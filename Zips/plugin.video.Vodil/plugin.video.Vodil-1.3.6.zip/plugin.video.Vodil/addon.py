# -*- coding: utf-8 -*-
import urllib,urllib2,re,xbmcplugin,xbmcgui,os,sys,datetime
from resources.lib.common_variables import *
from resources.lib.directory import *
from resources.lib.youtubewrapper import *
from resources.lib.watched import * 

fanart = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.Vodil', 'fanart.jpg'))
art = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.Vodil/resources/img', ''))

def CATEGORIES():
        addDir3('[COLOR aqua]חיפוש במי יוטיוב [/COLOR]',"plugin://plugin.video.MyYoutube/kodion/search/input/?description=חיפוש&fanart= &iconimage= &mode=4&name=חיפוש&url=www",35,art + 'ysearch.png')
        addDir3('[COLOR aqua]חיפוש ביוטיוב [/COLOR]',"plugin://plugin.video.youtube/kodion/search/input/",35,art + 'ysearch.png')
        addDir3('[COLOR aqua]חם ברשת [/COLOR]',"plugin://plugin.video.MyYoutube/?description=הסרטונים החמים&fanart&iconimage&mode=2&name=הסרטונים החמים&url=https://www.youtube.com//feed/trending",35,art + 'flame-512.png')
        addDir('[COLOR aqua]חדש מוזיקה מהארץ ומהעולם [/COLOR]','url',92,art + 'Music.png')
        addDir('[COLOR aqua]דוקומנטרי [/COLOR]','url',11,art + 'documentary.jpg')
        addDir('[COLOR aqua]מוזיקה [/COLOR]','url',13,art + 'Music.png')
        addDir('[COLOR aqua]הופעות חיות [/COLOR]','url',16,art + 'liveshows.png')
        addDir('[COLOR aqua]ילדים [/COLOR]','url',12,art + 'kids.png')
        addDir('[COLOR aqua]אוכל ובישול [/COLOR]','url',17,art + 'cooking.png')
        addDir('[COLOR aqua]טיולים [/COLOR]','url',14,art + 'travel.png')
        addDir('[COLOR aqua]סרטים [/COLOR]','url',38,art + 'movies.png')
        addDir('[COLOR aqua]לייף סטייל [/COLOR]','url',10,art + 'lifestyle.png') 
        addDir('[COLOR aqua]ספורט [/COLOR]','url',15,art + 'Sports.png')
        addDir('[COLOR aqua]סטנדאפ [/COLOR]','url',98,art + 'su.jpg')

def Muyu():
        addDir('[COLOR aqua]דרך (מי יוטיוב) [/COLOR]','url',99,'https://lh3.googleusercontent.com/W9bNP8huNRfwpHMxR-jHIXao_5FaOEdKLk3N0z7mr2W5ybdSEadEzDMD0qo-tNoe6A')
        addDir('[COLOR aqua]דרך (יוטיוב) [/COLOR]','url',199,'https://lh3.googleusercontent.com/W9bNP8huNRfwpHMxR-jHIXao_5FaOEdKLk3N0z7mr2W5ybdSEadEzDMD0qo-tNoe6A')

def Mu():

        addDir('[COLOR aqua]מוזיקה ישראלית רישמית [/COLOR]','url',97,art + '97.jpg')
        addDir('[COLOR aqua]עכשיו מוזיקה(חול) [/COLOR]','url',96,art + 'NOWMUSIC.png')
        addDir('[COLOR aqua]DJ WHO(חול) [/COLOR]','url',95,'https://yt3.ggpht.com/a/AGF-l7-zALRItOQnOaN5zwZxpE1XZyiZcdCllnN3wg=s100-c-k-c0xffffffff-no-rj-mo')
        addDir('[COLOR aqua]VEVO TUBE(חול) [/COLOR]','url',94,'https://yt3.ggpht.com/-AN6VHCEqvbo/AAAAAAAAAAI/AAAAAAAAAAA/4VTnH0Gva5Y/nd/photo.jpg')


def Mul():


        addDir('[COLOR aqua]מוזיקה ישראלית רישמית [/COLOR]','url',197,art + '97.jpg')
        addDir('[COLOR aqua]עכשיו מוזיקה(חול) [/COLOR]','url',196,art + 'NOWMUSIC.png')
        addDir('[COLOR aqua]DJ WHO(חול) [/COLOR]','url',195,'https://yt3.ggpht.com/a/AGF-l7-zALRItOQnOaN5zwZxpE1XZyiZcdCllnN3wg=s100-c-k-c0xffffffff-no-rj-mo')
        addDir('[COLOR aqua]VEVO TUBE(חול) [/COLOR]','url',193,'https://yt3.ggpht.com/-AN6VHCEqvbo/AAAAAAAAAAI/AAAAAAAAAAA/4VTnH0Gva5Y/nd/photo.jpg')

def Sll():
        addDir3('[COLOR aqua]עדן בן זקן [/COLOR]',"plugin://plugin.video.youtube/channel/UCt927ZDEsYMJL_8PXqMiVhg/?page=1",35,art + '97.jpg')
        addDir3('[COLOR aqua]נועה קירל [/COLOR]',"plugin://plugin.video.youtube/channel/UC7sHZrh1-mdwyBLq52m1MSw/?page=1",35,art + '97.jpg')
        addDir3('[COLOR aqua]גילי ארגוב [/COLOR]',"plugin://plugin.video.youtube/channel/UCequxLNw7IOP9rwJZhOtK6w/?page=1",35,art + '97.jpg')
        addDir3('[COLOR aqua]עמיר בניון [/COLOR]',"plugin://plugin.video.youtube/channel/UCerYyxoFp9Ln-zgxvM7X_0w/?page=1",35,art + '97.jpg')
        addDir3('[COLOR aqua]אושר ביטון [/COLOR]',"plugin://plugin.video.youtube/channel/UCVKwHi_KdIyd09oO8ap3vIA/?page=1",35,art + '97.jpg')
        addDir3('[COLOR aqua]אייל גולן [/COLOR]',"plugin://plugin.video.youtube/channel/UCrI0Slej0fiiwYPhR1EmFBw/?page=1",35,art + '97.jpg')
        addDir3('[COLOR aqua]מורן מזור [/COLOR]',"plugin://plugin.video.youtube/channel/UCNAeAJ7F1tvrLX-B7N2ohfA/?page=1",35,art + '97.jpg')
        addDir3('[COLOR aqua]אדיר גץ [/COLOR]',"plugin://plugin.video.youtube/channel/UC3KqEm2Q5XjzJJfhyj3MxSw/?page=1",35,art + '97.jpg')
        addDir3('[COLOR aqua]מאור אדרי [/COLOR]',"plugin://plugin.video.youtube/channel/UCDYRaqbP0BA4E73Ywn6-eVQ/?page=1",35,art + '97.jpg')
        addDir3('[COLOR aqua]אגם בוחבוט [/COLOR]',"plugin://plugin.video.youtube/channel/UC9TW96-3a8_scwVJjo9_PbA/?page=1",35,art + '97.jpg')
        addDir3('[COLOR aqua]רגב הוד [/COLOR]',"plugin://plugin.video.youtube/channel/UCs-MmgLIZ5YSFJuBz75HdSg/?page=1",35,art + '97.jpg')
        addDir3('[COLOR aqua]ישי ריבו [/COLOR]',"plugin://plugin.video.youtube/channel/UCHwxQ7twj_VWIPMcJ3Zdyqg/?page=1",35,art + '97.jpg')
        addDir3('[COLOR aqua]עומר אדם [/COLOR]',"plugin://plugin.video.youtube/user/OmerAdamOfficial/?page=1",35,art + '97.jpg')
        addDir3('[COLOR aqua]מאיר בנאי [/COLOR]',"plugin://plugin.video.youtube/user/MeirBanai/?page=1",35,art + '97.jpg')
        addDir3('[COLOR aqua]נתן גושן [/COLOR]',"plugin://plugin.video.youtube/user/NathanGoshenOfficial/?page=1",35,art + '97.jpg')
        addDir3('[COLOR aqua]מושיק עפיה [/COLOR]',"plugin://plugin.video.youtube/user/MoshikAfiaOfficial/?page=1",35,art + '97.jpg')
        addDir3('[COLOR aqua]ליאור נרקיס [/COLOR]',"plugin://plugin.video.youtube/user/LiorNarkisOfficial/?page=1",35,art + '97.jpg')
        addDir3('[COLOR aqua]בועז שרעבי [/COLOR]',"plugin://plugin.video.youtube/user/BoazSharabiMusic/?page=1",35,art + '97.jpg')
        addDir3('[COLOR aqua]ישי לוי [/COLOR]',"plugin://plugin.video.youtube/user/IshayLeviOfficial/?page=1",35,art + '97.jpg')
        addDir3('[COLOR aqua]נסרין קדרי [/COLOR]',"plugin://plugin.video.youtube/user/NasreenQadri/?page=1",35,art + '97.jpg')
        addDir3('[COLOR aqua]ריטה [/COLOR]',"plugin://plugin.video.youtube/user/ritaofficial/?page=1",35,art + '97.jpg')
        addDir3('[COLOR aqua]שרית חדד [/COLOR]',"plugin://plugin.video.youtube/user/SaritHadadOfficial/?page=1",35,art + '97.jpg')
        addDir3('[COLOR aqua]דודו אהרון [/COLOR]',"plugin://plugin.video.youtube/user/DuduAharonOfficiaI/?page=1",35,art + '97.jpg')
        addDir3('[COLOR aqua]שלומי שבת [/COLOR]',"plugin://plugin.video.youtube/user/shlomishabatofficiaI/?page=1",35,art + '97.jpg')
        addDir3('[COLOR aqua]חיים משה [/COLOR]',"plugin://plugin.video.youtube/user/haimmosheoffical/?page=1",35,art + '97.jpg')
        addDir3('[COLOR aqua]איציק קלה [/COLOR]',"plugin://plugin.video.youtube/user/itzikalaofficial/?page=1",35,art + '97.jpg')
        addDir3('[COLOR aqua]פאר טסי [/COLOR]',"plugin://plugin.video.youtube/user/peertasimizrahi/?page=1",35,art + '97.jpg')
        addDir3('[COLOR aqua]הראל מויאל [/COLOR]',"plugin://plugin.video.youtube/user/HarelMoyalMusic/?page=1",35,art + '97.jpg')


def Sxl():
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוסיקה 1 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLSDFo3uefkViQiBE1boD4E1lkT-L0tval/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוסיקה 2 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLqf3vdDTch5eIprOE5UW22JYVeF2H3DZQ/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 3 [/COLOR]',"plugin://plugin.video.youtube/playlist/PL2BiE_4h8Tpx5gH-aLL2fPHEDIQuNdOO7/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו ככה אני מכנה מוסיקה 4 [/COLOR]',"plugin://plugin.video.youtube/playlist/playlist? list = PLC134EF07843F8E12 /?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני קורא מוסיקה Vol.5 [/COLOR]',"plugin://plugin.video.youtube/playlist/PL0F21A53AF61D1FB7/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני קורא מוסיקה Vol.6 [/COLOR]',"plugin://plugin.video.youtube/playlist/PL469DC54E90251585/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוסיקה 7 [/COLOR]',"plugin://plugin.video.youtube/playlist/PL6Z-l9iL9V02f4s7eTwOOHLICG_pMp-bi/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 8 [/COLOR]',"plugin://plugin.video.youtube/playlist/PL2BiE_4h8TpzglEey9QQK56Pk_kc0D_Ll/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני קורא מוסיקה Vol.9 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLAAB55DE564DDB852/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 10 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLGQ0UcnwJRN0vlWtPCvCddvpVv-_RJXik/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני מכנה מוסיקה 11 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLe_aExlm6LzI-bHdvaznqY9HaN0uccsWY/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני קורא מוסיקה Vol.12 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLDouWbMQEftHsFyHSBua-RZLFsx--Cu4U/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוסיקה 13 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLP1Y3xiNAKkuhumMQUsCZocF-SaS7uIAC/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 14 [/COLOR]',"plugin://plugin.video.youtube/playlist/PL2BiE_4h8TpwA_Vs7CmADdM8TWsnmH9L8/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני מכנה מוסיקה 15 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLsqB7ljSBkucly4zjjGca9PUDCvrdd4F1/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני קורא מוסיקה 16 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLP1Y3xiNAKkug6YZSWuszc3nrXMxImP0T/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 17 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLGQ0UcnwJRN2YFTPvcFdlEqPk2X50EtsC/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 18 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLsqB7ljSBkudm8Kc21ML3S8Ywwm8POK_n/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 19 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLGQ0UcnwJRN3nlqZfg3GzdnJRu7tXbDvP/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 20 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLP1Y3xiNAKkvYyHd7bmpd0B8gHTxvcYdL/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוסיקה 21 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLP1Y3xiNAKktUOg36k5y3pOnHh9gmoXsn/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 22 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLU2xNh0BeCUhEVLj3S78WNag9O-Hpm8ad/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 23 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLsqB7ljSBkufEHqSjQJmedoixNkWNtQBO/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני קורא מוסיקה Vol.24 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLDouWbMQEftFLmCbJNnxBqo925x89tJci/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 25 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLsqB7ljSBkuexkNUk-eaT0nS9KAZPGMD7/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 26 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLsqB7ljSBkuesJ07Bxz6eiLcIaIz7xYXv/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 27 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLsqB7ljSBkuecopwcuVGcYAJO4qvz3XA3/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 28 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLsqB7ljSBkufIxPcOdmwnxGfSRZgDGOe3/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 29 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLsqB7ljSBkucC3zgKZF3S4EiZ45PUmx-/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! כרך 30 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLDouWbMQEftEEeKB6GcLaDQbypvob4e10/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 31 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLsqB7ljSBkuevnNzpL3R_p6BEV_u1r3aZ/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 32 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLsqB7ljSBkudmCDLFhy2slnXN3gVUuGrm/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 33 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLsqB7ljSBkud2zZR9oVu2XGjZ8aDNlIVX/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 34 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLsqB7ljSBkufvOUAC7Wbr5_Ik_XsnjD_X/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 35 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLsqB7ljSBkucOpSfwBvSGo-oNiGJ3ALJi/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 36 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLsqB7ljSBkufqYFkLc4cBF6CkHzDBxnYx/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 37 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLDouWbMQEftEcdNjhvM5YeVvXSl9nxOaU/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 38 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLsqB7ljSBkuex2YFNUhqHTEPU4PXMz6Gz/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 39 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLsqB7ljSBkueDzyERVqcAdh2C-aiTmBXY/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני מתקשר למוזיקה 40 [/COLOR]',"plugin://plugin.video.youtube/playlist/PL1h8do6DyqVMWIR4s3ppNF64_M0y42wW2/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 41 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLsqB7ljSBkuc7rHY6_l1khV-rG_Tie81e/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 42 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLsqB7ljSBkufUxVPOQxyTkistak74Si_S/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! כרך 43 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLDouWbMQEftHJSvaRvBzvFZ4S34kucnwl/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 44 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLsqB7ljSBkuehTugfSUFkeXFGbwKBcYnu/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 45 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLsqB7ljSBkueLsTNOL9vMM9QX3Vnrz-yn/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 46 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLDUAmuW0s8Whc9NXMvEtO5jFynx43OBLo/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 47 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLDouWbMQEftFtfaMjEM-9IjipNjw7qJ5W/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני מתקשר למוזיקה 48 [/COLOR]',"plugin://plugin.video.youtube/playlist/PL1h8do6DyqVOBo4p_hK90IMfCIPcFQ3dx/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני קורא מוסיקה Vol.49 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLxniG6aRxGSsg3ZuNKTs7dE5VWNBche0D/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא מוסיקה! 51 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLhUnYSiS17hw156nLAPgoULF3Mq7_z6K-/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 52 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLGQ0UcnwJRN1i1peiUpidY8gOl6u7dGbY/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 53 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLGQ0UcnwJRN0AgPw0IWosO6eyHCmlgOjx/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 54 [/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PLGQ0UcnwJRN3GZ-1DvWtyVXI_wP-XitwI/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא מוסיקה! 56 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLhUnYSiS17hzI0c55YCNUREsg_QLem0D2/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני אאהב מוזיקה 57 [/COLOR]',"plugin://plugin.video.youtube/playlist/PL1h8do6DyqVNHVVtloq2-cOWnuWtAX87w/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 58 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLGQ0UcnwJRN2AnC0Fe49aa7Lq-QILORYh/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 59 [/COLOR]',"plugin://plugin.video.youtube/playlist/PL1F0D80E99F7850E5/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא מוסיקה! 60 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLhUnYSiS17hxqroAmcTp0rPZlvjlSOKQ-/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! כרך 61 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLDouWbMQEftGZPWsKV2-J1Nb-bnnP1kDt/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני מתקשר למוזיקה 62[/COLOR]',"plugin://plugin.video.youtube/playlist/PLDouWbMQEftEFihO_LZMovLip0mVz0Fg3/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! כרך 63 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLDouWbMQEftGksuKJ-MJ8i2WwtwH-DyVe/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 64 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLDB9B7A7906FAFAB8/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני מתקשר למוזיקה 65 [/COLOR]',"plugin://plugin.video.youtube/playlist/PL_34_m4eTlaOh7AX4GJRnnxKgJ5n9_V-M/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! כרך א  66 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLDouWbMQEftFvmLqnvKo-Svl6QNXaD4ac/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני קורא מוסיקה 67 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLgXn-x6PNSy0QqokVgysvrcN_99cnlK1W/?page=1",35,art + 'NOWMUSIC.png')	
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוסיקה 68 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLgXn-x6PNSy3zxCaW4I9zxJpoNGm97dUK/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה אני קורא מוזיקה 69 [/COLOR]',"plugin://plugin.video.youtube/playlist/PL_34_m4eTlaP6n2tYDBKamuvoQDo89a97/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא מוסיקה! 70 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLfajXyIbTpnHOAqRdvINIq2ak-lFiEJvw/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא מוסיקה! 71 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLfajXyIbTpnHWjIRCcKyLcBorqLBnjPxc/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא מוזיקה 72 [/COLOR]',"plugin://plugin.video.youtube/playlist/PL_34_m4eTlaMoYI8LghIOjui2Tr8rukHp/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא מוסיקה! 73 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLjvJyxqOmFBJFZ8kMlpTIG63jCFwi_-cu/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני קורא מוסיקה 74 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLDouWbMQEftHqrKjdu7cFSACIudT2n5Il/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני קורא מוסיקה 75 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLjvJyxqOmFBIRjjgW0IQgRfh3cfAgANsS/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני קורא מוסיקה 76 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLDouWbMQEftHiTge92lMQFgbNVUCBlP8E/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא מוזיקה 77 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLziBTZqySBRFOFOwbSuPn4GtockoGot7k/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 78 [/COLOR]',"plugin://plugin.video.youtube/playlist/PL6CDBDD2A3C0D55A5/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא מוסיקה! 79 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLjvJyxqOmFBLVpyCD38x8RkEaYtETiBcR/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוסיקה 80 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLBB7D0AF873F8FAEA/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 81 [/COLOR]',"plugin://plugin.video.youtube/playlist/PL8FA9A7569EBB5E4A/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 82 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLoDgQlTbBQzYPrbsgmAJcDoD9Y33XhNJo/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני מתקשר למוזיקה 83 [/COLOR]',"plugin://plugin.video.youtube/playlist/PL_34_m4eTlaOeNd6fP9MspKqh9ksDiNtm/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 84 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLwyQmbD4WPl9s1rHOfSSKUj8a86HRLUCA/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 85 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLlhDgn0Cytc26XrU4x3JDhXb9dxyt2DEa/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוסיקה 86 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLDg9kwdnXsO-sGrCANOR5gb44MLhLD1Er/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוסיקה 87 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLRmc7JLx8IJKOccrdanLLQG1s0FTaHGKH/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני מתקשר למוזיקה 88 [/COLOR]',"plugin://plugin.video.youtube/playlist/PL_34_m4eTlaPzdgA9RG_BlIImsUwCVkzy/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא מוסיקה! 89 [/COLOR]',"plugin://plugin.video.youtube/playlist/PL_34_m4eTlaOtJMirQzXvOoAwdechWbhF/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא מוסיקה! 90 [/COLOR]',"plugin://plugin.video.youtube/playlist/PL_34_m4eTlaNHt6GM5dOnraJ2zdE4R2Z_/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא מוסיקה! 91 [/COLOR]',"plugin://plugin.video.youtube/playlist/PL_34_m4eTlaMf-42RHro2x2UVMHNEkLvD/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא למוזיקה 92 [/COLOR]',"plugin://plugin.video.youtube/playlist/PL_34_m4eTlaOFcXryY7OFbYGtK5Y1JoIa/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא מוסיקה! 93 [/COLOR]',"plugin://plugin.video.youtube/playlist/PL_34_m4eTlaN5Dj1kIzrJMX95HRBLqeQr/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא מוסיקה! 94 [/COLOR]',"plugin://plugin.video.youtube/playlist/PL_34_m4eTlaO0auWQxAH__sUTfRidOQZW/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא מוסיקה! 95 [/COLOR]',"plugin://plugin.video.youtube/playlist/NOW לזה אני קורא המנונים של המפלגה /?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא מוסיקה! 96 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLJyQ4LyHbaraIkU1z9RzBLS2kWqAoQXH0/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא מוסיקה! עכשיו 97 [/COLOR]',"plugin://plugin.video.youtube/playlist/PL_34_m4eTlaPorC89EUOQxwhXeZxd-Hc7/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא מוסיקה! 98 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLJyQ4LyHbarYfhbtEaTk4xj9CGRlylq6I/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא מוסיקה! 99 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLAd5X7u2hj3dRVSJz4mrcRxfrbCZ-E4iN/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו ככה אני מכנה מוסיקה 100 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLLZStkUkKPlVCF5pqz7Ztx8lXsTpGbIf6/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא מוסיקה! 101 [/COLOR]',"plugin://plugin.video.youtube/playlist/PL_34_m4eTlaP8vMmdKKQpo4pm0efcwkxc/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוסיקה 102 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLfWOuLCdH-1dCXUN2WvV6mUiTXRpr5VmI/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא מוסיקה! 103 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLcn2SuWDLcXDkhAclaScxjgWqW6KHiv_m/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא מוסיקה! 104 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLhV4RKTkP5JQRIjQUPM5Ndr_xuF7gCF6h/?page=1",35,art + 'NOWMUSIC.png')	
        addDir3('[COLOR aqua]עכשיו זה מה שאני מכנה פופ [/COLOR]',"plugin://plugin.video.youtube/playlist/PL_34_m4eTlaNQBMQYxfxQLN7eUkIKP66y/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני קוראת 60s [/COLOR]',"plugin://plugin.video.youtube/playlist/PL2BiE_4h8TpwWwKe3i_c4pnPshJktXC92/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני מכנה שנות ה -70 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLhXCO9UQq4zoIJY4qa1UA_WQWuwS-y2bc/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני מכנה שנות השמונים [/COLOR]',"plugin://plugin.video.youtube/playlist/PL_34_m4eTlaMgClOUihGU5EKM0md93FCN/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני מכנה שנות ה -90 [/COLOR]',"plugin://plugin.video.youtube/playlist/PL_34_m4eTlaOrcFRHD9mG4zUilcXQS8uB/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני קוראת ה- 00 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLsdPA0A_fKLmuHNuafb76kecjHqeGoBLs/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]VA - עכשיו זה מה שאני מכנה מסיבת קיץ 2019 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLCo9rIUIbahty3bDn2cUeK_fU6sYrmWnF/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה רגאיי [/COLOR]',"plugin://plugin.video.youtube/playlist/PL2BiE_4h8TpwJLR--E3-Fco9BRmEH0oq1/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני מכנה המאה ה -21 [/COLOR]',"plugin://plugin.video.youtube/playlist/PL_34_m4eTlaPLkaa4gLSJsWm86Z0H8i_U/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מדינה (2017) [/COLOR]',"plugin://plugin.video.youtube/playlist/PL2BiE_4h8TpwCSkzXEntUnMb2K8Sfl8q3/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]VA - עכשיו זה מה שאני מכנה מסיבת קיץ 2019 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLCo9rIUIbahty3bDn2cUeK_fU6sYrmWnF/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה רוק קלאסי (2015) [/COLOR]',"plugin://plugin.video.youtube/playlist/PL2BiE_4h8Tpw-9ppd1cagjhcsa6nuOByP/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 1985 (כעת סדרת יום השנה העשירית) [/COLOR]',"plugin://plugin.video.youtube/playlist/PLsqB7ljSBkufwGaYG3NFmCK9Z9dp86vb9/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא המנונים של המפלגה [/COLOR]',"plugin://plugin.video.youtube/playlist/PL_34_m4eTlaN0b1Wntb0io2m_j0Bbe1Id/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו: 100 צפיות: Sing-a-Long [/COLOR]',"plugin://plugin.video.youtube/playlist/PL2BiE_4h8Tpx3Ez_UdMt-n6WeamFX3bqs/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו 100 צפיות לסרטים [/COLOR]',"plugin://plugin.video.youtube/playlist/PLmMGqezX7LHW2HGwL8h3UpLtPxciLf9hO/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו: 100 צפיות: שירי מכוניות [/COLOR]',"plugin://plugin.video.youtube/playlist/PL2BiE_4h8Tpx-eImS3x2BYsxSIwqWfl7x/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]VA - NU 100 צפיות שנשכחו שנות ה -80 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLh2ZThx4HC6WSLzfH8weBzCpzCLUNDGl4/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]VA - NU 100 צפיות שנשכחו שנות ה -90 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLCo9rIUIbahs3c8qsdSzflX7xstAoJg3N/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו: 100 צפיות: משטרי כוח [/COLOR]',"plugin://plugin.video.youtube/playlist/PL2BiE_4h8Tpy37yKc8FP4HpIV6ZyR2eaZ/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו: 100 צפיות: חג המולד [/COLOR]',"plugin://plugin.video.youtube/playlist/PL2BiE_4h8Tpz00pWE68zD_Ag9PO9o903s/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה רוקנרול [/COLOR]',"plugin://plugin.video.youtube/playlist/PL2BiE_4h8TpzdcbEeANYQDnvsfXo0HHL5/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני קורא שירי אהבה (2018) [/COLOR]',"plugin://plugin.video.youtube/playlist/PL2BiE_4h8Tpz3VMIcAnTzaX5rpsvtIczX/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני קורא קל [/COLOR]',"plugin://plugin.video.youtube/playlist/PL2BiE_4h8Tpwr3V1CEDhNeKxEm6PLQwSe/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא דיסני 2017 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLhXCO9UQq4zosccGMdyCinFpdHvSE9Kvu/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו מה שאני קורא לאבא רוק [/COLOR]',"plugin://plugin.video.youtube/playlist/PLW_NpxKH1uD_qdX2gbvTsHVzYKvEQXGh7/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]VA - עכשיו זה מה שאני מכנה מסיבת קיץ 2019 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLCo9rIUIbahty3bDn2cUeK_fU6sYrmWnF/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא לו רמיקס [/COLOR]',"plugin://plugin.video.youtube/playlist/PLhXCO9UQq4zocy64nFXan7WiscyJymBDH/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה אולד סקול [/COLOR]',"plugin://plugin.video.youtube/playlist/PL2BiE_4h8TpyHnumViPWg0_enDQRotJv4/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה נשמה קלאסית [/COLOR]',"plugin://plugin.video.youtube/playlist/PL2BiE_4h8TpzvN8xfhOGPUw-SAcDa2-Ex/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני מכנה זמר [/COLOR]',"plugin://plugin.video.youtube/playlist/PL_34_m4eTlaNh63gxFpUwwAROXj5V3AX8/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני קוראת ליל כל הקדושים [/COLOR]',"plugin://plugin.video.youtube/playlist/PLGQ0UcnwJRN3rMvLhns856JQoxtQtYIgf/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני קוראת אני רוצה רוק [/COLOR]',"plugin://plugin.video.youtube/playlist/PLGQ0UcnwJRN3rRVKwiNLTc1rAVrWSGEUp/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני קוראת מספר 1 (2015) [/COLOR]',"plugin://plugin.video.youtube/playlist/PLGQ0UcnwJRN2ZlwzY369IQP__M_bGRp1E/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוטאון [/COLOR]',"plugin://plugin.video.youtube/playlist/PLGQ0UcnwJRN0sYMpb9cKV9ct_h1Ct1YP0/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה גל חדש 80s [/COLOR]',"plugin://plugin.video.youtube/playlist/PLGQ0UcnwJRN03-63KDFnCiKaYLJsszOi_/?page=1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני קוראת Country Vol. 3 [/COLOR]',"plugin://plugin.video.youtube/playlist/PLGQ0UcnwJRN0sCK_zH_BoG1nd4Y_3pmJb/?page=1",35,art + 'NOWMUSIC.png')

def Su():
        addDir3('[COLOR aqua]פלייליסט סטנדאפ [/COLOR]',"plugin://plugin.video.youtube/?description=חיפוש&fanart&iconimage&mode=4&name=פלייליסט סטנדאפ&url=www",35,art + 'su.jpg')
        addDir3('[COLOR aqua]נאור ציון [/COLOR]',"plugin://plugin.video.youtube/?description=חיפוש&fanart&iconimage&mode=4&name=נאור ציון&url=www",35,art + 'su.jpg')	 

def Dgl():
        addDir3('[B][COLOR coral]country music [/COLOR][/B]',"plugin://plugin.video.youtube/playlist/PLV3wO-tIt_3ECUWNSkyFH633Gnk3gluV8/",35,'https://yt3.ggpht.com/a/AGF-l7-zALRItOQnOaN5zwZxpE1XZyiZcdCllnN3wg=s100-c-k-c0xffffffff-no-rj-mo')

        addDir3('[B][COLOR coral]uncategorized [/COLOR][/B]',"plugin://plugin.video.youtube/playlist/PLV3wO-tIt_3F52OlmieJsNUd_ABn2iXZN/",35,'https://yt3.ggpht.com/a/AGF-l7-zALRItOQnOaN5zwZxpE1XZyiZcdCllnN3wg=s100-c-k-c0xffffffff-no-rj-mo')

        addDir3('[B][COLOR coral]events [/COLOR][/B]',"plugin://plugin.video.youtube/playlist/PLV3wO-tIt_3HGIQ3C_Czmc0x-JaDpFkAA/",35,'https://yt3.ggpht.com/a/AGF-l7-zALRItOQnOaN5zwZxpE1XZyiZcdCllnN3wg=s100-c-k-c0xffffffff-no-rj-mo')

        addDir3('[B][COLOR coral]Christmas [/COLOR][/B]',"plugin://plugin.video.youtube/playlist/PLV3wO-tIt_3FKhHChoGD5H6LP4jmkBPyD/",35,'https://yt3.ggpht.com/a/AGF-l7-zALRItOQnOaN5zwZxpE1XZyiZcdCllnN3wg=s100-c-k-c0xffffffff-no-rj-mo')

        addDir3('[B][COLOR coral]80/90s [/COLOR][/B]',"plugin://plugin.video.youtube/playlist/PLV3wO-tIt_3FH1ah7Rp671n63z2huFYZ2/",35,'https://yt3.ggpht.com/a/AGF-l7-zALRItOQnOaN5zwZxpE1XZyiZcdCllnN3wg=s100-c-k-c0xffffffff-no-rj-mo')

        addDir3('[B][COLOR coral]concerts [/COLOR][/B]',"plugin://plugin.video.youtube/playlist/PLV3wO-tIt_3Efj8N08eopR5NFh1dCmEt0/",35,'https://yt3.ggpht.com/a/AGF-l7-zALRItOQnOaN5zwZxpE1XZyiZcdCllnN3wg=s100-c-k-c0xffffffff-no-rj-mo')

        addDir3('[B][COLOR coral]R&B [/COLOR][/B]',"plugin://plugin.video.youtube/playlist/PLV3wO-tIt_3E3fK2NKmylEEqkRVaW9hLz/",35,'https://yt3.ggpht.com/a/AGF-l7-zALRItOQnOaN5zwZxpE1XZyiZcdCllnN3wg=s100-c-k-c0xffffffff-no-rj-mo')

        addDir3('[B][COLOR coral]karaoke [/COLOR][/B]',"plugin://plugin.video.youtube/playlist/PLV3wO-tIt_3GVT106wzYNdRoL7YbRZlT-/",35,'https://yt3.ggpht.com/a/AGF-l7-zALRItOQnOaN5zwZxpE1XZyiZcdCllnN3wg=s100-c-k-c0xffffffff-no-rj-mo')

        addDir3('[B][COLOR coral]tragically hip [/COLOR][/B]',"plugin://plugin.video.youtube/playlist/PLV3wO-tIt_3FN5M5ct_4PscMv_SL4hcGp/",35,'https://yt3.ggpht.com/a/AGF-l7-zALRItOQnOaN5zwZxpE1XZyiZcdCllnN3wg=s100-c-k-c0xffffffff-no-rj-mo')

        addDir3('[B][COLOR coral]screensavers [/COLOR][/B]',"plugin://plugin.video.youtube/playlist/PLV3wO-tIt_3EbjH5y5XlV29jowSjlNMO3/",35,'https://yt3.ggpht.com/a/AGF-l7-zALRItOQnOaN5zwZxpE1XZyiZcdCllnN3wg=s100-c-k-c0xffffffff-no-rj-mo')

        addDir3('[B][COLOR coral]cape breton kitchen party [/COLOR][/B]',"plugin://plugin.video.youtube/playlist/PLV3wO-tIt_3F4DNbag62rnJ4EOS5r2mnA/",35,'https://yt3.ggpht.com/a/AGF-l7-zALRItOQnOaN5zwZxpE1XZyiZcdCllnN3wg=s100-c-k-c0xffffffff-no-rj-mo')

        addDir3('[B][COLOR coral]motown [/COLOR][/B]',"plugin://plugin.video.youtube/playlist/PLV3wO-tIt_3HzAo-BPj2W-l9VwzxqgHCU/",35,'https://yt3.ggpht.com/a/AGF-l7-zALRItOQnOaN5zwZxpE1XZyiZcdCllnN3wg=s100-c-k-c0xffffffff-no-rj-mo')

def Sl():
        addDir3('[COLOR aqua]עדן בן זקן [/COLOR]',"plugin://plugin.video.MyYoutube/channel/UCt927ZDEsYMJL_8PXqMiVhg",35,art + '97.jpg')
        addDir3('[COLOR aqua]נועה קירל [/COLOR]',"plugin://plugin.video.MyYoutube/channel/UC7sHZrh1-mdwyBLq52m1MSw",35,art + '97.jpg')
        addDir3('[COLOR aqua]גילי ארגוב [/COLOR]',"plugin://plugin.video.MyYoutube/channel/UCequxLNw7IOP9rwJZhOtK6w",35,art + '97.jpg')
        addDir3('[COLOR aqua]עמיר בניון [/COLOR]',"plugin://plugin.video.MyYoutube/channel/UCerYyxoFp9Ln-zgxvM7X_0w",35,art + '97.jpg')
        addDir3('[COLOR aqua]אושר ביטון [/COLOR]',"plugin://plugin.video.MyYoutube/channel/UCVKwHi_KdIyd09oO8ap3vIA",35,art + '97.jpg')
        addDir3('[COLOR aqua]אייל גולן [/COLOR]',"plugin://plugin.video.MyYoutube/channel/UCrI0Slej0fiiwYPhR1EmFBw",35,art + '97.jpg')
        addDir3('[COLOR aqua]מורן מזור [/COLOR]',"plugin://plugin.video.MyYoutube/channel/UCNAeAJ7F1tvrLX-B7N2ohfA",35,art + '97.jpg')
        addDir3('[COLOR aqua]אדיר גץ [/COLOR]',"plugin://plugin.video.MyYoutube/channel/UC3KqEm2Q5XjzJJfhyj3MxSw",35,art + '97.jpg')
        addDir3('[COLOR aqua]מאור אדרי [/COLOR]',"plugin://plugin.video.MyYoutube/channel/UCDYRaqbP0BA4E73Ywn6-eVQ",35,art + '97.jpg')
        addDir3('[COLOR aqua]אגם בוחבוט [/COLOR]',"plugin://plugin.video.MyYoutube/channel/UC9TW96-3a8_scwVJjo9_PbA",35,art + '97.jpg')
        addDir3('[COLOR aqua]רגב הוד [/COLOR]',"plugin://plugin.video.MyYoutube/channel/UCs-MmgLIZ5YSFJuBz75HdSg",35,art + '97.jpg')
        addDir3('[COLOR aqua]ישי ריבו [/COLOR]',"plugin://plugin.video.MyYoutube/channel/UCHwxQ7twj_VWIPMcJ3Zdyqg",35,art + '97.jpg')
        addDir3('[COLOR aqua]עומר אדם [/COLOR]',"plugin://plugin.video.MyYoutube/user/OmerAdamOfficial",35,art + '97.jpg')
        addDir3('[COLOR aqua]מאיר בנאי [/COLOR]',"plugin://plugin.video.MyYoutube/user/MeirBanai",35,art + '97.jpg')
        addDir3('[COLOR aqua]נתן גושן [/COLOR]',"plugin://plugin.video.MyYoutube/user/NathanGoshenOfficial",35,art + '97.jpg')
        addDir3('[COLOR aqua]מושיק עפיה [/COLOR]',"plugin://plugin.video.MyYoutube/user/MoshikAfiaOfficial",35,art + '97.jpg')
        addDir3('[COLOR aqua]ליאור נרקיס [/COLOR]',"plugin://plugin.video.MyYoutube/user/LiorNarkisOfficial",35,art + '97.jpg')
        addDir3('[COLOR aqua]בועז שרעבי [/COLOR]',"plugin://plugin.video.MyYoutube/user/BoazSharabiMusic",35,art + '97.jpg')
        addDir3('[COLOR aqua]ישי לוי [/COLOR]',"plugin://plugin.video.MyYoutube/user/IshayLeviOfficial",35,art + '97.jpg')
        addDir3('[COLOR aqua]נסרין קדרי [/COLOR]',"plugin://plugin.video.MyYoutube/user/NasreenQadri",35,art + '97.jpg')
        addDir3('[COLOR aqua]ריטה [/COLOR]',"plugin://plugin.video.MyYoutube/user/ritaofficial",35,art + '97.jpg')
        addDir3('[COLOR aqua]שרית חדד [/COLOR]',"plugin://plugin.video.MyYoutube/user/SaritHadadOfficial",35,art + '97.jpg')
        addDir3('[COLOR aqua]דודו אהרון [/COLOR]',"plugin://plugin.video.MyYoutube/user/DuduAharonOfficiaI",35,art + '97.jpg')
        addDir3('[COLOR aqua]שלומי שבת [/COLOR]',"plugin://plugin.video.MyYoutube/user/shlomishabatofficiaI",35,art + '97.jpg')
        addDir3('[COLOR aqua]חיים משה [/COLOR]',"plugin://plugin.video.MyYoutube/user/haimmosheoffical",35,art + '97.jpg')
        addDir3('[COLOR aqua]איציק קלה [/COLOR]',"plugin://plugin.video.MyYoutube/user/itzikalaofficial",35,art + '97.jpg')
        addDir3('[COLOR aqua]פאר טסי [/COLOR]',"plugin://plugin.video.MyYoutube/user/peertasimizrahi",35,art + '97.jpg')
        addDir3('[COLOR aqua]הראל מויאל [/COLOR]',"plugin://plugin.video.MyYoutube/user/HarelMoyalMusic",35,art + '97.jpg')

def Dg():
        addDir3('[B][COLOR coral]country music [/COLOR][/B]',"plugin://plugin.video.MyYoutube/playlist/PLV3wO-tIt_3ECUWNSkyFH633Gnk3gluV8/",35,'https://yt3.ggpht.com/a/AGF-l7-zALRItOQnOaN5zwZxpE1XZyiZcdCllnN3wg=s100-c-k-c0xffffffff-no-rj-mo')

        addDir3('[B][COLOR coral]uncategorized [/COLOR][/B]',"plugin://plugin.video.MyYoutube/playlist/PLV3wO-tIt_3F52OlmieJsNUd_ABn2iXZN/",35,'https://yt3.ggpht.com/a/AGF-l7-zALRItOQnOaN5zwZxpE1XZyiZcdCllnN3wg=s100-c-k-c0xffffffff-no-rj-mo')

        addDir3('[B][COLOR coral]events [/COLOR][/B]',"plugin://plugin.video.MyYoutube/playlist/PLV3wO-tIt_3HGIQ3C_Czmc0x-JaDpFkAA/",35,'https://yt3.ggpht.com/a/AGF-l7-zALRItOQnOaN5zwZxpE1XZyiZcdCllnN3wg=s100-c-k-c0xffffffff-no-rj-mo')

        addDir3('[B][COLOR coral]Christmas [/COLOR][/B]',"plugin://plugin.video.MyYoutube/playlist/PLV3wO-tIt_3FKhHChoGD5H6LP4jmkBPyD/",35,'https://yt3.ggpht.com/a/AGF-l7-zALRItOQnOaN5zwZxpE1XZyiZcdCllnN3wg=s100-c-k-c0xffffffff-no-rj-mo')

        addDir3('[B][COLOR coral]80/90s [/COLOR][/B]',"plugin://plugin.video.MyYoutube/playlist/PLV3wO-tIt_3FH1ah7Rp671n63z2huFYZ2/",35,'https://yt3.ggpht.com/a/AGF-l7-zALRItOQnOaN5zwZxpE1XZyiZcdCllnN3wg=s100-c-k-c0xffffffff-no-rj-mo')

        addDir3('[B][COLOR coral]concerts [/COLOR][/B]',"plugin://plugin.video.MyYoutube/playlist/PLV3wO-tIt_3Efj8N08eopR5NFh1dCmEt0/",35,'https://yt3.ggpht.com/a/AGF-l7-zALRItOQnOaN5zwZxpE1XZyiZcdCllnN3wg=s100-c-k-c0xffffffff-no-rj-mo')

        addDir3('[B][COLOR coral]R&B [/COLOR][/B]',"plugin://plugin.video.MyYoutube/playlist/PLV3wO-tIt_3E3fK2NKmylEEqkRVaW9hLz/",35,'https://yt3.ggpht.com/a/AGF-l7-zALRItOQnOaN5zwZxpE1XZyiZcdCllnN3wg=s100-c-k-c0xffffffff-no-rj-mo')

        addDir3('[B][COLOR coral]karaoke [/COLOR][/B]',"plugin://plugin.video.MyYoutube/playlist/PLV3wO-tIt_3GVT106wzYNdRoL7YbRZlT-/",35,'https://yt3.ggpht.com/a/AGF-l7-zALRItOQnOaN5zwZxpE1XZyiZcdCllnN3wg=s100-c-k-c0xffffffff-no-rj-mo')

        addDir3('[B][COLOR coral]tragically hip [/COLOR][/B]',"plugin://plugin.video.MyYoutube/playlist/PLV3wO-tIt_3FN5M5ct_4PscMv_SL4hcGp/",35,'https://yt3.ggpht.com/a/AGF-l7-zALRItOQnOaN5zwZxpE1XZyiZcdCllnN3wg=s100-c-k-c0xffffffff-no-rj-mo')

        addDir3('[B][COLOR coral]screensavers [/COLOR][/B]',"plugin://plugin.video.MyYoutube/playlist/PLV3wO-tIt_3EbjH5y5XlV29jowSjlNMO3/",35,'https://yt3.ggpht.com/a/AGF-l7-zALRItOQnOaN5zwZxpE1XZyiZcdCllnN3wg=s100-c-k-c0xffffffff-no-rj-mo')

        addDir3('[B][COLOR coral]cape breton kitchen party [/COLOR][/B]',"plugin://plugin.video.MyYoutube/playlist/PLV3wO-tIt_3F4DNbag62rnJ4EOS5r2mnA/",35,'https://yt3.ggpht.com/a/AGF-l7-zALRItOQnOaN5zwZxpE1XZyiZcdCllnN3wg=s100-c-k-c0xffffffff-no-rj-mo')

        addDir3('[B][COLOR coral]motown [/COLOR][/B]',"plugin://plugin.video.MyYoutube/playlist/PLV3wO-tIt_3HzAo-BPj2W-l9VwzxqgHCU/",35,'https://yt3.ggpht.com/a/AGF-l7-zALRItOQnOaN5zwZxpE1XZyiZcdCllnN3wg=s100-c-k-c0xffffffff-no-rj-mo')

def Sx():

        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוסיקה 1 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLSDFo3uefkViQiBE1boD4E1lkT-L0tval",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוסיקה 2 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLqf3vdDTch5eIprOE5UW22JYVeF2H3DZQ",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 3 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL2BiE_4h8Tpx5gH-aLL2fPHEDIQuNdOO7",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו ככה אני מכנה מוסיקה 4 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/playlist? list = PLC134EF07843F8E12 ",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני קורא מוסיקה Vol.5 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL0F21A53AF61D1FB7",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני קורא מוסיקה Vol.6 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL469DC54E90251585",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוסיקה 7 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL6Z-l9iL9V02f4s7eTwOOHLICG_pMp-bi",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 8 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL2BiE_4h8TpzglEey9QQK56Pk_kc0D_Ll",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני קורא מוסיקה Vol.9 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLAAB55DE564DDB852",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 10 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLGQ0UcnwJRN0vlWtPCvCddvpVv-_RJXik",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני מכנה מוסיקה 11 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLe_aExlm6LzI-bHdvaznqY9HaN0uccsWY",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני קורא מוסיקה Vol.12 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLDouWbMQEftHsFyHSBua-RZLFsx--Cu4U",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוסיקה 13 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLP1Y3xiNAKkuhumMQUsCZocF-SaS7uIAC",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 14 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL2BiE_4h8TpwA_Vs7CmADdM8TWsnmH9L8",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני מכנה מוסיקה 15 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLsqB7ljSBkucly4zjjGca9PUDCvrdd4F1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני קורא מוסיקה 16 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLP1Y3xiNAKkug6YZSWuszc3nrXMxImP0T",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 17 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLGQ0UcnwJRN2YFTPvcFdlEqPk2X50EtsC",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 18 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLsqB7ljSBkudm8Kc21ML3S8Ywwm8POK_n",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 19 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLGQ0UcnwJRN3nlqZfg3GzdnJRu7tXbDvP",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 20 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLP1Y3xiNAKkvYyHd7bmpd0B8gHTxvcYdL",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוסיקה 21 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLP1Y3xiNAKktUOg36k5y3pOnHh9gmoXsn",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 22 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLU2xNh0BeCUhEVLj3S78WNag9O-Hpm8ad",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 23 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLsqB7ljSBkufEHqSjQJmedoixNkWNtQBO",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני קורא מוסיקה Vol.24 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLDouWbMQEftFLmCbJNnxBqo925x89tJci",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 25 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLsqB7ljSBkuexkNUk-eaT0nS9KAZPGMD7",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 26 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLsqB7ljSBkuesJ07Bxz6eiLcIaIz7xYXv",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 27 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLsqB7ljSBkuecopwcuVGcYAJO4qvz3XA3",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 28 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLsqB7ljSBkufIxPcOdmwnxGfSRZgDGOe3",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 29 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLsqB7ljSBkucC3zgKZF3S4EiZ45PUmx-",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! כרך 30 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLDouWbMQEftEEeKB6GcLaDQbypvob4e10",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 31 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLsqB7ljSBkuevnNzpL3R_p6BEV_u1r3aZ",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 32 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLsqB7ljSBkudmCDLFhy2slnXN3gVUuGrm",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 33 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLsqB7ljSBkud2zZR9oVu2XGjZ8aDNlIVX",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 34 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLsqB7ljSBkufvOUAC7Wbr5_Ik_XsnjD_X",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 35 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLsqB7ljSBkucOpSfwBvSGo-oNiGJ3ALJi",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 36 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLsqB7ljSBkufqYFkLc4cBF6CkHzDBxnYx",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 37 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLDouWbMQEftEcdNjhvM5YeVvXSl9nxOaU",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 38 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLsqB7ljSBkuex2YFNUhqHTEPU4PXMz6Gz",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 39 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLsqB7ljSBkueDzyERVqcAdh2C-aiTmBXY",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני מתקשר למוזיקה 40 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL1h8do6DyqVMWIR4s3ppNF64_M0y42wW2",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 41 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLsqB7ljSBkuc7rHY6_l1khV-rG_Tie81e",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 42 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLsqB7ljSBkufUxVPOQxyTkistak74Si_S",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! כרך 43 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLDouWbMQEftHJSvaRvBzvFZ4S34kucnwl",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 44 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLsqB7ljSBkuehTugfSUFkeXFGbwKBcYnu",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 45 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLsqB7ljSBkueLsTNOL9vMM9QX3Vnrz-yn",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 46 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLDUAmuW0s8Whc9NXMvEtO5jFynx43OBLo",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 47 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLDouWbMQEftFtfaMjEM-9IjipNjw7qJ5W",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני מתקשר למוזיקה 48 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL1h8do6DyqVOBo4p_hK90IMfCIPcFQ3dx",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני קורא מוסיקה Vol.49 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLxniG6aRxGSsg3ZuNKTs7dE5VWNBche0D",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא מוסיקה! 51 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLhUnYSiS17hw156nLAPgoULF3Mq7_z6K-",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 52 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLGQ0UcnwJRN1i1peiUpidY8gOl6u7dGbY",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 53 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLGQ0UcnwJRN0AgPw0IWosO6eyHCmlgOjx",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 54 [/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLGQ0UcnwJRN3GZ-1DvWtyVXI_wP-XitwI",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא מוסיקה! 56 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLhUnYSiS17hzI0c55YCNUREsg_QLem0D2",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני אאהב מוזיקה 57 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL1h8do6DyqVNHVVtloq2-cOWnuWtAX87w",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 58 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLGQ0UcnwJRN2AnC0Fe49aa7Lq-QILORYh",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 59 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL1F0D80E99F7850E5",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא מוסיקה! 60 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLhUnYSiS17hxqroAmcTp0rPZlvjlSOKQ-",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! כרך 61 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLDouWbMQEftGZPWsKV2-J1Nb-bnnP1kDt",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני מתקשר למוזיקה 62[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLDouWbMQEftEFihO_LZMovLip0mVz0Fg3",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! כרך 63 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLDouWbMQEftGksuKJ-MJ8i2WwtwH-DyVe",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 64 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLDB9B7A7906FAFAB8",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני מתקשר למוזיקה 65 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL_34_m4eTlaOh7AX4GJRnnxKgJ5n9_V-M",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! כרך א  66 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLDouWbMQEftFvmLqnvKo-Svl6QNXaD4ac",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני קורא מוסיקה 67 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLgXn-x6PNSy0QqokVgysvrcN_99cnlK1W",35,art + 'NOWMUSIC.png')	
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוסיקה 68 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLgXn-x6PNSy3zxCaW4I9zxJpoNGm97dUK",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה אני קורא מוזיקה 69 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL_34_m4eTlaP6n2tYDBKamuvoQDo89a97",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא מוסיקה! 70 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLfajXyIbTpnHOAqRdvINIq2ak-lFiEJvw",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא מוסיקה! 71 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLfajXyIbTpnHWjIRCcKyLcBorqLBnjPxc",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא מוזיקה 72 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL_34_m4eTlaMoYI8LghIOjui2Tr8rukHp",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא מוסיקה! 73 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLjvJyxqOmFBJFZ8kMlpTIG63jCFwi_-cu",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני קורא מוסיקה 74 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLDouWbMQEftHqrKjdu7cFSACIudT2n5Il",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני קורא מוסיקה 75 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLjvJyxqOmFBIRjjgW0IQgRfh3cfAgANsS",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני קורא מוסיקה 76 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLDouWbMQEftHiTge92lMQFgbNVUCBlP8E",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא מוזיקה 77 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLziBTZqySBRFOFOwbSuPn4GtockoGot7k",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 78 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL6CDBDD2A3C0D55A5",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא מוסיקה! 79 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLjvJyxqOmFBLVpyCD38x8RkEaYtETiBcR",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוסיקה 80 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLBB7D0AF873F8FAEA",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 81 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL8FA9A7569EBB5E4A",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 82 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLoDgQlTbBQzYPrbsgmAJcDoD9Y33XhNJo",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני מתקשר למוזיקה 83 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL_34_m4eTlaOeNd6fP9MspKqh9ksDiNtm",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 84 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLwyQmbD4WPl9s1rHOfSSKUj8a86HRLUCA",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 85 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLlhDgn0Cytc26XrU4x3JDhXb9dxyt2DEa",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוסיקה 86 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLDg9kwdnXsO-sGrCANOR5gb44MLhLD1Er",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוסיקה 87 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLRmc7JLx8IJKOccrdanLLQG1s0FTaHGKH",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני מתקשר למוזיקה 88 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL_34_m4eTlaPzdgA9RG_BlIImsUwCVkzy",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא מוסיקה! 89 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL_34_m4eTlaOtJMirQzXvOoAwdechWbhF",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא מוסיקה! 90 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL_34_m4eTlaNHt6GM5dOnraJ2zdE4R2Z_",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא מוסיקה! 91 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL_34_m4eTlaMf-42RHro2x2UVMHNEkLvD",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא למוזיקה 92 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL_34_m4eTlaOFcXryY7OFbYGtK5Y1JoIa",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא מוסיקה! 93 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL_34_m4eTlaN5Dj1kIzrJMX95HRBLqeQr",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא מוסיקה! 94 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL_34_m4eTlaO0auWQxAH__sUTfRidOQZW",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא מוסיקה! 95 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/NOW לזה אני קורא המנונים של המפלגה ",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא מוסיקה! 96 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLJyQ4LyHbaraIkU1z9RzBLS2kWqAoQXH0",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא מוסיקה! עכשיו 97 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL_34_m4eTlaPorC89EUOQxwhXeZxd-Hc7",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא מוסיקה! 98 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLJyQ4LyHbarYfhbtEaTk4xj9CGRlylq6I",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא מוסיקה! 99 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLAd5X7u2hj3dRVSJz4mrcRxfrbCZ-E4iN",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו ככה אני מכנה מוסיקה 100 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLLZStkUkKPlVCF5pqz7Ztx8lXsTpGbIf6",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא מוסיקה! 101 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL_34_m4eTlaP8vMmdKKQpo4pm0efcwkxc",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוסיקה 102 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLfWOuLCdH-1dCXUN2WvV6mUiTXRpr5VmI",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא מוסיקה! 103 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLcn2SuWDLcXDkhAclaScxjgWqW6KHiv_m",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא מוסיקה! 104 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLhV4RKTkP5JQRIjQUPM5Ndr_xuF7gCF6h",35,art + 'NOWMUSIC.png')	
        addDir3('[COLOR aqua]עכשיו זה מה שאני מכנה פופ [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL_34_m4eTlaNQBMQYxfxQLN7eUkIKP66y",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני קוראת 60s [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL2BiE_4h8TpwWwKe3i_c4pnPshJktXC92",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני מכנה שנות ה -70 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLhXCO9UQq4zoIJY4qa1UA_WQWuwS-y2bc",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני מכנה שנות השמונים [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL_34_m4eTlaMgClOUihGU5EKM0md93FCN",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני מכנה שנות ה -90 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL_34_m4eTlaOrcFRHD9mG4zUilcXQS8uB",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני קוראת ה- 00 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLsdPA0A_fKLmuHNuafb76kecjHqeGoBLs",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]VA - עכשיו זה מה שאני מכנה מסיבת קיץ 2019 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLCo9rIUIbahty3bDn2cUeK_fU6sYrmWnF",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה רגאיי [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL2BiE_4h8TpwJLR--E3-Fco9BRmEH0oq1",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני מכנה המאה ה -21 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL_34_m4eTlaPLkaa4gLSJsWm86Z0H8i_U",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מדינה (2017) [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL2BiE_4h8TpwCSkzXEntUnMb2K8Sfl8q3",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]VA - עכשיו זה מה שאני מכנה מסיבת קיץ 2019 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLCo9rIUIbahty3bDn2cUeK_fU6sYrmWnF",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה רוק קלאסי (2015) [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL2BiE_4h8Tpw-9ppd1cagjhcsa6nuOByP",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוזיקה! 1985 (כעת סדרת יום השנה העשירית) [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLsqB7ljSBkufwGaYG3NFmCK9Z9dp86vb9",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא המנונים של המפלגה [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL_34_m4eTlaN0b1Wntb0io2m_j0Bbe1Id",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו: 100 צפיות: Sing-a-Long [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL2BiE_4h8Tpx3Ez_UdMt-n6WeamFX3bqs",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו 100 צפיות לסרטים [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLmMGqezX7LHW2HGwL8h3UpLtPxciLf9hO",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו: 100 צפיות: שירי מכוניות [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL2BiE_4h8Tpx-eImS3x2BYsxSIwqWfl7x",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]VA - NU 100 צפיות שנשכחו שנות ה -80 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLh2ZThx4HC6WSLzfH8weBzCpzCLUNDGl4",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]VA - NU 100 צפיות שנשכחו שנות ה -90 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLCo9rIUIbahs3c8qsdSzflX7xstAoJg3N",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו: 100 צפיות: משטרי כוח [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL2BiE_4h8Tpy37yKc8FP4HpIV6ZyR2eaZ",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו: 100 צפיות: חג המולד [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL2BiE_4h8Tpz00pWE68zD_Ag9PO9o903s",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה רוקנרול [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL2BiE_4h8TpzdcbEeANYQDnvsfXo0HHL5",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני קורא שירי אהבה (2018) [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL2BiE_4h8Tpz3VMIcAnTzaX5rpsvtIczX",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני קורא קל [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL2BiE_4h8Tpwr3V1CEDhNeKxEm6PLQwSe",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא דיסני 2017 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLhXCO9UQq4zosccGMdyCinFpdHvSE9Kvu",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו מה שאני קורא לאבא רוק [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLW_NpxKH1uD_qdX2gbvTsHVzYKvEQXGh7",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]VA - עכשיו זה מה שאני מכנה מסיבת קיץ 2019 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLCo9rIUIbahty3bDn2cUeK_fU6sYrmWnF",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני קורא לו רמיקס [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLhXCO9UQq4zocy64nFXan7WiscyJymBDH",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה אולד סקול [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL2BiE_4h8TpyHnumViPWg0_enDQRotJv4",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה נשמה קלאסית [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL2BiE_4h8TpzvN8xfhOGPUw-SAcDa2-Ex",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו זה מה שאני מכנה זמר [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL_34_m4eTlaNh63gxFpUwwAROXj5V3AX8",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני קוראת ליל כל הקדושים [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLGQ0UcnwJRN3rMvLhns856JQoxtQtYIgf",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני קוראת אני רוצה רוק [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLGQ0UcnwJRN3rRVKwiNLTc1rAVrWSGEUp",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני קוראת מספר 1 (2015) [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLGQ0UcnwJRN2ZlwzY369IQP__M_bGRp1E",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה מוטאון [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLGQ0UcnwJRN0sYMpb9cKV9ct_h1Ct1YP0",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני מכנה גל חדש 80s [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLGQ0UcnwJRN03-63KDFnCiKaYLJsszOi_",35,art + 'NOWMUSIC.png')
        addDir3('[COLOR aqua]עכשיו לזה אני קוראת Country Vol. 3 [/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLGQ0UcnwJRN0sCK_zH_BoG1nd4Y_3pmJb",35,art + 'NOWMUSIC.png')

def Su():
        addDir3('[COLOR aqua]פלייליסט סטנדאפ [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=פלייליסט סטנדאפ&url=www",35,art + 'su.jpg')
        addDir3('[COLOR aqua]נאור ציון [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=נאור ציון&url=www",35,art + 'su.jpg')	 
        addDir3('[COLOR aqua]הצגות מרוקאיות [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=הצגות מרוקאיות&url=www",35,art + 'su.jpg')
        addDir3('[COLOR aqua]מני עוזרי [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=מני עוזרי&url=www",35,art + 'su.jpg')
        addDir3('[COLOR aqua]בן בן ברוך [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=בן בן ברוך&url=www",35,art + 'su.jpg')
        addDir3('[COLOR aqua]ישראל קטורזה [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=ישראל קטורזה&url=www",35,art + 'su.jpg')
        addDir3('[COLOR aqua]שלום אסייג [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=שלום אסייג&url=www",35,art + 'su.jpg')
        addDir3('[COLOR aqua]יוסי פנסו [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=יוסי פנסו&url=www",35,art + 'su.jpg')
        addDir3('[COLOR aqua]יוסי גבני [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=יוסי גבני&url=www",35,art + 'su.jpg')
        addDir3('[COLOR aqua]אלי ומריאנו [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=אלי ומריאנו&url=www",35,art + 'su.jpg')
        
def vevo():

        addDir3('[COLORred]VEVO[/COLOR] [COLORwhite]US Kanal[/COLOR]',"plugin://plugin.video.MyYoutube/user/VEVO/",35,'http://sgkodi.de/VEVO/Daten/VevoUS.png')
        addDir3('[COLORred]VEVO[/COLOR] [COLORwhite]DE Kanal[/COLOR]',"plugin://plugin.video.MyYoutube/user/deutschlandVEVO/",35,'http://sgkodi.de/VEVO/Daten/VevoDE.png')
        addDir3('[COLORred]VEVO[/COLOR] [COLORwhite]UK Kanal[/COLOR]',"plugin://plugin.video.MyYoutube/user/VEVOUK/",35,'http://sgkodi.de/VEVO/Daten/VevoUK.png')
        addDir3('[COLORred]VEVO[/COLOR] [COLORwhite]FR Kanal[/COLOR]',"plugin://plugin.video.MyYoutube/user/VevoFranceOfficiel/",35,'http://sgkodi.de/VEVO/Daten/VevoFR.png')
        addDir3('[COLORred]VEVO[/COLOR] [COLORwhite]NL Kanal[/COLOR]',"plugin://plugin.video.MyYoutube/user/VEVONederland/",35,'http://sgkodi.de/VEVO/Daten/VevoNL.png')
        addDir3('[COLORred]VEVO[/COLOR] [COLORwhite]ES Kanal[/COLOR]',"plugin://plugin.video.MyYoutube/user/VEVOEspana/",35,'http://sgkodi.de/VEVO/Daten/VevoES.png')
        addDir3('[COLORred]VEVO[/COLOR] [COLORwhite]IT Kanal[/COLOR]',"plugin://plugin.video.MyYoutube/user/VEVOIT/",35,'http://sgkodi.de/VEVO/Daten/VevoIT.png')
        addDir3('[COLORred]VEVO[/COLOR] [COLORwhite]PL Kanal[/COLOR]',"plugin://plugin.video.MyYoutube/user/VEVOPolska/",35,'http://sgkodi.de/VEVO/Daten/VevoPL.png')
        addDir3('[COLORred][B]What´s Hot[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFu8MzzbNVtUvHs0cQ_gZ03m/",35,'http://sgkodi.de/VEVO/Daten/VevoCharts.png')
        addDir3('[COLORred][B]Hot this Week[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFtx71frwf8cxXXhW0YEG3xF/",35,'http://sgkodi.de/VEVO/Daten/VevoCharts.png')
        addDir3('[COLORred][B]Top 20[/B][/COLOR] [COLORwhite]Videos in the US[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFuTq2RLA0DhevkZYp954-k4/",35,'http://sgkodi.de/VEVO/Daten/VevoCharts.png')
        addDir3('[COLORred][B]Top 20[/B][/COLOR] [COLORwhite]New Artist Videos in the US[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFuHBYGM1iEL6OUyiA4BsvrZ/",35,'http://sgkodi.de/VEVO/Daten/VevoCharts.png')
        addDir3('[COLORred][B]Top 10[/B][/COLOR] [COLORwhite]Pop Videos[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFv8JKRhQtU4elLD73E3kvvo/",35,'http://sgkodi.de/VEVO/Daten/VevoCharts.png')
        addDir3('[COLORred][B]Top 10[/B][/COLOR] [COLORwhite]Alternative Videos[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFvHFiFhJhaqyRAHkX7ewSRk/",35,'http://sgkodi.de/VEVO/Daten/VevoCharts.png')
        addDir3('[COLORred][B]Top 10[/B][/COLOR] [COLORwhite]Alternative Videos of 2018[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFtZeu9JzS4O7m6HvGFYqhCu/",35,'http://sgkodi.de/VEVO/Daten/VevoCharts.png')
        addDir3('[COLORred][B]Top 10[/B][/COLOR] [COLORwhite]Country Videos[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFu712crop5LYYzvxm_aY4Yi/",35,'http://sgkodi.de/VEVO/Daten/VevoCharts.png')
        addDir3('[COLORred][B]Top 10[/B][/COLOR] [COLORwhite]Country Videos of 2018[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFvuDwJjlGWLjtLgIdlKW4YG/",35,'http://sgkodi.de/VEVO/Daten/VevoCharts.png')
        addDir3('[COLORred][B]Top 10[/B][/COLOR] [COLORwhite]EDM Videos[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFuVbKK_q7An7AGK_sBovNbm/",35,'http://sgkodi.de/VEVO/Daten/VevoCharts.png')
        addDir3('[COLORred][B]Top 10[/B][/COLOR] [COLORwhite]EDM Videos of 2018[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFsO6z9aLV540RcbIQSDsbMP/",35,'http://sgkodi.de/VEVO/Daten/VevoCharts.png')
        addDir3('[COLORred][B]Top 10[/B][/COLOR] [COLORwhite]Hip-Hop Videos[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFs8J2ySTyV8aW9ZDwT-f2KE/",35,'http://sgkodi.de/VEVO/Daten/VevoCharts.png')
        addDir3('[COLORred][B]Top 10[/B][/COLOR] [COLORwhite]Hip-Hop Videos of 2018[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFtxXjd3Klm7cDmqXCxyY9b0/",35,'http://sgkodi.de/VEVO/Daten/VevoCharts.png')
        addDir3('[COLORred][B]Top 10[/B][/COLOR] [COLORwhite]Indie Videos[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFtJHsp-bsHZH3jxLa08rDya/",35,'http://sgkodi.de/VEVO/Daten/VevoCharts.png')
        addDir3('[COLORred][B]Top 10[/B][/COLOR] [COLORwhite]Indie Videos of 2018[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFuEOGsquQgnbxQQ6d9W2aKu/",35,'http://sgkodi.de/VEVO/Daten/VevoCharts.png')
        addDir3('[COLORred][B]Top 10[/B][/COLOR] [COLORwhite]Latin Videos[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFuz1RSdd0ua9EHdQSJecALm/",35,'http://sgkodi.de/VEVO/Daten/VevoCharts.png')
        addDir3('[COLORred][B]Top 10[/B][/COLOR] [COLORwhite]Latin Videos of 2018[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFuVuLIQoV8aOHArPfZbxLV2/",35,'http://sgkodi.de/VEVO/Daten/VevoCharts.png')
        addDir3('[COLORred][B]Top 10[/B][/COLOR] [COLORwhite]Metal Videos[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFunVZhgJ9IREhr73C2amsLz/",35,'http://sgkodi.de/VEVO/Daten/VevoCharts.png')
        addDir3('[COLORred][B]Top 10[/B][/COLOR] [COLORwhite]Metal Videos of 2018[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFvuqteD3p7vAgUIyPbGBjGK/",35,'http://sgkodi.de/VEVO/Daten/VevoCharts.png')
        addDir3('[COLORred][B]Top 10[/B][/COLOR] [COLORwhite]R&B Videos[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFuJMY7OjmKmhtOEcegCY6C6/",35,'http://sgkodi.de/VEVO/Daten/VevoCharts.png')
        addDir3('[COLORred][B]Top 10[/B][/COLOR] [COLORwhite]R&B Videos of 2018[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFvvFxqFhboitegq_lVPgb18/",35,'http://sgkodi.de/VEVO/Daten/VevoCharts.png')
        addDir3('[COLORred][B]Top 10[/B][/COLOR] [COLORwhite]Rock Videos[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFuvha_x5OEnmpYpfK-AtuTp/",35,'http://sgkodi.de/VEVO/Daten/VevoCharts.png')
        addDir3('[COLORred][B]Top 10[/B][/COLOR] [COLORwhite]Rock Videos of 2018[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFudLBYO_ZSU-8Rjv29JIYh_/",35,'http://sgkodi.de/VEVO/Daten/VevoCharts.png')
        addDir3('[COLORwhite]All New[/COLOR] [COLORred][B]ALTERNATIVE[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFsez6cjXAxHTruW0jteUHQk/",35,'http://sgkodi.de/VEVO/Daten/VevoNewGenre.png')
        addDir3('[COLORwhite]Kickin´ New[/COLOR] [COLORred][B]COUNTRY[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFtUu1HrxtZ4hv8nNLKiRseN/",35,'http://sgkodi.de/VEVO/Daten/VevoNewGenre.png')
        addDir3('[COLORwhite]New[/COLOR] [COLORred][B]EDM[/B][/COLOR] [COLORwhite]Beats[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFvBK4oJZylITMXRxAPJvbr8/",35,'http://sgkodi.de/VEVO/Daten/VevoNewGenre.png')
        addDir3('[COLORwhite]Hot New[/COLOR] [COLORred][B]HIP-HOP[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFv-V7FvZP-PWuE-1x2Deqqe/",35,'http://sgkodi.de/VEVO/Daten/VevoNewGenre.png')
        addDir3('[COLORwhite]All New[/COLOR] [COLORred][B]INDIE[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFvXYAx7RjMQd6h7_URtCwoK/",35,'http://sgkodi.de/VEVO/Daten/VevoNewGenre.png')
        addDir3('[COLORwhite]Nuevo Pop[/COLOR] [COLORred][B]LATINO[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFtps6SqgQYfMoMk557f2VAk/",35,'http://sgkodi.de/VEVO/Daten/VevoNewGenre.png')
        addDir3('[COLORwhite]Malicious New[/COLOR] [COLORred][B]METAL[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFuErwY_it1HO20Da-13FfNz/",35,'http://sgkodi.de/VEVO/Daten/VevoNewGenre.png')
        addDir3('[COLORwhite]Nuevo Regional[/COLOR] [COLORred][B]MEXICANO[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFun6Q71-e4lgwHigs0EbSfd/",35,'http://sgkodi.de/VEVO/Daten/VevoNewGenre.png')
        addDir3('[COLORwhite]New[/COLOR] [COLORred][B]R&B[/B][/COLOR] [COLORwhite]Vibes[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFupYyrDriLYu3ba9oYMUJ65/",35,'http://sgkodi.de/VEVO/Daten/VevoNewGenre.png')
        addDir3('[COLORwhite]Rugged New[/COLOR] [COLORred][B]ROCK[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFvrS_oXmav-as9fy3lt1i34/",35,'http://sgkodi.de/VEVO/Daten/VevoNewGenre.png')
        addDir3('[COLORwhite]Brand New[/COLOR] [COLORred][B]POP[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFt2TyOofWG0XwA8IDC8SGIN/",35,'http://sgkodi.de/VEVO/Daten/VevoNewGenre.png')
        addDir3('[COLORwhite]Los Rompe Tarima[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFvRr9wRh1o8oeIpkPUdAjV6/",35,'http://sgkodi.de/VEVO/Daten/VevoNewGenre.png')
        addDir3('[COLORred][B]Fresh Music[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFuiE7QFMzvaTuhXleCaAc52/",35,'http://sgkodi.de/VEVO/Daten/VevoGenre.png')
        addDir3('[COLORred][B]Afro Beat[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFufJOabZGuV93QVdZzouWyc/",35,'http://sgkodi.de/VEVO/Daten/VevoGenre.png')
        addDir3('[COLORred][B]Dancehall Delights[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFu9k1UqFdWffUtMyeNbwAYw/",35,'http://sgkodi.de/VEVO/Daten/VevoGenre.png')
        addDir3('[COLORred][B]Dance Pop Hits[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFtynbPGh-GPxTsCGAW35GgW/",35,'http://sgkodi.de/VEVO/Daten/VevoGenre.png')
        addDir3('[COLORred][B]Dad Rock[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFvsOFNUeME8BSbiH_PwQGOK/",35,'http://sgkodi.de/VEVO/Daten/VevoGenre.png')
        addDir3('[COLORred][B]Electro Alt/Indie[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFtWjRRwOK_D_RO2kv0yU3mx/",35,'http://sgkodi.de/VEVO/Daten/VevoGenre.png')
        addDir3('[COLORred][B]Extrem Metal[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFv-fsLsz-1RaVdKeBPp5o28/",35,'http://sgkodi.de/VEVO/Daten/VevoGenre.png')
        addDir3('[COLORred][B]Grown Folk R&B[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFtgtiMbBi64rRudSIMFg-d8/",35,'http://sgkodi.de/VEVO/Daten/VevoGenre.png')
        addDir3('[COLORred][B]Heavy Spitters[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFs14BsetzaXkYUo-Nx6WRG7/",35,'http://sgkodi.de/VEVO/Daten/VevoGenre.png')
        addDir3('[COLORred][B]Hear it Now: Country![/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFtU-Y58frRg2nENqyZLYuzj/",35,'http://sgkodi.de/VEVO/Daten/VevoGenre.png')
        addDir3('[COLORred][B]Indie Pop[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFtG6Vx47mZFpr56Wfty30FJ/",35,'http://sgkodi.de/VEVO/Daten/VevoGenre.png')
        addDir3('[COLORred][B]Island Vibes[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFtU-Y58frRg2nENqyZLYuzj/",35,'http://sgkodi.de/VEVO/Daten/VevoGenre.png')
        addDir3('[COLORred][B]Latin Trendsetters[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFsfDtWiBJ4j7YyDINWIiHpq/",35,'http://sgkodi.de/VEVO/Daten/VevoGenre.png')
        addDir3('[COLORred][B]Nuevo Sabor Tropical[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFtVmU7eZa84X1s7EmaUaeI5/",35,'http://sgkodi.de/VEVO/Daten/VevoGenre.png')
        addDir3('[COLORred][B]Old 2 the New[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFuF8lJd_OZwQsWMrKMCEgIB/",35,'http://sgkodi.de/VEVO/Daten/VevoGenre.png')
        addDir3('[COLORred][B]Organic Alt/Indie[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFsrB_M5iGi2ww3vCTVVyjZW/",35,'http://sgkodi.de/VEVO/Daten/VevoGenre.png')
        addDir3('[COLORred][B]Pure Pop[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFvKRiSw23TNP68fIrUblrWH/",35,'http://sgkodi.de/VEVO/Daten/VevoGenre.png')
        addDir3('[COLORred][B]Pop Teen[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFvxjdtw3Iy4LsyhXeCt_P44/",35,'http://sgkodi.de/VEVO/Daten/VevoGenre.png')
        addDir3('[COLORred][B]Riddim Nation[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFvF0nBYvE8vKSlWsGssAydq/",35,'http://sgkodi.de/VEVO/Daten/VevoGenre.png')
        addDir3('[COLORred][B]Roots Reggae[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFtd2_FhMAWoiMW0r5X-Sveo/",35,'http://sgkodi.de/VEVO/Daten/VevoGenre.png')
        addDir3('[COLORred][B]Soca Hits[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFsmprDH-i2yeq1z8OwiFzDu/",35,'http://sgkodi.de/VEVO/Daten/VevoGenre.png')
        addDir3('[COLORred][B]Teen Hip-Hop and R&B[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFvHLl17Tm2-fyhwDBnecahx/",35,'http://sgkodi.de/VEVO/Daten/VevoGenre.png')
        addDir3('[COLORred][B]Trap Stars[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFuSozSTGO7dibrhaDg6qRq2/",35,'http://sgkodi.de/VEVO/Daten/VevoGenre.png')
        addDir3('[COLORred][B]This One s For The Girls[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFspwjv96-6Vanlik6v2vRz0/",35,'http://sgkodi.de/VEVO/Daten/VevoGenre.png')
        addDir3('[COLORred][B]UK Represent[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFsi4M0yYHy4KL-UBVfCmq3G/",35,'http://sgkodi.de/VEVO/Daten/VevoGenre.png')
        addDir3('[COLORwhite]Love it Live:[/COLOR] [COLORred][B]COUNTRY[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFuLQIXnp6BrHTYaGF0w4dY-/",35,'http://sgkodi.de/VEVO/Daten/VevoLive.png')
        addDir3('[COLORwhite]Love it Live:[/COLOR] [COLORred][B]INDIE[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFtVyHzilNNbDeI5UkWa1hZ8/",35,'http://sgkodi.de/VEVO/Daten/VevoLive.png')
        addDir3('[COLORwhite]Love it Live:[/COLOR] [COLORred][B]HIP-HOP[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFvz5YcFommSYF-iCrZj6nhE/",35,'http://sgkodi.de/VEVO/Daten/VevoLive.png')
        addDir3('[COLORwhite]Love it Live:[/COLOR] [COLORred][B]METAL[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFvSPe7p4oCziGKb8yMm2D8a/",35,'http://sgkodi.de/VEVO/Daten/VevoLive.png')
        addDir3('[COLORwhite]Love it Live:[/COLOR] [COLORred][B]R&B[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFtKOKmHyEgagZOOsed6bLGp/",35,'http://sgkodi.de/VEVO/Daten/VevoLive.png')
        addDir3('[COLORwhite]Love it Live:[/COLOR] [COLORred][B]ROCK[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFseh1MIXV1gsrU_h_1Pc_mo/",35,'http://sgkodi.de/VEVO/Daten/VevoLive.png')
        addDir3('[COLORwhite]Love it Live:[/COLOR] [COLORred][B]POP[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFseUoJd-4NUu042RuQ0PUfi/",35,'http://sgkodi.de/VEVO/Daten/VevoLive.png')
        addDir3('[COLORwhite]Live Performances[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFvtAbH4_z7IEaSYAHrNW8Wo/",35,'http://sgkodi.de/VEVO/Daten/VevoLive.png')
        addDir3('[COLORwhite]DSCVR - All Live Performances[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PLfpWqf0Dq32_xD4HttGXuLkM-QfSoWBvW/",35,'http://sgkodi.de/VEVO/Daten/VevoLive.png')
        addDir3('[COLORwhite]LiveSets @ The Great Escape Festival 2018[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL7KLwyJCC7QyKJoYKgfo8l7VkrkKkyjRq/",35,'http://sgkodi.de/VEVO/Daten/VevoLive.png')
        addDir3('[COLORred][B]COUNTRY[/B][/COLOR] [COLORwhite]Party Playlist[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFv8hIun4ujGj0RF66Ogb-vf/",35,'http://sgkodi.de/VEVO/Daten/VevoMoods.png')
        addDir3('[COLORred][B]EDM[/B][/COLOR] [COLORwhite]Party Playlist[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFvxJlU0eH71A4nkP1O1HsUo/",35,'http://sgkodi.de/VEVO/Daten/VevoMoods.png')
        addDir3('[COLORred][B]HIP-HOP[/B][/COLOR] [COLORwhite]In the Gym[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFtZk0J0MsWkajC3139aQ2wy/",35,'http://sgkodi.de/VEVO/Daten/VevoMoods.png')
        addDir3('[COLORred][B]HIT[/B][/COLOR] [COLORwhite]the Gym[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFuXtvZQsoJYw3PTZjCN8CCZ/",35,'http://sgkodi.de/VEVO/Daten/VevoMoods.png')
        addDir3('[COLORred][B]R&B[/B][/COLOR] [COLORwhite]Party Playlist[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFv4jC7qf3u38KNpvv2SOkJR/",35,'http://sgkodi.de/VEVO/Daten/VevoMoods.png')
        addDir3('[COLORred][B]ROMANCE[/B][/COLOR] [COLORwhite]Rockero[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFs5owDVo-lHb6QgCA0ZL3Jk/",35,'http://sgkodi.de/VEVO/Daten/VevoMoods.png')
        addDir3('[COLORred][B]POP[/B][/COLOR] [COLORwhite]Party Playlist[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFvz9SFKucMbmBt-SnZtokVY/",35,'http://sgkodi.de/VEVO/Daten/VevoMoods.png')
        addDir3('[COLORred][B]Pop Outta Bed[/B][/COLOR] [COLORwhite]- Music With Your Coffee[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFukDT2wdYkXwSZqg8HsH73q/",35,'http://sgkodi.de/VEVO/Daten/VevoMoods.png')
        addDir3('[COLORred][B]The Breakfast Club[/B][/COLOR] [COLORwhite]- Morning Music[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFtfwzVHdLt_nJwt9Iv7qoD7/",35,'http://sgkodi.de/VEVO/Daten/VevoMoods.png')
        addDir3('[COLORred][B]CHILLOUT[/B][/COLOR] [COLORwhite]- Lazy Morning[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFtROKI2bqQdOGNWgmRWsKNv/",35,'http://sgkodi.de/VEVO/Daten/VevoMoods.png')
        addDir3('[COLORred][B]Mellow Out[/B][/COLOR] [COLORwhite]- Low Key Afternoon[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFul67nuDgHNojFAt1IPjiIC/",35,'http://sgkodi.de/VEVO/Daten/VevoMoods.png')
        addDir3('[COLORred][B]Midnight Chill[/B][/COLOR] [COLORwhite]- Sleepy Head[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFugJqfmiNpXMRop_swcsXHZ/",35,'http://sgkodi.de/VEVO/Daten/VevoMoods.png')
        addDir3('[COLORred][B]Crushin On You[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFuo2kolkJmA_Th0sUC_mLtW/",35,'http://sgkodi.de/VEVO/Daten/VevoMoods.png')
        addDir3('[COLORred][B]Hoy Se Bebe[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFs2is-Fji_wHWtfO_-Rko2x/",35,'http://sgkodi.de/VEVO/Daten/VevoMoods.png')
        addDir3('[COLORred][B]Late Registration[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFtvZUAUKlYLfS74PyTgJqo4/",35,'http://sgkodi.de/VEVO/Daten/VevoMoods.png')
        addDir3('[COLORwhite]Incoming[/COLOR] [COLORred][B]ALTERNATIVE[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFt_H0qxBMqqQonj83vaKDbF/",35,'http://sgkodi.de/VEVO/Daten/VevoPlaylist.png')
        addDir3('[COLORwhite]Incoming[/COLOR] [COLORred][B]COUNTRY[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFtftz_53w-VnY9kYz8bC66w/",35,'http://sgkodi.de/VEVO/Daten/VevoPlaylist.png')
        addDir3('[COLORwhite]Incoming[/COLOR] [COLORred][B]EDM[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFubH8RSGxdBDwhf7g4C60Vy/",35,'http://sgkodi.de/VEVO/Daten/VevoPlaylist.png')
        addDir3('[COLORwhite]Incoming[/COLOR] [COLORred][B]HIP-HOP[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFvN_9mCk7b8h33NrlxiPTx1/",35,'http://sgkodi.de/VEVO/Daten/VevoPlaylist.png')
        addDir3('[COLORwhite]Incoming[/COLOR] [COLORred][B]INDIE[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFsFhx7JRa8pbMVIExlLYNah/",35,'http://sgkodi.de/VEVO/Daten/VevoPlaylist.png')
        addDir3('[COLORwhite]Incoming[/COLOR] [COLORred][B]METAL[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFuFHvOwsadSCn3NKeuNIh0B/",35,'http://sgkodi.de/VEVO/Daten/VevoPlaylist.png')
        addDir3('[COLORwhite]Incoming[/COLOR] [COLORred][B]R&B[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFvSkAtT0DUEffzC5mi7hUOl/",35,'http://sgkodi.de/VEVO/Daten/VevoPlaylist.png')
        addDir3('[COLORwhite]Incoming[/COLOR] [COLORred][B]ROCK[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFtva3fYalscaRiMVc9C6EES/",35,'http://sgkodi.de/VEVO/Daten/VevoPlaylist.png')
        addDir3('[COLORwhite]Incoming[/COLOR] [COLORred][B]POP[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFuIC3udROGYMT_M4f39x4BW/",35,'http://sgkodi.de/VEVO/Daten/VevoPlaylist.png')
        addDir3('[COLORwhite]DSCVR[/COLOR] [COLORred][B]ALTERNATIVE[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFuZjjpuZMhh7KC-Sw6aehjA/",35,'http://sgkodi.de/VEVO/Daten/VevoDSCVR.png')
        addDir3('[COLORwhite]DSCVR[/COLOR] [COLORred][B]COUNTRY[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFs8XbSARCWThNqt5YXhCOHu/",35,'http://sgkodi.de/VEVO/Daten/VevoDSCVR.png')
        addDir3('[COLORwhite]DSCVR[/COLOR] [COLORred][B]EDM[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFsGFJ6dh8R6AExOhIYljnjp/",35,'http://sgkodi.de/VEVO/Daten/VevoDSCVR.png')
        addDir3('[COLORwhite]DSCVR[/COLOR] [COLORred][B]HIP-HOP[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFt5tsGbHhlAVX7KDM4WpMYC/",35,'http://sgkodi.de/VEVO/Daten/VevoDSCVR.png')
        addDir3('[COLORwhite]DSCVR[/COLOR] [COLORred][B]INDIE[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFuwFi1wSueeFR-7MdKn5xM-/",35,'http://sgkodi.de/VEVO/Daten/VevoDSCVR.png')
        addDir3('[COLORwhite]DSCVR[/COLOR] [COLORred][B]LATINO[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFtd5iXVx_m6tSyyJZskY3xf/",35,'http://sgkodi.de/VEVO/Daten/VevoDSCVR.png')
        addDir3('[COLORwhite]DSCVR[/COLOR] [COLORred][B]METAL[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFsl7Hqzq6VeI7rWskr4lb37/",35,'http://sgkodi.de/VEVO/Daten/VevoDSCVR.png')
        addDir3('[COLORwhite]DSCVR[/COLOR] [COLORred][B]R&B[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFvlIjnD63Q8WJdzN_Sa94kp/",35,'http://sgkodi.de/VEVO/Daten/VevoDSCVR.png')
        addDir3('[COLORwhite]DSCVR[/COLOR] [COLORred][B]ROCK[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFsQ42vFCS-PhDg--aPyh9R7/",35,'http://sgkodi.de/VEVO/Daten/VevoDSCVR.png')
        addDir3('[COLORwhite]DSCVR[/COLOR] [COLORred][B]POP[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFtbNWZwYMO7HLlH58DcVJoi/",35,'http://sgkodi.de/VEVO/Daten/VevoDSCVR.png')
        addDir3('[COLORred][B]ALTERNATIVE[/B][/COLOR] [COLORwhite]Replay[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFu2G9yrUTQaq34OGlENR7Dw/",35,'http://sgkodi.de/VEVO/Daten/VevoReplay.png')
        addDir3('[COLORred][B]COUNTRY[/B][/COLOR] [COLORwhite]Replay[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFsO4BWeXMvfFJuwXONeMRAJ/",35,'http://sgkodi.de/VEVO/Daten/VevoReplay.png')
        addDir3('[COLORred][B]EDM[/B][/COLOR] [COLORwhite]Replay[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFspK-zf2PoWqP6NJYflkM-B/",35,'http://sgkodi.de/VEVO/Daten/VevoReplay.png')
        addDir3('[COLORred][B]INDIE[/B][/COLOR] [COLORwhite]Replay[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFs5S8Hy6amKBeKuGq2CMxCv/",35,'http://sgkodi.de/VEVO/Daten/VevoReplay.png')
        addDir3('[COLORred][B]METAL[/B][/COLOR] [COLORwhite]Replay[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFvruwh6bTrU_X1Yn7aCvwtZ/",35,'http://sgkodi.de/VEVO/Daten/VevoReplay.png')
        addDir3('[COLORred][B]RAP[/B][/COLOR] [COLORwhite]Replay[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFtb-K_G-Uv-FgKNFuT2KSBW/",35,'http://sgkodi.de/VEVO/Daten/VevoReplay.png')
        addDir3('[COLORred][B]R&B[/B][/COLOR] [COLORwhite]Replay[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFvP58E91WStRnOPTxSTTgC7/",35,'http://sgkodi.de/VEVO/Daten/VevoReplay.png')
        addDir3('[COLORred][B]ROCK[/B][/COLOR] [COLORwhite]Replay[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFt8kH1xUjp9mmrUMTG3qt1I/",35,'http://sgkodi.de/VEVO/Daten/VevoReplay.png')
        addDir3('[COLORred][B]POP[/B][/COLOR] [COLORwhite]Replay[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFsuscmwmqh96nRKLrVM8BOy/",35,'http://sgkodi.de/VEVO/Daten/VevoReplay.png')
        addDir3('[COLORred][B]POP[/B][/COLOR] [COLORwhite]Mix 2018>2015[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL7KLwyJCC7QzpNciVGe-7K6ShC3MzL3vd/",35,'http://sgkodi.de/VEVO/Daten/VevoMix.png')
        addDir3('[COLORred][B]DANCE/ELECTRO[/B][/COLOR] [COLORwhite]Mix 2018>2015[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL7KLwyJCC7QyXUZLdnHDbBIjBZZSOFRKk/",35,'http://sgkodi.de/VEVO/Daten/VevoMix.png')
        addDir3('[COLORred][B]INDIE/ROCK/ALTERNATIVE[/B][/COLOR] [COLORwhite]Mix 2018>2015[/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL7KLwyJCC7Qx3UC8uj-qLIsOdd5OmkNHY/",35,'http://sgkodi.de/VEVO/Daten/VevoMix.png')
        addDir3('[COLORred][B]Interviews[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFtf0OfrhrX05vWJlddRR_AW/",35,'http://sgkodi.de/VEVO/Daten/VevoMeets.png')
        addDir3('[COLORred][B]VEVO Meets[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFvxtE1BaLe2s4EHqRxqNEdx/",35,'http://sgkodi.de/VEVO/Daten/VevoMeets.png')
        addDir3('[COLORred][B]60Seconds with...[/B][/COLOR]',"plugin://plugin.video.MyYoutube/playlist/PL9tY0BWXOZFuUNkhmRYHLQjc5wOjKNU_Z/",35,'http://sgkodi.de/VEVO/Daten/VevoMeets.png')

def vev():
        addDir3('[COLORred]VEVO[/COLOR] [COLORwhite]US Kanal[/COLOR]',"plugin://plugin.video.youtube/user/VEVO/",35,'http://sgkodi.de/VEVO/Daten/VevoUS.png')
        addDir3('[COLORred]VEVO[/COLOR] [COLORwhite]DE Kanal[/COLOR]',"plugin://plugin.video.youtube/user/deutschlandVEVO/",35,'http://sgkodi.de/VEVO/Daten/VevoDE.png')
        addDir3('[COLORred]VEVO[/COLOR] [COLORwhite]UK Kanal[/COLOR]',"plugin://plugin.video.youtube/user/VEVOUK/",35,'http://sgkodi.de/VEVO/Daten/VevoUK.png')
        addDir3('[COLORred]VEVO[/COLOR] [COLORwhite]FR Kanal[/COLOR]',"plugin://plugin.video.youtube/user/VevoFranceOfficiel/",35,'http://sgkodi.de/VEVO/Daten/VevoFR.png')
        addDir3('[COLORred]VEVO[/COLOR] [COLORwhite]NL Kanal[/COLOR]',"plugin://plugin.video.youtube/user/VEVONederland/",35,'http://sgkodi.de/VEVO/Daten/VevoNL.png')
        addDir3('[COLORred]VEVO[/COLOR] [COLORwhite]ES Kanal[/COLOR]',"plugin://plugin.video.youtube/user/VEVOEspana/",35,'http://sgkodi.de/VEVO/Daten/VevoES.png')
        addDir3('[COLORred]VEVO[/COLOR] [COLORwhite]IT Kanal[/COLOR]',"plugin://plugin.video.youtube/user/VEVOIT/",35,'http://sgkodi.de/VEVO/Daten/VevoIT.png')
        addDir3('[COLORred]VEVO[/COLOR] [COLORwhite]PL Kanal[/COLOR]',"plugin://plugin.video.youtube/user/VEVOPolska/",35,'http://sgkodi.de/VEVO/Daten/VevoPL.png')
        addDir3('[COLORred][B]What´s Hot[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFu8MzzbNVtUvHs0cQ_gZ03m/",35,'http://sgkodi.de/VEVO/Daten/VevoCharts.png')
        addDir3('[COLORred][B]Hot this Week[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFtx71frwf8cxXXhW0YEG3xF/",35,'http://sgkodi.de/VEVO/Daten/VevoCharts.png')
        addDir3('[COLORred][B]Top 20[/B][/COLOR] [COLORwhite]Videos in the US[/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFuTq2RLA0DhevkZYp954-k4/",35,'http://sgkodi.de/VEVO/Daten/VevoCharts.png')
        addDir3('[COLORred][B]Top 20[/B][/COLOR] [COLORwhite]New Artist Videos in the US[/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFuHBYGM1iEL6OUyiA4BsvrZ/",35,'http://sgkodi.de/VEVO/Daten/VevoCharts.png')
        addDir3('[COLORred][B]Top 10[/B][/COLOR] [COLORwhite]Pop Videos[/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFv8JKRhQtU4elLD73E3kvvo/",35,'http://sgkodi.de/VEVO/Daten/VevoCharts.png')
        addDir3('[COLORred][B]Top 10[/B][/COLOR] [COLORwhite]Alternative Videos[/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFvHFiFhJhaqyRAHkX7ewSRk/",35,'http://sgkodi.de/VEVO/Daten/VevoCharts.png')
        addDir3('[COLORred][B]Top 10[/B][/COLOR] [COLORwhite]Alternative Videos of 2018[/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFtZeu9JzS4O7m6HvGFYqhCu/",35,'http://sgkodi.de/VEVO/Daten/VevoCharts.png')
        addDir3('[COLORred][B]Top 10[/B][/COLOR] [COLORwhite]Country Videos[/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFu712crop5LYYzvxm_aY4Yi/",35,'http://sgkodi.de/VEVO/Daten/VevoCharts.png')
        addDir3('[COLORred][B]Top 10[/B][/COLOR] [COLORwhite]Country Videos of 2018[/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFvuDwJjlGWLjtLgIdlKW4YG/",35,'http://sgkodi.de/VEVO/Daten/VevoCharts.png')
        addDir3('[COLORred][B]Top 10[/B][/COLOR] [COLORwhite]EDM Videos[/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFuVbKK_q7An7AGK_sBovNbm/",35,'http://sgkodi.de/VEVO/Daten/VevoCharts.png')
        addDir3('[COLORred][B]Top 10[/B][/COLOR] [COLORwhite]EDM Videos of 2018[/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFsO6z9aLV540RcbIQSDsbMP/",35,'http://sgkodi.de/VEVO/Daten/VevoCharts.png')
        addDir3('[COLORred][B]Top 10[/B][/COLOR] [COLORwhite]Hip-Hop Videos[/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFs8J2ySTyV8aW9ZDwT-f2KE/",35,'http://sgkodi.de/VEVO/Daten/VevoCharts.png')
        addDir3('[COLORred][B]Top 10[/B][/COLOR] [COLORwhite]Hip-Hop Videos of 2018[/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFtxXjd3Klm7cDmqXCxyY9b0/",35,'http://sgkodi.de/VEVO/Daten/VevoCharts.png')
        addDir3('[COLORred][B]Top 10[/B][/COLOR] [COLORwhite]Indie Videos[/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFtJHsp-bsHZH3jxLa08rDya/",35,'http://sgkodi.de/VEVO/Daten/VevoCharts.png')
        addDir3('[COLORred][B]Top 10[/B][/COLOR] [COLORwhite]Indie Videos of 2018[/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFuEOGsquQgnbxQQ6d9W2aKu/",35,'http://sgkodi.de/VEVO/Daten/VevoCharts.png')
        addDir3('[COLORred][B]Top 10[/B][/COLOR] [COLORwhite]Latin Videos[/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFuz1RSdd0ua9EHdQSJecALm/",35,'http://sgkodi.de/VEVO/Daten/VevoCharts.png')
        addDir3('[COLORred][B]Top 10[/B][/COLOR] [COLORwhite]Latin Videos of 2018[/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFuVuLIQoV8aOHArPfZbxLV2/",35,'http://sgkodi.de/VEVO/Daten/VevoCharts.png')
        addDir3('[COLORred][B]Top 10[/B][/COLOR] [COLORwhite]Metal Videos[/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFunVZhgJ9IREhr73C2amsLz/",35,'http://sgkodi.de/VEVO/Daten/VevoCharts.png')
        addDir3('[COLORred][B]Top 10[/B][/COLOR] [COLORwhite]Metal Videos of 2018[/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFvuqteD3p7vAgUIyPbGBjGK/",35,'http://sgkodi.de/VEVO/Daten/VevoCharts.png')
        addDir3('[COLORred][B]Top 10[/B][/COLOR] [COLORwhite]R&B Videos[/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFuJMY7OjmKmhtOEcegCY6C6/",35,'http://sgkodi.de/VEVO/Daten/VevoCharts.png')
        addDir3('[COLORred][B]Top 10[/B][/COLOR] [COLORwhite]R&B Videos of 2018[/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFvvFxqFhboitegq_lVPgb18/",35,'http://sgkodi.de/VEVO/Daten/VevoCharts.png')
        addDir3('[COLORred][B]Top 10[/B][/COLOR] [COLORwhite]Rock Videos[/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFuvha_x5OEnmpYpfK-AtuTp/",35,'http://sgkodi.de/VEVO/Daten/VevoCharts.png')
        addDir3('[COLORred][B]Top 10[/B][/COLOR] [COLORwhite]Rock Videos of 2018[/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFudLBYO_ZSU-8Rjv29JIYh_/",35,'http://sgkodi.de/VEVO/Daten/VevoCharts.png')
        addDir3('[COLORwhite]All New[/COLOR] [COLORred][B]ALTERNATIVE[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFsez6cjXAxHTruW0jteUHQk/",35,'http://sgkodi.de/VEVO/Daten/VevoNewGenre.png')
        addDir3('[COLORwhite]Kickin´ New[/COLOR] [COLORred][B]COUNTRY[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFtUu1HrxtZ4hv8nNLKiRseN/",35,'http://sgkodi.de/VEVO/Daten/VevoNewGenre.png')
        addDir3('[COLORwhite]New[/COLOR] [COLORred][B]EDM[/B][/COLOR] [COLORwhite]Beats[/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFvBK4oJZylITMXRxAPJvbr8/",35,'http://sgkodi.de/VEVO/Daten/VevoNewGenre.png')
        addDir3('[COLORwhite]Hot New[/COLOR] [COLORred][B]HIP-HOP[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFv-V7FvZP-PWuE-1x2Deqqe/",35,'http://sgkodi.de/VEVO/Daten/VevoNewGenre.png')
        addDir3('[COLORwhite]All New[/COLOR] [COLORred][B]INDIE[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFvXYAx7RjMQd6h7_URtCwoK/",35,'http://sgkodi.de/VEVO/Daten/VevoNewGenre.png')
        addDir3('[COLORwhite]Nuevo Pop[/COLOR] [COLORred][B]LATINO[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFtps6SqgQYfMoMk557f2VAk/",35,'http://sgkodi.de/VEVO/Daten/VevoNewGenre.png')
        addDir3('[COLORwhite]Malicious New[/COLOR] [COLORred][B]METAL[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFuErwY_it1HO20Da-13FfNz/",35,'http://sgkodi.de/VEVO/Daten/VevoNewGenre.png')
        addDir3('[COLORwhite]Nuevo Regional[/COLOR] [COLORred][B]MEXICANO[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFun6Q71-e4lgwHigs0EbSfd/",35,'http://sgkodi.de/VEVO/Daten/VevoNewGenre.png')
        addDir3('[COLORwhite]New[/COLOR] [COLORred][B]R&B[/B][/COLOR] [COLORwhite]Vibes[/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFupYyrDriLYu3ba9oYMUJ65/",35,'http://sgkodi.de/VEVO/Daten/VevoNewGenre.png')
        addDir3('[COLORwhite]Rugged New[/COLOR] [COLORred][B]ROCK[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFvrS_oXmav-as9fy3lt1i34/",35,'http://sgkodi.de/VEVO/Daten/VevoNewGenre.png')
        addDir3('[COLORwhite]Brand New[/COLOR] [COLORred][B]POP[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFt2TyOofWG0XwA8IDC8SGIN/",35,'http://sgkodi.de/VEVO/Daten/VevoNewGenre.png')
        addDir3('[COLORwhite]Los Rompe Tarima[/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFvRr9wRh1o8oeIpkPUdAjV6/",35,'http://sgkodi.de/VEVO/Daten/VevoNewGenre.png')
        addDir3('[COLORred][B]Fresh Music[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFuiE7QFMzvaTuhXleCaAc52/",35,'http://sgkodi.de/VEVO/Daten/VevoGenre.png')
        addDir3('[COLORred][B]Afro Beat[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFufJOabZGuV93QVdZzouWyc/",35,'http://sgkodi.de/VEVO/Daten/VevoGenre.png')
        addDir3('[COLORred][B]Dancehall Delights[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFu9k1UqFdWffUtMyeNbwAYw/",35,'http://sgkodi.de/VEVO/Daten/VevoGenre.png')
        addDir3('[COLORred][B]Dance Pop Hits[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFtynbPGh-GPxTsCGAW35GgW/",35,'http://sgkodi.de/VEVO/Daten/VevoGenre.png')
        addDir3('[COLORred][B]Dad Rock[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFvsOFNUeME8BSbiH_PwQGOK/",35,'http://sgkodi.de/VEVO/Daten/VevoGenre.png')
        addDir3('[COLORred][B]Electro Alt/Indie[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFtWjRRwOK_D_RO2kv0yU3mx/",35,'http://sgkodi.de/VEVO/Daten/VevoGenre.png')
        addDir3('[COLORred][B]Extrem Metal[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFv-fsLsz-1RaVdKeBPp5o28/",35,'http://sgkodi.de/VEVO/Daten/VevoGenre.png')
        addDir3('[COLORred][B]Grown Folk R&B[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFtgtiMbBi64rRudSIMFg-d8/",35,'http://sgkodi.de/VEVO/Daten/VevoGenre.png')
        addDir3('[COLORred][B]Heavy Spitters[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFs14BsetzaXkYUo-Nx6WRG7/",35,'http://sgkodi.de/VEVO/Daten/VevoGenre.png')
        addDir3('[COLORred][B]Hear it Now: Country![/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFtU-Y58frRg2nENqyZLYuzj/",35,'http://sgkodi.de/VEVO/Daten/VevoGenre.png')
        addDir3('[COLORred][B]Indie Pop[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFtG6Vx47mZFpr56Wfty30FJ/",35,'http://sgkodi.de/VEVO/Daten/VevoGenre.png')
        addDir3('[COLORred][B]Island Vibes[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFtU-Y58frRg2nENqyZLYuzj/",35,'http://sgkodi.de/VEVO/Daten/VevoGenre.png')
        addDir3('[COLORred][B]Latin Trendsetters[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFsfDtWiBJ4j7YyDINWIiHpq/",35,'http://sgkodi.de/VEVO/Daten/VevoGenre.png')
        addDir3('[COLORred][B]Nuevo Sabor Tropical[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFtVmU7eZa84X1s7EmaUaeI5/",35,'http://sgkodi.de/VEVO/Daten/VevoGenre.png')
        addDir3('[COLORred][B]Old 2 the New[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFuF8lJd_OZwQsWMrKMCEgIB/",35,'http://sgkodi.de/VEVO/Daten/VevoGenre.png')
        addDir3('[COLORred][B]Organic Alt/Indie[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFsrB_M5iGi2ww3vCTVVyjZW/",35,'http://sgkodi.de/VEVO/Daten/VevoGenre.png')
        addDir3('[COLORred][B]Pure Pop[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFvKRiSw23TNP68fIrUblrWH/",35,'http://sgkodi.de/VEVO/Daten/VevoGenre.png')
        addDir3('[COLORred][B]Pop Teen[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFvxjdtw3Iy4LsyhXeCt_P44/",35,'http://sgkodi.de/VEVO/Daten/VevoGenre.png')
        addDir3('[COLORred][B]Riddim Nation[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFvF0nBYvE8vKSlWsGssAydq/",35,'http://sgkodi.de/VEVO/Daten/VevoGenre.png')
        addDir3('[COLORred][B]Roots Reggae[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFtd2_FhMAWoiMW0r5X-Sveo/",35,'http://sgkodi.de/VEVO/Daten/VevoGenre.png')
        addDir3('[COLORred][B]Soca Hits[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFsmprDH-i2yeq1z8OwiFzDu/",35,'http://sgkodi.de/VEVO/Daten/VevoGenre.png')
        addDir3('[COLORred][B]Teen Hip-Hop and R&B[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFvHLl17Tm2-fyhwDBnecahx/",35,'http://sgkodi.de/VEVO/Daten/VevoGenre.png')
        addDir3('[COLORred][B]Trap Stars[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFuSozSTGO7dibrhaDg6qRq2/",35,'http://sgkodi.de/VEVO/Daten/VevoGenre.png')
        addDir3('[COLORred][B]This One s For The Girls[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFspwjv96-6Vanlik6v2vRz0/",35,'http://sgkodi.de/VEVO/Daten/VevoGenre.png')
        addDir3('[COLORred][B]UK Represent[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFsi4M0yYHy4KL-UBVfCmq3G/",35,'http://sgkodi.de/VEVO/Daten/VevoGenre.png')
        addDir3('[COLORwhite]Love it Live:[/COLOR] [COLORred][B]COUNTRY[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFuLQIXnp6BrHTYaGF0w4dY-/",35,'http://sgkodi.de/VEVO/Daten/VevoLive.png')
        addDir3('[COLORwhite]Love it Live:[/COLOR] [COLORred][B]INDIE[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFtVyHzilNNbDeI5UkWa1hZ8/",35,'http://sgkodi.de/VEVO/Daten/VevoLive.png')
        addDir3('[COLORwhite]Love it Live:[/COLOR] [COLORred][B]HIP-HOP[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFvz5YcFommSYF-iCrZj6nhE/",35,'http://sgkodi.de/VEVO/Daten/VevoLive.png')
        addDir3('[COLORwhite]Love it Live:[/COLOR] [COLORred][B]METAL[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFvSPe7p4oCziGKb8yMm2D8a/",35,'http://sgkodi.de/VEVO/Daten/VevoLive.png')
        addDir3('[COLORwhite]Love it Live:[/COLOR] [COLORred][B]R&B[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFtKOKmHyEgagZOOsed6bLGp/",35,'http://sgkodi.de/VEVO/Daten/VevoLive.png')
        addDir3('[COLORwhite]Love it Live:[/COLOR] [COLORred][B]ROCK[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFseh1MIXV1gsrU_h_1Pc_mo/",35,'http://sgkodi.de/VEVO/Daten/VevoLive.png')
        addDir3('[COLORwhite]Love it Live:[/COLOR] [COLORred][B]POP[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFseUoJd-4NUu042RuQ0PUfi/",35,'http://sgkodi.de/VEVO/Daten/VevoLive.png')
        addDir3('[COLORwhite]Live Performances[/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFvtAbH4_z7IEaSYAHrNW8Wo/",35,'http://sgkodi.de/VEVO/Daten/VevoLive.png')
        addDir3('[COLORwhite]DSCVR - All Live Performances[/COLOR]',"plugin://plugin.video.youtube/playlist/PLfpWqf0Dq32_xD4HttGXuLkM-QfSoWBvW/",35,'http://sgkodi.de/VEVO/Daten/VevoLive.png')
        addDir3('[COLORwhite]LiveSets @ The Great Escape Festival 2018[/COLOR]',"plugin://plugin.video.youtube/playlist/PL7KLwyJCC7QyKJoYKgfo8l7VkrkKkyjRq/",35,'http://sgkodi.de/VEVO/Daten/VevoLive.png')
        addDir3('[COLORred][B]COUNTRY[/B][/COLOR] [COLORwhite]Party Playlist[/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFv8hIun4ujGj0RF66Ogb-vf/",35,'http://sgkodi.de/VEVO/Daten/VevoMoods.png')
        addDir3('[COLORred][B]EDM[/B][/COLOR] [COLORwhite]Party Playlist[/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFvxJlU0eH71A4nkP1O1HsUo/",35,'http://sgkodi.de/VEVO/Daten/VevoMoods.png')
        addDir3('[COLORred][B]HIP-HOP[/B][/COLOR] [COLORwhite]In the Gym[/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFtZk0J0MsWkajC3139aQ2wy/",35,'http://sgkodi.de/VEVO/Daten/VevoMoods.png')
        addDir3('[COLORred][B]HIT[/B][/COLOR] [COLORwhite]the Gym[/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFuXtvZQsoJYw3PTZjCN8CCZ/",35,'http://sgkodi.de/VEVO/Daten/VevoMoods.png')
        addDir3('[COLORred][B]R&B[/B][/COLOR] [COLORwhite]Party Playlist[/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFv4jC7qf3u38KNpvv2SOkJR/",35,'http://sgkodi.de/VEVO/Daten/VevoMoods.png')
        addDir3('[COLORred][B]ROMANCE[/B][/COLOR] [COLORwhite]Rockero[/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFs5owDVo-lHb6QgCA0ZL3Jk/",35,'http://sgkodi.de/VEVO/Daten/VevoMoods.png')
        addDir3('[COLORred][B]POP[/B][/COLOR] [COLORwhite]Party Playlist[/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFvz9SFKucMbmBt-SnZtokVY/",35,'http://sgkodi.de/VEVO/Daten/VevoMoods.png')
        addDir3('[COLORred][B]Pop Outta Bed[/B][/COLOR] [COLORwhite]- Music With Your Coffee[/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFukDT2wdYkXwSZqg8HsH73q/",35,'http://sgkodi.de/VEVO/Daten/VevoMoods.png')
        addDir3('[COLORred][B]The Breakfast Club[/B][/COLOR] [COLORwhite]- Morning Music[/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFtfwzVHdLt_nJwt9Iv7qoD7/",35,'http://sgkodi.de/VEVO/Daten/VevoMoods.png')
        addDir3('[COLORred][B]CHILLOUT[/B][/COLOR] [COLORwhite]- Lazy Morning[/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFtROKI2bqQdOGNWgmRWsKNv/",35,'http://sgkodi.de/VEVO/Daten/VevoMoods.png')
        addDir3('[COLORred][B]Mellow Out[/B][/COLOR] [COLORwhite]- Low Key Afternoon[/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFul67nuDgHNojFAt1IPjiIC/",35,'http://sgkodi.de/VEVO/Daten/VevoMoods.png')
        addDir3('[COLORred][B]Midnight Chill[/B][/COLOR] [COLORwhite]- Sleepy Head[/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFugJqfmiNpXMRop_swcsXHZ/",35,'http://sgkodi.de/VEVO/Daten/VevoMoods.png')
        addDir3('[COLORred][B]Crushin On You[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFuo2kolkJmA_Th0sUC_mLtW/",35,'http://sgkodi.de/VEVO/Daten/VevoMoods.png')
        addDir3('[COLORred][B]Hoy Se Bebe[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFs2is-Fji_wHWtfO_-Rko2x/",35,'http://sgkodi.de/VEVO/Daten/VevoMoods.png')
        addDir3('[COLORred][B]Late Registration[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFtvZUAUKlYLfS74PyTgJqo4/",35,'http://sgkodi.de/VEVO/Daten/VevoMoods.png')
        addDir3('[COLORwhite]Incoming[/COLOR] [COLORred][B]ALTERNATIVE[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFt_H0qxBMqqQonj83vaKDbF/",35,'http://sgkodi.de/VEVO/Daten/VevoPlaylist.png')
        addDir3('[COLORwhite]Incoming[/COLOR] [COLORred][B]COUNTRY[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFtftz_53w-VnY9kYz8bC66w/",35,'http://sgkodi.de/VEVO/Daten/VevoPlaylist.png')
        addDir3('[COLORwhite]Incoming[/COLOR] [COLORred][B]EDM[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFubH8RSGxdBDwhf7g4C60Vy/",35,'http://sgkodi.de/VEVO/Daten/VevoPlaylist.png')
        addDir3('[COLORwhite]Incoming[/COLOR] [COLORred][B]HIP-HOP[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFvN_9mCk7b8h33NrlxiPTx1/",35,'http://sgkodi.de/VEVO/Daten/VevoPlaylist.png')
        addDir3('[COLORwhite]Incoming[/COLOR] [COLORred][B]INDIE[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFsFhx7JRa8pbMVIExlLYNah/",35,'http://sgkodi.de/VEVO/Daten/VevoPlaylist.png')
        addDir3('[COLORwhite]Incoming[/COLOR] [COLORred][B]METAL[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFuFHvOwsadSCn3NKeuNIh0B/",35,'http://sgkodi.de/VEVO/Daten/VevoPlaylist.png')
        addDir3('[COLORwhite]Incoming[/COLOR] [COLORred][B]R&B[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFvSkAtT0DUEffzC5mi7hUOl/",35,'http://sgkodi.de/VEVO/Daten/VevoPlaylist.png')
        addDir3('[COLORwhite]Incoming[/COLOR] [COLORred][B]ROCK[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFtva3fYalscaRiMVc9C6EES/",35,'http://sgkodi.de/VEVO/Daten/VevoPlaylist.png')
        addDir3('[COLORwhite]Incoming[/COLOR] [COLORred][B]POP[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFuIC3udROGYMT_M4f39x4BW/",35,'http://sgkodi.de/VEVO/Daten/VevoPlaylist.png')
        addDir3('[COLORwhite]DSCVR[/COLOR] [COLORred][B]ALTERNATIVE[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFuZjjpuZMhh7KC-Sw6aehjA/",35,'http://sgkodi.de/VEVO/Daten/VevoDSCVR.png')
        addDir3('[COLORwhite]DSCVR[/COLOR] [COLORred][B]COUNTRY[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFs8XbSARCWThNqt5YXhCOHu/",35,'http://sgkodi.de/VEVO/Daten/VevoDSCVR.png')
        addDir3('[COLORwhite]DSCVR[/COLOR] [COLORred][B]EDM[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFsGFJ6dh8R6AExOhIYljnjp/",35,'http://sgkodi.de/VEVO/Daten/VevoDSCVR.png')
        addDir3('[COLORwhite]DSCVR[/COLOR] [COLORred][B]HIP-HOP[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFt5tsGbHhlAVX7KDM4WpMYC/",35,'http://sgkodi.de/VEVO/Daten/VevoDSCVR.png')
        addDir3('[COLORwhite]DSCVR[/COLOR] [COLORred][B]INDIE[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFuwFi1wSueeFR-7MdKn5xM-/",35,'http://sgkodi.de/VEVO/Daten/VevoDSCVR.png')
        addDir3('[COLORwhite]DSCVR[/COLOR] [COLORred][B]LATINO[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFtd5iXVx_m6tSyyJZskY3xf/",35,'http://sgkodi.de/VEVO/Daten/VevoDSCVR.png')
        addDir3('[COLORwhite]DSCVR[/COLOR] [COLORred][B]METAL[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFsl7Hqzq6VeI7rWskr4lb37/",35,'http://sgkodi.de/VEVO/Daten/VevoDSCVR.png')
        addDir3('[COLORwhite]DSCVR[/COLOR] [COLORred][B]R&B[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFvlIjnD63Q8WJdzN_Sa94kp/",35,'http://sgkodi.de/VEVO/Daten/VevoDSCVR.png')
        addDir3('[COLORwhite]DSCVR[/COLOR] [COLORred][B]ROCK[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFsQ42vFCS-PhDg--aPyh9R7/",35,'http://sgkodi.de/VEVO/Daten/VevoDSCVR.png')
        addDir3('[COLORwhite]DSCVR[/COLOR] [COLORred][B]POP[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFtbNWZwYMO7HLlH58DcVJoi/",35,'http://sgkodi.de/VEVO/Daten/VevoDSCVR.png')
        addDir3('[COLORred][B]ALTERNATIVE[/B][/COLOR] [COLORwhite]Replay[/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFu2G9yrUTQaq34OGlENR7Dw/",35,'http://sgkodi.de/VEVO/Daten/VevoReplay.png')
        addDir3('[COLORred][B]COUNTRY[/B][/COLOR] [COLORwhite]Replay[/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFsO4BWeXMvfFJuwXONeMRAJ/",35,'http://sgkodi.de/VEVO/Daten/VevoReplay.png')
        addDir3('[COLORred][B]EDM[/B][/COLOR] [COLORwhite]Replay[/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFspK-zf2PoWqP6NJYflkM-B/",35,'http://sgkodi.de/VEVO/Daten/VevoReplay.png')
        addDir3('[COLORred][B]INDIE[/B][/COLOR] [COLORwhite]Replay[/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFs5S8Hy6amKBeKuGq2CMxCv/",35,'http://sgkodi.de/VEVO/Daten/VevoReplay.png')
        addDir3('[COLORred][B]METAL[/B][/COLOR] [COLORwhite]Replay[/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFvruwh6bTrU_X1Yn7aCvwtZ/",35,'http://sgkodi.de/VEVO/Daten/VevoReplay.png')
        addDir3('[COLORred][B]RAP[/B][/COLOR] [COLORwhite]Replay[/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFtb-K_G-Uv-FgKNFuT2KSBW/",35,'http://sgkodi.de/VEVO/Daten/VevoReplay.png')
        addDir3('[COLORred][B]R&B[/B][/COLOR] [COLORwhite]Replay[/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFvP58E91WStRnOPTxSTTgC7/",35,'http://sgkodi.de/VEVO/Daten/VevoReplay.png')
        addDir3('[COLORred][B]ROCK[/B][/COLOR] [COLORwhite]Replay[/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFt8kH1xUjp9mmrUMTG3qt1I/",35,'http://sgkodi.de/VEVO/Daten/VevoReplay.png')
        addDir3('[COLORred][B]POP[/B][/COLOR] [COLORwhite]Replay[/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFsuscmwmqh96nRKLrVM8BOy/",35,'http://sgkodi.de/VEVO/Daten/VevoReplay.png')
        addDir3('[COLORred][B]POP[/B][/COLOR] [COLORwhite]Mix 2018>2015[/COLOR]',"plugin://plugin.video.youtube/playlist/PL7KLwyJCC7QzpNciVGe-7K6ShC3MzL3vd/",35,'http://sgkodi.de/VEVO/Daten/VevoMix.png')
        addDir3('[COLORred][B]DANCE/ELECTRO[/B][/COLOR] [COLORwhite]Mix 2018>2015[/COLOR]',"plugin://plugin.video.youtube/playlist/PL7KLwyJCC7QyXUZLdnHDbBIjBZZSOFRKk/",35,'http://sgkodi.de/VEVO/Daten/VevoMix.png')
        addDir3('[COLORred][B]INDIE/ROCK/ALTERNATIVE[/B][/COLOR] [COLORwhite]Mix 2018>2015[/COLOR]',"plugin://plugin.video.youtube/playlist/PL7KLwyJCC7Qx3UC8uj-qLIsOdd5OmkNHY/",35,'http://sgkodi.de/VEVO/Daten/VevoMix.png')
        addDir3('[COLORred][B]Interviews[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFtf0OfrhrX05vWJlddRR_AW/",35,'http://sgkodi.de/VEVO/Daten/VevoMeets.png')
        addDir3('[COLORred][B]VEVO Meets[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFvxtE1BaLe2s4EHqRxqNEdx/",35,'http://sgkodi.de/VEVO/Daten/VevoMeets.png')
        addDir3('[COLORred][B]60Seconds with...[/B][/COLOR]',"plugin://plugin.video.youtube/playlist/PL9tY0BWXOZFuUNkhmRYHLQjc5wOjKNU_Z/",35,'http://sgkodi.de/VEVO/Daten/VevoMeets.png')

def kids():
     
        addDir3('[COLOR aqua]הצגות לילדים [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=הצגות לילדים&url=www",35,art + 'kids.png')
        addDir3('[COLOR aqua]סרטים לילדים מדובב + מתורגם [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=סרטים לילדים מדובב + מתורגם&url=www",35,art + 'kids.png')
        addDir3('[COLOR aqua]קלטות לילדים [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=קלטות לילדים&url=www",35,art + 'kids.png')
        addDir3('[COLOR aqua]יובל המבולבל[/COLOR]','plugin://plugin.video.MyYoutube/kodion/search/query/?q=%d7%99%d7%95%d7%91%d7%9c%20%d7%94%d7%9e%d7%91%d7%95%d7%91%d7%9c',35,art + 'kids.png')
        addDir3('[COLOR aqua]דוד חיים [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=דוד חיים&url=www",35,art + 'kids.png')
        addDir3('[COLOR aqua]מיכל הקטנה[/COLOR]','plugin://plugin.video.MyYoutube/kodion/search/query/?q=%d7%9e%d7%99%d7%9b%d7%9c%20%d7%94%d7%a7%d7%98%d7%a0%d7%94',35,art + '30027.jpg')
        addDir3('[COLOR aqua]רינת [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=רינת&url=www",35,art + '30028.jpg')
        addDir3('[COLOR aqua]פסטיגל [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=פסטיגל&url=www",35,art + '30029.jpg')
        addDir3('[COLOR aqua]מופעי קרקס[/COLOR]','plugin://plugin.video.MyYoutube/kodion/search/query/?q=full%20circus%20show',35,art + 'kids.png')		
        addDir('[COLOR aqua]ערוץ גוניור[/COLOR]','PL3432ABAC840E3DF3',18,art + '30030.jpg')
        addDir('[COLOR aqua]ניק גוניור[/COLOR]','PLbrxg_e8MbbF-psMIds86ndWuTehx4kQS',19,art + '30031.jpg')
        addDir('[COLOR aqua]ניקלודאון[/COLOR]','PLtXcJHjzQOdOJyKUf4N_im5szCADvUbb_',20,art + '30032.jpg')
        addDir('[COLOR aqua]לוגי[/COLOR]','PLtXcJHjzQOdOJyKUf4N_im5szCADvUbb_',21,art + '30033.jpg')
        addDir('[COLOR aqua]הופ[/COLOR]','PLeagipoZmyfmBwqCrCc8p7cE6QdLes-eL',22,art + 'hop.png')
        addDir('[COLOR aqua]הופ ילדות ישראלית[/COLOR]','PLrhuB2KrXOjikfPLJhTmz2qKDkltz9L8Y',23,art + 'hopy.jpg')
        addDir('[COLOR aqua]לולי[/COLOR]','PLqcNVz8UuCsLhpzTjL0JGj3YuMyWWd5Ug',24,art + 'luly.jpg')
        addDir('[COLOR aqua]בייבי[/COLOR]','PLsFmiuNwu758huWLmxTM4NCln7tbqJDPn',25,art + 'baby.jpg')
        addDir('[COLOR aqua]הוט ילדים[/COLOR]','PLtfPnJye9L3dxlbWP7OlJH-_yI3PYsh9r',26,art + 'HOTVOD.png')
        addDir('[COLOR aqua]ערוץ הילדים[/COLOR]','PLeagipoZmyfkWkyetCWsJMGy8yBvHdJs-',27,art + 'kidstv.png')
        addDir('[COLOR aqua]חינוכית לילדים[/COLOR]','PLeagipoZmyfn9MhKB9Smgqob8CLNiaA51',28,art + '23.jpg')
        addDir('[COLOR aqua]ערוץ זום[/COLOR]','PLS3SOlSTtJcDe-vQ-T46r_cB1U_ENAuKF',29,art + 'zoom.jpg')
        addDir('[COLOR aqua]דיסני גוניור[/COLOR]','PLeagipoZmyfl46t2ABPQitVy1V7qu2vrG',30,art + 'dsjr.jpg')	
        addDir('[COLOR aqua]סדרות נוסטלגיות[/COLOR]','PLeagipoZmyfl46t2ABPQitVy1V7qu2vrG',37,art + 'kids.png')	
        addDir3('[COLOR aqua]לימוד קסמים לילדים [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=לימוד קסמים לילדים&url=www",35,art + 'kids.png')	
        addDir3('[COLOR aqua]יצירה לילדים [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=יצירה לילדים&url=www",35,art + 'kids.png')
        addDir3('[COLOR aqua]אוריגמי לילדים [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=אוריגמי לילדים&url=www",35,art + 'kids.png')

def movies():
        addDir3('[COLOR aqua]סרטים ישראליים [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=סרטים ישראליים&url=www",35,art + 'movies.png')
        addDir3('[COLOR aqua]סרטים מתורגמים[/COLOR]','plugin://plugin.video.MyYoutube/kodion/search/query/?q=%d7%a1%d7%a8%d7%98%20%d7%9e%d7%aa%d7%95%d7%a8%d7%92%d7%9d%20%d7%9e%d7%9c%d7%90',35,art + 'movies.png')
        addDir3('[COLOR aqua]סרטים לילדים [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=סרטים לילדים&url=www",35,art + 'movies.png')
		
def junior():
        addDir('[COLOR aqua]קופיקו עונה 1[/COLOR]','PLR7DTcU2p0QhDzYbbniDNwSbXUM_p6N3f',1,art + '30030.jpg')
        addDir('[COLOR aqua]קופיקו עונה 2[/COLOR]','PLR7DTcU2p0QgEdLPHhrhKtxElvYVrseAQ',1,art + '30030.jpg')
        addDir('[COLOR aqua]קופיקו עונה 3[/COLOR]','PLR7DTcU2p0QhNGUffSgu8_5dP3lnOGZTx',1,art + '30030.jpg')
        addDir('[COLOR aqua]הפיראט המהיר[/COLOR]','PLR7DTcU2p0Qirvpu8HPR2GUCLJmXrn9dJ',1,art + '30030.jpg')
        addDir('[COLOR aqua]הנעלמים[/COLOR]','PLR7DTcU2p0Qh4o44FETppW3n4vQCQGqsk',1,art + '30030.jpg')
        addDir('[COLOR aqua]דוח דלעת[/COLOR]','PLR7DTcU2p0QhuQU-SWBGtywN6Zt1bapZt',1,art + '30030.jpg')
        addDir('[COLOR aqua]ספיד רייסר[/COLOR]','PLR7DTcU2p0QjzH9muKiw1eTbp0aU3hB63',1,art + '30030.jpg')
        addDir('[COLOR aqua]וולברין והאקס מן[/COLOR]','PLR7DTcU2p0QhGsv3LuA3GnCJWjoPBCafl',1,art + '30030.jpg')
        addDir('[COLOR aqua]החתולים הסמוראיים[/COLOR]','PLR7DTcU2p0QhPmznEmitRHkv5RcUG3E-s',1,art + '30030.jpg')
        addDir('[COLOR aqua]רוי בוי[/COLOR]','PLR7DTcU2p0Qg8pxiEld0Fg3K2Bd8gTKw5',1,art + '30030.jpg')
        addDir('[COLOR aqua]בארץ הקטקטים[/COLOR]','PLR7DTcU2p0Qg5sF-jE09YnRymKba8N8l_',1,art + '30030.jpg')
        addDir('[COLOR aqua]משטרת האגדות[/COLOR]','PLR7DTcU2p0QiaEmc56lGHMpxW4ladE93X',1,art + '30030.jpg')
        addDir('[COLOR aqua]סנדוקאן[/COLOR]','PLR7DTcU2p0QgWYVQap5zPK0MkwJizYku_',1,art + '30030.jpg')

def nostal():
        addDir('[COLOR aqua]הבית של פיסטוק[/COLOR]','PL51YAgTlfPj7D-QAVZ94EK-BHm7XG9BOl',1,art + 'kids.png')
        addDir3('[COLOR aqua]נילס הולגרסון [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=נילס הולגרסון&url=www",35,art + 'kids.png')
        addDir3('[COLOR aqua]דובוני אכפת לי [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=דובוני אכפת לי&url=www",35,art + 'kids.png')
        addDir('[COLOR aqua]הקוסם מארץ עוץ[/COLOR]','PLrm9dDLqwrHnZF86MMTIb-Q3LSKLGLTDQ',1,art + 'kids.png')
        addDir3('[COLOR aqua]הדרדסים [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=הדרדסים&url=www",35,art + 'kids.png')
        addDir3('[COLOR aqua]צבי הנינגה [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=צבי הנינגה&url=www",35,art + 'kids.png')
        addDir3('[COLOR aqua]הלב [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=הלב&url=www",35,art + 'kids.png')
        addDir3('[COLOR aqua]הקטקטים [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=הקטקטים&url=www",35,art + 'kids.png')
        addDir3('[COLOR aqua]שוטרים וגנבים [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=שוטרים וגנבים&url=www",35,art + 'kids.png')
        addDir3('[COLOR aqua]גברת פלפלת [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=גברת פלפלת&url=www",35,art + 'kids.png')
        addDir('[COLOR aqua]שאלתיאל קוואק[/COLOR]','PLkLrihhmnxYELf9vVWTDEN3kZbUUegfA2',1,art + 'kids.png')
        addDir('[COLOR aqua]פיטר פן[/COLOR]','PLkLrihhmnxYF0aX8dXLN13mUAMICQmerb',1,art + 'kids.png')
        addDir3('[COLOR aqua]החיים - היה היה [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=החיים - היה היה&url=www",35,art + 'kids.png')
        addDir3('[COLOR aqua]בלי סודות [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=בלי סודות&url=www",35,art + 'kids.png')
        addDir3('[COLOR aqua]פרפר נחמד [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=פרפר נחמד&url=www",35,art + 'kids.png')
        addDir3('[COLOR aqua]דן הדוור [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=דן הדוור&url=www",35,art + 'kids.png')
        addDir3('[COLOR aqua]הדבורה מאיה [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=הדבורה מאיה&url=www",35,art + 'kids.png')
        addDir3('[COLOR aqua]קשת וענן [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=קשת וענן&url=www",35,art + 'kids.png')
		
def dsjunior():
        addDir3('[COLOR aqua]ארמון החיות [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=ארמון החיות&url=www",35,art + 'kids.png')
        addDir3('[COLOR aqua]הנסיכה סופיה הראשונה [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=הנסיכה סופיה הראשונה&url=www",35,art + 'kids.png')
        addDir('[COLOR aqua]הסרטים המצויירים של מיני [/COLOR]','PLVwL64lSxWWw21D3vaqKMxNOXTO82t1je',1,art + 'dsjr.jpg')
        addDir('[COLOR aqua]ספיישל להיות פיראט[/COLOR]','PLVwL64lSxWWzCmfvd65mBVKGX0VMFIEM7',1,art + 'dsjr.jpg')
        addDir('[COLOR aqua]התעמלות עם מיקי מאוס[/COLOR]','PLVwL64lSxWWwLsl52oUSphP6zSbbvQu_h',1,art + 'dsjr.jpg')
        addDir('[COLOR aqua]דוק רופאת צעצועים[/COLOR]','PLVwL64lSxWWyRD2CIOc5qkXUuSWSsyuRh',1,art + 'dsjr.jpg')
        addDir('[COLOR aqua]הרגעים הגדולים של סטאר [/COLOR]','PLRKLm5GvuZVIv7NoJvoBrlAlOYaatpzqM',1,art + 'dsjr.jpg')
        addDir('[COLOR aqua]היורשים - בית ספר של סודות[/COLOR]','PLRKLm5GvuZVJq1moobQvXZUHMM943qAWP',1,art + 'dsjr.jpg')
        
def zoom():
        addDir('[COLOR aqua]ציקה ומפירו[/COLOR]','PLnzhIyrsnB5YoLZMevyWHS4lhnFB2yIH-',1,art + 'zoom.jpg')
        addDir('[COLOR aqua]סוסי פרא[/COLOR]','PL9FUtLp-Tfr3vR1EJa04KIDYskHfpsaQp',1,art + 'zoom.jpg')
        addDir('[COLOR aqua]מועדון החנונים[/COLOR]','PLKMFPiSCwUk0myYc1Z8oPLGO6hXJdf5uv',1,art + 'zoom.jpg')
        addDir('[COLOR aqua]סופר סטרייקה[/COLOR]','PLnzhIyrsnB5ZoulWt_5tVF2MaySwu-1Vm',1,art + 'zoom.jpg')
        addDir('[COLOR aqua]צימה[/COLOR]','PLnzhIyrsnB5at3Uw3KWWCzVYUOCD6aYy9',1,art + 'zoom.jpg')
        addDir('[COLOR aqua]מועדון החנונים[/COLOR]','PLKMFPiSCwUk22xxgMwcNShgeBYNSfotbB',1,art + 'zoom.jpg')
        addDir('[COLOR aqua]דיגימון[/COLOR]','PLKMFPiSCwUk2AWPSN0CngtMfiB8oFWZwX',1,art + 'zoom.jpg')
        addDir('[COLOR aqua]איטי ועצבני[/COLOR]','PLKMFPiSCwUk08zM6SlJ3RrCu2_zdReijH',1,art + 'zoom.jpg')
        addDir('[COLOR aqua]פאוור  ריינגרס[/COLOR]','PLKMFPiSCwUk01oKz850en3WtD80zdmGus',1,art + 'zoom.jpg')
        
def ch23():
        addDir3('[COLOR aqua]שבט צוצלת [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=שבט צוצלת&url=www",35,art + 'kids.png')
        addDir('[COLOR aqua]חדשות מהעבר עונה 3[/COLOR]','PLth1a195qHsgnf978kWlEqU3IWuM2XnRI',1,art + '23.jpg')
        addDir('[COLOR aqua]חדשות התנך[/COLOR]','PLth1a195qHsgd5DCakz5w30jJ2_wsD9uv',1,art + '23.jpg')
        addDir('[COLOR aqua]החפרנים עונה 3[/COLOR]','PLth1a195qHsh6M7Js4DzJrIoa9_lMB4Zp',1,art + '23.jpg')
        addDir('[COLOR aqua]בוא נתערב[/COLOR]','PLth1a195qHsgHRikWwcJcTjpD_Ks4qYeU',1,art + '23.jpg')
        addDir3('[COLOR aqua]אחשלירוח [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=אחשלירוח&url=www",35,art + 'kids.png')
        addDir('[COLOR aqua]כנסת נכבדה[/COLOR]','PLth1a195qHsiN_6THGph_Kl3_hwQPq4vE',1,art + '23.jpg')
        addDir('[COLOR aqua]קישקשתא בדרכים[/COLOR]','PLth1a195qHsjLDoU-UCLFZrCQCd8ulef_',1,art + '23.jpg')
        addDir('[COLOR aqua]שוסטר ושוסטר[/COLOR]','PLth1a195qHshFOAU_eVupbzfvNkhcZ4pq',1,art + '23.jpg')
        addDir('[COLOR aqua]כאן ואומן[/COLOR]','PLth1a195qHsjuXR49nz70tgdT-g1nroZR',1,art + '23.jpg')
        addDir('[COLOR aqua]חדשות מהעבר מהדורה עולמית[/COLOR]','PLth1a195qHshoshAzTBxywa88VxYFB5ne',1,art + '23.jpg')
        addDir('[COLOR aqua]מה הסיפור? עונה 2[/COLOR]','PLth1a195qHsg6eDer1tNg4OAv5CmLOFhv',1,art + '23.jpg')
        addDir('[COLOR aqua]מה זה מוזה במעבדה עונה 2 [/COLOR]','PLth1a195qHsj20lXv4QqTQ7kb2RLoGxY8',1,art + '23.jpg')
        addDir('[COLOR aqua]חיות במה בהופעה [/COLOR]','PLth1a195qHsia6PoVqxkhSajNlBszZ4wu',1,art + '23.jpg')
        addDir('[COLOR aqua]דן ומוזלי עונה 2[/COLOR]','PLth1a195qHsh2JB7l8Y-0B8RKTzKeLTzI',1,art + '23.jpg')
        addDir('[COLOR aqua]גלילאו עונה 5 [/COLOR]','PLth1a195qHsigShKnT9DsIyKxcTBQ70Tf',1,art + '23.jpg')
        addDir('[COLOR aqua]דן ומוזלי[/COLOR]','PLth1a195qHsg1IITJcYXjfsNCdbRn3XTD',1,art + '23.jpg')		
		
def kidstv():
        addDir('[COLOR aqua]הכל טום[/COLOR]','PLstSEvEmr9e8wuM076jsnSbM6HEdLjmfz',1,art + 'kidstv.png')
        addDir('[COLOR aqua]ברחובות שלנו[/COLOR]','PLstSEvEmr9e-2ucQ38nu31Ms1qJPlVHcS',1,art + 'kidstv.png')
        addDir('[COLOR aqua]הבנים והבנות[/COLOR]','PLnzhIyrsnB5ZjJfepTibnFqEG8BD6ZML4',1,art + 'kidstv.png')
        addDir('[COLOR aqua]שוברי גלים[/COLOR]','PLnzhIyrsnB5bRzOyHnZgx7yHzOBAXz79L',1,art + 'kidstv.png')
        addDir('[COLOR aqua]נדחפים[/COLOR]','PLstSEvEmr9e-7DxpPTuIbRjIbFCMcY7YZ',1,art + 'kidstv.png')
        addDir('[COLOR aqua]פרויקט הלהקה[/COLOR]','PLnzhIyrsnB5ZwJDhjWM0bK-D4WFDR1jCQ',1,art + 'kidstv.png')
        addDir('[COLOR aqua]ששטוס[/COLOR]','PL7c4Q2VJu8RPYg1H-Cc005Pydh-nUNooD',1,art + 'kidstv.png')
        addDir('[COLOR aqua]השמיניה[/COLOR]','PLdHb9F0cRmPwtckIQ4LtKH_ZZOtTYoxC7',1,art + 'kidstv.png')
        addDir('[COLOR aqua]בית ספר למוזיקה[/COLOR]','PLF583DE56321F34CF',1,art + 'kidstv.png')
        
def hot():
        addDir('[COLOR aqua]סוסי פרא[/COLOR]','PL419YR22ubLCkWDoe9rdRvkeF3UD259Wq',1,art + 'HOTVOD.png')
        addDir('[COLOR aqua]גאליס[/COLOR]','PLnzhIyrsnB5bxl8sjsRDcrkodmEF08lJl',1,art + 'HOTVOD.png')
        addDir('[COLOR aqua]מועדון החנונים[/COLOR]','PLnzhIyrsnB5bmIlwndIpo7tuLJZT4dnPl',1,art + 'HOTVOD.png')
        addDir('[COLOR aqua]הקלמרים[/COLOR]','PLnzhIyrsnB5YCnG2GryC_jFjDLCZoMLax',1,art + 'HOTVOD.png')
        addDir('[COLOR aqua]הפיגמות[/COLOR]','PLnzhIyrsnB5ZtO6UnIyktQIs4_Kysgfki',1,art + 'HOTVOD.png')
        addDir('[COLOR aqua]שכונה[/COLOR]','PL419YR22ubLAeiTiDZ3oHDtPmD54vi2vB',1,art + 'HOTVOD.png')
        addDir('[COLOR aqua]גיא ביער החיות[/COLOR]','PL419YR22ubLD1JcHPAtU_KFQ-53xOZ9YP',1,art + 'HOTVOD.png')
        addDir('[COLOR aqua]החוף של רינת - 2[/COLOR]','PL419YR22ubLB2k8pelTCjEcf9vtOdJPMX',1,art + 'HOTVOD.png')
        addDir('[COLOR aqua]עמרי והפיה יעלי[/COLOR]','PL419YR22ubLBPUYYOTxv3y4J4jadrvBDM',1,art + 'HOTVOD.png')
        addDir('[COLOR aqua]חיפזון וזהירון [/COLOR]','PL419YR22ubLCBKso-lZI46QeMOajbJo1K',1,art + 'HOTVOD.png')
        addDir('[COLOR aqua]החוף של רינת - עונה 1[/COLOR]','PL419YR22ubLDmN4nWRYdtXsPEqfUcwXTu',1,art + 'HOTVOD.png')
        addDir('[COLOR aqua]רוני וקשיו[/COLOR]','PLFC30D9236B6C1D89',1,art + 'HOTVOD.png')
        addDir('[COLOR aqua]הגרוטיאדה[/COLOR]','PLD410CE40090B6F46',1,art + 'HOTVOD.png')	
        addDir('[COLOR aqua]מותק של יומולדת[/COLOR]','PL19F7B03ACE78D040',1,art + 'HOTVOD.png')
        addDir('[COLOR aqua]מלכת קסמים[/COLOR]','PL252279467C3A6572',1,art + 'HOTVOD.png')

		
def hop():
        addDir3('[COLOR aqua]סמי הכבאי [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=סמי הכבאי&url=www",35,art + 'kids.png')
        addDir3('[COLOR aqua]פיטר הארנב [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=פיטר הארנב&url=www",35,art + 'kids.png')
        addDir3('[COLOR aqua]דני שובבני [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=דני שובבני&url=www",35,art + 'kids.png')
        addDir3('[COLOR aqua]סבא טוביה [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=סבא טוביה&url=www",35,art + 'kids.png')
        addDir('[COLOR aqua]מיכל הקטנה הופ[/COLOR]','PLnzhIyrsnB5ZXcKexGucWUf2ifAd5dEQj',1,art + 'hop.png')
        addDir('[COLOR aqua]מר עגבניה יובל המבולבל[/COLOR]','PLfcYs4SRZfuLibKBZbJKnGpbPf9XxtRWZ',1,art + 'hop.png')
        addDir('[COLOR aqua]יובל המבולבל[/COLOR]','PLfcYs4SRZfuIrU-AvQvAoJ01gW-EnlfHw',1,art + 'hop.png')
        addDir3('[COLOR aqua]בוב הבנאי [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=בוב הבנאי&url=www",35,art + 'kids.png')
        addDir('[COLOR aqua]מולי וצומי[/COLOR]','PLfcYs4SRZfuJHmb8y_BpUpzAsm1guoAlK',1,art + 'hop.png')
        addDir('[COLOR aqua]חבורת חשבונבונים[/COLOR]','PLfcYs4SRZfuLfZHSFxkaT55Hd6nw5N2hi',1,art + 'hop.png')
        addDir('[COLOR aqua]היקום שלי[/COLOR]','PLfcYs4SRZfuLc0EsDe3Hu3o98Dsv_6m9M',1,art + 'hop.png')
        addDir('[COLOR aqua]חזרה לגן ולבית הספר[/COLOR]','PLfcYs4SRZfuJSXTLmVphH2f7bDvs-6p6u',1,art + 'hop.png')
        addDir('[COLOR aqua]החיוך של רוזי[/COLOR]','PLfcYs4SRZfuKA9uxEK0kvYZNOObplk5jK',1,art + 'hop.png')	

def hopy():
        addDir('[COLOR aqua]שירים ברצף לילדים[/COLOR]','PL6jaO-hu0IvypWmNRJxwG8JP9S2PoDdq-',1,art + 'hopy.jpg')
        addDir3('[COLOR aqua]שירי נעמי שמר [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=שירי נעמי שמר&url=www",35,art + 'kids.png')
        addDir3('[COLOR aqua]שירי אריק איינשטיין - שירים ילדים [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=שירי אריק איינשטיין - שירים ילדים&url=www",35,art + 'kids.png')
        addDir('[COLOR aqua]שירי לאה גולדברג [/COLOR]','PL6jaO-hu0IvxLOnGOzzxXbjOR66OdFRO5',1,art + 'hopy.jpg')
        addDir('[COLOR aqua]גילי בא לבקר[/COLOR]','PL6jaO-hu0IvwPjfkrAicOe1bq-orEN1TT',1,art + 'hopy.jpg')
        addDir('[COLOR aqua]שירי חיות לילדים[/COLOR]','PL6jaO-hu0IvznDFo8JyQRHRUP5l6DoxT2',1,art + 'hopy.jpg')
        addDir('[COLOR aqua]שירים לפעוטות[/COLOR]','PL6jaO-hu0IvydJtUigNLeFFUq1vXZtCk3',1,art + 'hopy.jpg')
        addDir('[COLOR aqua]שירים לילדים לקראת השינה[/COLOR]','PL6jaO-hu0IvznQlhRRKBY6M_ykDXxdB0r',1,art + 'hopy.jpg')
        addDir('[COLOR aqua]דפנה ואורי - שירים ישראלים[/COLOR]','PL6jaO-hu0IvyE-cdcwbQ8bhxZnUr2jflq',1,art + 'hopy.jpg')
       				
def nickjunior():
        addDir('[COLOR aqua]מגלים עם דורה[/COLOR]','PLnzhIyrsnB5Y7_fxFIhYzmMggxTnl5kAv',1,art + '30031.jpg')
        addDir('[COLOR aqua]מפרץ ההרפתקאות[/COLOR]','PLnzhIyrsnB5ZlawaEzYVXU_YwDIUPeE4K',1,art + '30031.jpg')
        addDir('[COLOR aqua]תמר הבלשית[/COLOR]','PLPWc8VdaIIsAki2FqbtHQ7xW3zIMCTL3d',1,art + '30031.jpg')
        addDir('[COLOR aqua]ענבלי בא לי[/COLOR]','PLPWc8VdaIIsB2vKN57J-hZAk8nqGpa4EF',1,art + '30031.jpg')
        addDir('[COLOR aqua]זמן לזוז[/COLOR]','PLPWc8VdaIIsDYbIQJMDX4usMYw7pYmPxj',1,art + '30031.jpg')
        addDir('[COLOR aqua]הסוד של מיה[/COLOR]','PLPWc8VdaIIsCGEVOC2iJxnWNEjI13xbnA',1,art + '30031.jpg')
        addDir('[COLOR aqua]עולמו הקסום של מקס[/COLOR]','PLPWc8VdaIIsCeVQhASYBNmykK4gKh0DCe',1,art + '30031.jpg')
        addDir('[COLOR aqua]מר למה וגברת ככה[/COLOR]','PLPWc8VdaIIsC8iEN7EhY46jmy93imkpHI',1,art + '30031.jpg')
        addDir('[COLOR aqua]משפחת יומולדת[/COLOR]','PLPWc8VdaIIsBOUPxtM2CD7yGs1D8NCM_Z',1,art + '30031.jpg')
        addDir('[COLOR aqua]שטויות בחדשות [/COLOR]','PLPWc8VdaIIsBzxaUfj3smv1tJ8sKQXwrW',1,art + '30031.jpg')
        addDir('[COLOR aqua]בגינה של לין[/COLOR]','PLPWc8VdaIIsDcjHMTBavJG-Rm8p0wvvW_',1,art + '30031.jpg')
        addDir('[COLOR aqua]סיפורי פיות[/COLOR]','PLPWc8VdaIIsD8YvtRkkqjYC5SF7TKvAcM',1,art + '30031.jpg')
        addDir('[COLOR aqua]יצירה בקצרה[/COLOR]','PLPWc8VdaIIsC0SPM0_dgOVIDn5vcCH8Ti',1,art + '30031.jpg')
        addDir('[COLOR aqua]שלוש ארבע לעבודה[/COLOR]','PLPWc8VdaIIsASIzs8TcS3FFYEL68jBPWO',1,art + '30031.jpg')
        addDir('[COLOR aqua]רוני וקשיו[/COLOR]','PLPWc8VdaIIsDPb04SHd5fzzqYt3FtmWs-',1,art + 'Cartoons.png')
		
def luly():
        addDir('[COLOR aqua]לולי ספיישלים - פרקים מלאים ברצף[/COLOR]','PLTleo-h9TFqLYSNebLcKWr2outn2xYRhe',1,art + 'luly.jpg')
        addDir('[COLOR aqua]טלטאביז[/COLOR]','PLCVlyUabAQX0baRcL13edNd1zBeqLuoaV',1,art + 'luly.jpg')
        addDir('[COLOR aqua]מיילו[/COLOR]','PLTleo-h9TFqJI6GrNCJO9yjyXbZHS9X-F',1,art + 'luly.jpg')
        addDir('[COLOR aqua]טוקטוק[/COLOR]','PLTleo-h9TFqKkr82pGJe-bk1pMMxFg_b-',1,art + 'luly.jpg')
        addDir('[COLOR aqua]צרלי ודודו[/COLOR]','PLTleo-h9TFqK3NlYz7T3fz6XGRfTVk2FH',1,art + 'luly.jpg')
        addDir('[COLOR aqua]חיות בערוץ לולי[/COLOR]','PLTleo-h9TFqI2CFuWeFA-Q2Bu3BBHdXqv',1,art + 'luly.jpg')
        addDir('[COLOR aqua]לולי למתחילים[/COLOR]','PLTleo-h9TFqKzWTiRE8-uIG8cWqSu0FW8',1,art + 'luly.jpg')
        addDir('[COLOR aqua]קוקו הארנב[/COLOR]','PLnzhIyrsnB5bntEbuvQNa4VqJ0dOaOVtD',1,art + 'luly.jpg')
        addDir('[COLOR aqua]חבורת אבאדס[/COLOR]','PLTleo-h9TFqLym2Yg3-l_TJeqigJFstsE',1,art + 'luly.jpg')
        addDir('[COLOR aqua]בומבה[/COLOR]','PLTleo-h9TFqLkb8a4Y9aeuZUH0W436ah7',1,art + 'luly.jpg')
        addDir('[COLOR aqua]בונים מבלונים[/COLOR]','PLTleo-h9TFqK-0raN5AabE_YjlNsLj-hb',1,art + 'luly.jpg')
        addDir('[COLOR aqua]להלילו[/COLOR]','PLTleo-h9TFqJsNpiGgyKbJyqjBJxyBBZe',1,art + 'luly.jpg')

def baby():       
        addDir('[COLOR aqua]ערוץ בייבי - תוכניות ברצף[/COLOR]','PLErYJg2XgxyWqQlU1CqCdPs15WhnAzzwb',1,art + 'baby.jpg')
        addDir('[COLOR aqua]שירים ישראליים לילדים[/COLOR]','PLErYJg2XgxyXTMAJvmFXoW6Qe66Ztw0Fk',1,art + 'baby.jpg')
        addDir('[COLOR aqua]קיץ עם ערוץ בייבי[/COLOR]','PLErYJg2XgxyWdetl6GmsKjp4hIlaR6BDl',1,art + 'baby.jpg')
        addDir('[COLOR aqua]פרקים מיוחדים ליום ההולדת[/COLOR]','PLErYJg2XgxyWWl7sL3Oh25LxgXe5Vgpwz',1,art + 'baby.jpg')
        addDir3('[COLOR aqua]חגי ישראל עם רינת גבאי ומימי [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=חגי ישראל עם רינת גבאי ומימי&url=www",35,art + 'kids.png')
        addDir('[COLOR aqua]חורף עם ערוץ בייבי[/COLOR]','PLErYJg2XgxyV4DL2r3vpo74zeJuWa8K1x',1,art + 'baby.jpg')
        addDir('[COLOR aqua]אוצר מילים עם נוני[/COLOR]','PLErYJg2XgxyXmgk6cyROtlJh2g-Fk_T6n',1,art + 'baby.jpg')
        addDir('[COLOR aqua]רינת גבאי ומימי בארץ המילים[/COLOR]','PLErYJg2XgxyX7c9LjwlY22F3cjpI5h6V_',1,art + 'baby.jpg')
        addDir('[COLOR aqua]דרקו ותולי[/COLOR]','PLErYJg2XgxyVJhg76kIibughL6QiHgN2-',1,art + 'baby.jpg')
        addDir('[COLOR aqua]אוליבר[/COLOR]','PLErYJg2XgxyX1gmsKze-1WjpDoNefNYJD',1,art + 'baby.jpg')
        addDir('[COLOR aqua]מתכוננים לשינה עם ערוץ בייבי[/COLOR]','PLErYJg2XgxyVYzsbPxH2dzhlWLs9sWGTa',1,art + 'baby.jpg')		
        addDir('[COLOR aqua]רינת גבאי בעולם האגדות[/COLOR]','PLErYJg2XgxyWiffjko4BQmExqDdR6-C4v',1,art + 'baby.jpg')
		
def logy():
        addDir('[COLOR aqua]היה היה[/COLOR]','PL7FRY7ROxqHQQFHpxmJ6r-xiB1K0BwGdu',1,art + '30033.jpg')
        addDir('[COLOR aqua]אין חיה כזאת - ממושה[/COLOR]','PLnzhIyrsnB5bFcWJAIfnnkPVcu_Owmagv',1,art + '30033.jpg')
        addDir('[COLOR aqua]קני הכריש[/COLOR]','PLD_Y4wLedlhqRCLLpVWlqg6g7k9F8t98J',1,art + '30033.jpg')
        addDir3('[COLOR aqua]אוטובוס הקסמים [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=אוטובוס הקסמים&url=www",35,art + 'kids.png')
        addDir('[COLOR aqua]הובס ספר הקסמים הגדול[/COLOR]','PLnzhIyrsnB5Y9PQ5k5jG0fr1V3LJTuFHN',1,art + '30033.jpg')
        addDir('[COLOR aqua]המובילים עונה 1[/COLOR]','PL-SBsAk8heRmm43KBeVhC9h6R6wCUSW7j',1,art + '30033.jpg')
        addDir('[COLOR aqua]המובילים עונה 2[/COLOR]','PLBaGngHK8wj1OxzO6P3ouBUulIG4fijkG',1,art + '30033.jpg')
        addDir('[COLOR aqua]המובילים עונה 3[/COLOR]','PLBGBC8WmVUB9xGVomRmpLtFAsrbBhRHx0',1,art + '30033.jpg')
        addDir('[COLOR aqua]כח מילולית[/COLOR]','PLnzhIyrsnB5ZUB06GBVvhZ93hPaoy9Mv1',1,art + '30033.jpg')		

def nicklodeon():
        addDir('[COLOR aqua]הצחוקייה 1-4: פרקים מלאים[/COLOR]','PLuQCYUv97StSnZGTUoMyIjbFdAACRCxKV',1,art + '30032.jpg')
        addDir('[COLOR aqua]צמפיונסיק[/COLOR]','PLuQCYUv97StRAe0OQOvWUBejgQVAjrucA',1,art + '30032.jpg')
        addDir('[COLOR aqua]גן חיות 1 + 2[/COLOR]','PLuQCYUv97StTP1kioc4cGBUkdPrktt8Pz',1,art + '30032.jpg')
        addDir('[COLOR aqua]גן חיות עונה 3[/COLOR]','PLuQCYUv97StQfg1CrmkR5ChUnu6q1X5Hj',1,art + '30032.jpg')
        addDir('[COLOR aqua]משפחת כספי[/COLOR]','PLuQCYUv97StRNroygQpznlYXzyvob8aDJ',1,art + '30032.jpg')
        addDir('[COLOR aqua]שכונה[/COLOR]','PLuQCYUv97StQ1q3po2cwh48H6LOSZbjaM',1,art + '30032.jpg')
        addDir('[COLOR aqua]הצחוקייה סופרסטארז[/COLOR]','PLuQCYUv97StQ5w1484WOSYjwFfhiQsnPy',1,art + '30032.jpg')
        addDir('[COLOR aqua]הצחוקייה - קצרצרים, עונות 3-1[/COLOR]','PLuQCYUv97StTBH8qBwHzw12DHe7Zn78Qx',1,art + '30032.jpg')
        addDir('[COLOR aqua]שכונה[/COLOR]','PLuQCYUv97StR0o1N7zfbpobVVwev0sx91',1,art + '30032.jpg')
        addDir('[COLOR aqua]יפניק[/COLOR]','PLuQCYUv97StS-YtE8BYNUpLIxKrGOBAe6',1,art + '30032.jpg')
        addDir('[COLOR aqua]סופר שטותניק[/COLOR]','PLuQCYUv97StRk-DsmuAL0ptZPJ9ATkguV',1,art + '30032.jpg')
        addDir('[COLOR aqua]חבורת הספסל האחורי[/COLOR]','PLuQCYUv97StTLZK9Zicyj4qfyiVh0DbkN',1,art + '30032.jpg')
        addDir('[COLOR aqua]קיץ דיגיטלי[/COLOR]','PLuQCYUv97StT2i_JrYVDy2cVTW1Gtmp9s',1,art + '30032.jpg')
		
def lifestyle():       
        addDir('[COLOR aqua]'+translate(10013)+'[/COLOR]','PLCXKcf_9F-9ILiz6gapk-g6eRVczIinXn',1,art + 'lifestyle.png')
        addDir('[COLOR aqua]'+translate(10014)+'[/COLOR]','PLvw1iwpJo48E7MsgyxQwthpjYdMJV4a2l',1,art + 'lifestyle.png')
        addDir('[COLOR aqua]'+translate(10015)+'[/COLOR]','PLBQgA3Kndk7eYrJwHej6Swx-nryBmN52V',1,art + 'lifestyle.png')
        addDir('[COLOR aqua]'+translate(10016)+'[/COLOR]','PLK_DOFD1-caZyw7DH1PeghrCeAa0RXKGl',1,art + 'lifestyle.png')
        addDir('[COLOR aqua]'+translate(10017)+'[/COLOR]','PLE403X8vX2i1nabZsuGAZT7KaJTtX6_iu',1,art + 'lifestyle.png')
        addDir('[COLOR aqua]'+translate(10018)+'[/COLOR]','PLPJTnhnYa-pOndAB5TU2A8qEpUguaxj5U',1,art + 'lifestyle.png')
        addDir('[COLOR aqua]'+translate(10019)+'[/COLOR]','PL40DAF9063E60BD47',1,art + 'lifestyle.png')
        addDir('[COLOR aqua]'+translate(10012)+'[/COLOR]','PLP1X5PjaY0cw-jNeYM5itPwNC89L6K6ee',1,art + 'lifestyle.png')
        addDir('[COLOR aqua]'+translate(10020)+'[/COLOR]','PLnzhIyrsnB5b2kjwaZOLmoGPBXU4IPpXi',1,art + 'lifestyle.png')
        addDir('[COLOR aqua]'+translate(10021)+'[/COLOR]','PLoCBhUDrfgwpkBF9LGJzjcdqrA5BzGnn1',1,art + 'lifestyle.png')
        addDir('[COLOR aqua]'+translate(10023)+'[/COLOR]','PLWSwSEhBdIBKsVqaZn9PwebkLguJX3vSM',1,art + 'lifestyle.png')
        addDir('[COLOR aqua]'+translate(10024)+'[/COLOR]','PLoCBhUDrfgwqhdtQo2pMtMr4a3i3FLjOy',1,art + 'lifestyle.png')
        addDir('[COLOR aqua]'+translate(10025)+'[/COLOR]','PLYMK_Nbs-rsupx1SLcgZFXnfy7HZ3KRoN',1,art + 'lifestyle.png')
        addDir('[COLOR aqua]'+translate(10026)+'[/COLOR]','PLKUX44R3MbuR3sX61i9QiwnOBr61tEMc_',1,art + 'lifestyle.png')
        addDir('[COLOR aqua]'+translate(10027)+'[/COLOR]','PLE0ZXwRBc5iNxdziR3nGtfZoi11p2y0hO',1,art + 'lifestyle.png')
        addDir('[COLOR aqua]'+translate(10028)+'[/COLOR]','PLP3V-LOuN7YX5yIWumBvrDGJ_Dt355Wd7',1,art + 'lifestyle.png')
        addDir('[COLOR aqua]'+translate(10029)+'[/COLOR]','PLE403X8vX2i12ajSfJmY9MZ2tRfWwA11X',1,art + 'lifestyle.png')

def documentary():                
        addDir3('[COLOR aqua]דוקו בעברית[/COLOR]','plugin://plugin.video.MyYoutube/kodion/search/query/?q=%d7%93%d7%95%d7%a7%d7%95%d7%9e%d7%a0%d7%98%d7%a8%d7%99%20%d7%99%d7%a9%d7%a8%d7%90%d7%9c%d7%99',35,art + 'documentary.jpg')
        #addDir('[COLOR aqua]סרטוני טבע בעברית[/COLOR]','PLnzhIyrsnB5Y8Ymf2ryG-LlX0DxK0JD5N',1,art + 'documentary.jpg')
        addDir3('[COLOR aqua]זמן אמת[/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=זמן אמת &url=www",35,art + 'documentary.jpg')		
        addDir3('[COLOR aqua]חוצה ישראל[/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=חוצה ישראל &url=www",35,art + 'documentary.jpg')
        #addDir('[COLOR aqua]דוקומנטרי עם רינו צרור[/COLOR]','PLnzhIyrsnB5ahqRF_z2KwVFffa65NbDyR',1,art + 'documentary.jpg')
        addDir3('[COLOR aqua]טבע לילדים בעברית [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=טבע לילדים בעברית&url=www",35,art + 'documentary.jpg.jpg')
        #addDir('[COLOR aqua]סרטונים נבחרים נשיונל גאוגרפיק[/COLOR]','PLivjPDlt6ApQ8vBgHkeEjeRJjzqUGv9dV',1,art + 'documentary.jpg')
        #addDir('[COLOR aqua]סרטונים פופולריים סרטי טבע תיעודיים[/COLOR]','PL5o3ll3G4acxgDMSO7JXvDsosQ-UDPL6n',1,art + 'documentary.jpg')
        addDir3('[COLOR aqua]נשיונל גיאוגרפיק[/COLOR]','plugin://plugin.video.MyYoutube/kodion/search/query/?q=national%20geographic',35,art + 'documentary.jpg')
        addDir3('[COLOR aqua]Net Geo Wild[/COLOR]','plugin://plugin.video.MyYoutube/kodion/search/query/?q=Net%20Geo%20Wild',35,art + 'documentary.jpg')
        addDir3('[COLOR aqua]דיסקברי[/COLOR]','plugin://plugin.video.MyYoutube/kodion/search/query/?q=discovery',35,art + 'documentary.jpg')
        addDir3('[COLOR aqua]דוקומנטרי BBC[/COLOR]','plugin://plugin.video.MyYoutube/kodion/search/query/?q=bbc%20documentary',35,art + 'documentary.jpg')
        addDir3('[COLOR aqua]סרטוני טבע HD [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=סרטוני טבע HD&url=www",35,art + 'documentary.jpg.jpg')
        addDir3('[COLOR aqua]טבע וחיות בר HD [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=טבע וחיות בר HD&url=www",35,art + 'documentary.jpg.jpg')
        addDir3('[COLOR aqua]אוקיינוס[/COLOR]','plugin://plugin.video.MyYoutube/kodion/search/query/?q=ocean%20documentary',35,art + 'documentary.jpg')
        addDir3('[COLOR aqua]אפריקה[/COLOR]','plugin://plugin.video.MyYoutube/kodion/search/query/?q=africa%20documentary',35,art + 'documentary.jpg')
        #addDir('[COLOR aqua]רוסיה הפראית[/COLOR]','PLql7ZywaMwm0qsDq7eziLHbtmHkD77aCj',1,art + 'documentary.jpg')
        addDir3('[COLOR aqua]מדע[/COLOR]','plugin://plugin.video.MyYoutube/kodion/search/query/?q=science%20documentary',35,art + 'documentary.jpg')
        addDir3('[COLOR aqua]דינוזאורים[/COLOR]','plugin://plugin.video.MyYoutube/kodion/search/query/?q=dinosaur%20documentary',35,art + 'documentary.jpg')
        addDir3('[COLOR aqua]חיות קטלניות[/COLOR]','plugin://plugin.video.MyYoutube/kodion/search/query/?q=deadly%20animals',35,art + 'documentary.jpg')
        addDir3('[COLOR aqua]כרישים[/COLOR]','plugin://plugin.video.MyYoutube/kodion/search/query/?q=sharks%20documentary',35,art + 'documentary.jpg')
        addDir3('[COLOR aqua]נחשים[/COLOR]','plugin://plugin.video.MyYoutube/kodion/search/query/?q=snakes%20documentary',35,art + 'documentary.jpg')        
        addDir3('[COLOR aqua]ציפורים[/COLOR]','plugin://plugin.video.MyYoutube/kodion/search/query/?q=birds%20documentary',35,art + 'documentary.jpg')
        #addDir('[COLOR aqua]תנינים[/COLOR]','PLnzhIyrsnB5YPDK-se-BkGWaDjPER-0jp',1,art + 'documentary.jpg')
        #addDir('[COLOR aqua]דובים[/COLOR]','PLnzhIyrsnB5ZuhAQyz6kzcmlAl_K18Jvl',1,art + 'documentary.jpg')
        #addDir('[COLOR aqua]אריות[/COLOR]','PLnzhIyrsnB5bFPCKp6A5afJiE0S1-s_C6',1,art + 'documentary.jpg')
        #addDir('[COLOR aqua]חרקים[/COLOR]','PL1bLcCen2CCeRW-XeL1Nvgn7hpeSlqab7',1,art + 'documentary.jpg')
        #addDir('[COLOR aqua]צמחים[/COLOR]','PL1bLcCen2CCcObVIYmrFePh4J2oy3ITWJ',1,art + 'documentary.jpg')
        addDir('[COLOR aqua]איך זה פועל[/COLOR]','PLLgqOez346ZPcqnmLsDkqr0kPjuRz5Rjo',1,art + 'documentary.jpg')
        addDir3('[COLOR aqua]חוצנים[/COLOR]','plugin://plugin.video.MyYoutube/kodion/search/query/?q=aliens%20documentary',35,art + 'documentary.jpg')
        addDir('[COLOR aqua]קונספירציות מתורגם[/COLOR]','PLnzhIyrsnB5b2OK0deM0-QnSFc4___ePC',1,art + 'documentary.jpg')
        addDir3('[COLOR aqua]קונספירציות לועזית[/COLOR]','plugin://plugin.video.MyYoutube/kodion/search/query/?q=conspiracy%20documentary',35,art + 'documentary.jpg')
        addDir3('[COLOR aqua]מערכת השמש[/COLOR]','plugin://plugin.video.MyYoutube/kodion/search/query/?q=solar%20system%20documentary',35,art + 'documentary.jpg')
        addDir3('[COLOR aqua]חורים שחורים [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=חורים שחורים&url=www",35,art + 'documentary.jpg')
        #addDir('[COLOR aqua]סיפורים מעוררי השראה[/COLOR]','PLUkdT9ljJ1cYE-Mxn43WRf_0Gq4oWa-QD',1,art + 'documentary.jpg')		
        #addDir('[COLOR aqua]חיות מחמד יוצאות דופן[/COLOR]','PLUkdT9ljJ1caovAwonqPel9hYzk8V1j4l',1,art + 'documentary.jpg')		
        addDir3('[COLOR aqua]היסטוריה[/COLOR]','plugin://plugin.video.MyYoutube/kodion/search/query/?q=history%20documentary',35,art + 'documentary.jpg')
        #addDir('[COLOR aqua]ערוץ ההיסטוריה DECISIVE BATTLES[/COLOR]','PL3H6z037pboH81MoHl8zcbugf2onvFcDc',1,art + 'documentary.jpg')
        #addDir('[COLOR aqua]ערוץ ההיסטוריה THE REAL WILD WEST[/COLOR]','PL3H6z037pboG9_flx9II9XMO5VE_1qHtR',1,art + 'documentary.jpg')
        #addDir('[COLOR aqua]ערוץ ההיסטוריה The Conquerors[/COLOR]','PLSBILXkL0K2tuApKAbXqwkoRgkq2ixifw',1,art + 'documentary.jpg')
		
def Music():
        addDir3('[COLOR aqua]מוזיקה ישראלית[/COLOR]','plugin://plugin.video.MyYoutube/kodion/search/query/?q=%d7%9e%d7%95%d7%96%d7%99%d7%a7%d7%94%20%d7%99%d7%a9%d7%a8%d7%90%d7%9c%d7%99%d7%aa&search_type=playlist',35,art + 'Music.png')
        addDir3('[COLOR aqua]מוזיקה לועזית[/COLOR]','plugin://plugin.video.MyYoutube/kodion/search/query/?q=%d7%9e%d7%95%d7%96%d7%99%d7%a7%d7%94%20%d7%9c%d7%95%d7%a2%d7%96%d7%99%d7%aa&search_type=playlist',35,art + 'Music.png')
        addDir3('[COLOR aqua]שירים ישראליים מכל הזמנים [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=שירים ישראליים מכל הזמנים&url=www",35,art + 'Music.png')
        #addDir('[COLOR aqua]שירים ישראליים מרגשים[/COLOR]','PLryjW6BWLS1Q_xeVOlPfXJF4S3G0purex',1,art + 'Music.png')
        addDir3('[COLOR aqua]דאנס מזרחי[/COLOR]','plugin://plugin.video.MyYoutube/kodion/search/query/?q=%d7%93%d7%90%d7%a0%d7%a1%20%d7%9e%d7%96%d7%a8%d7%97%d7%99',35,art + 'Music.png')
        addDir3('[COLOR aqua]מזרחית קצבית [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=מזרחית קצבית&url=www",35,art + 'Music.png')
        #addDir('[COLOR aqua]טראקים לחדר כושר[/COLOR]','PL9239ABA016845864',1,art + 'Music.png')
        #addDir('[COLOR aqua]פלייליסט אירובי[/COLOR]','PL1oz4IM59QGMmlAYTP2d1l9GeV4TS0hXV',1,art + 'Music.png')
        #addDir('[COLOR aqua]סרטונים חדשים[/COLOR]','PLrEnWoR732-D67iteOI6DPdJH1opjAuJt',1,art + 'Music.png')
        #addDir('[COLOR aqua]סרטוני וידאו פופולריים[/COLOR]','PLFgquLnL59alCl_2TQvOiD5Vgm1hCaGSI',1,art + 'Music.png')
        addDir3('[COLOR aqua]Billboard[/COLOR]','plugin://plugin.video.MyYoutube/kodion/search/query/?q=Billboard',35,art + 'Music.png')
        addDir3('[COLOR aqua]Mtv[/COLOR]','plugin://plugin.video.MyYoutube/kodion/search/query/?q=mtv&search_type=playlist',35,art + 'Music.png')
        addDir3('[COLOR aqua]Vevo [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=Vevo&url=www",35,art + 'Music.png')
        addDir3('[COLOR aqua]שנות ה 80&90[/COLOR]','plugin://plugin.video.MyYoutube/kodion/search/query/?q=80s%20music&search_type=playlist',35,art + 'Music.png')
        #addDir('[COLOR aqua]שנות ה 80&90[/COLOR]','PL3485902CC4FB6C67',1,art + 'Music.png')
        addDir('[COLOR aqua]להיטי שנות ה 70[/COLOR]','PLGBuKfnErZlAkaUUy57-mR97f8SBgMNHh',1,art + 'Music.png')
        addDir('[COLOR aqua]להיטי שנות ה 60[/COLOR]','PLuK6flVU_Aj5EJ9Pp-C9N7XA0YJr_GrJI',1,art + 'Music.png')
        addDir('[COLOR aqua]להיטי שנות ה 50[/COLOR]','PLuK6flVU_Aj45QZ_A5ld0-pP3CIkoNQDk',1,art + 'Music.png')
        #addDir('[COLOR aqua]להיטי קאנטרי[/COLOR]','PL2BN1Zd8U_MsyMeK8r9Vdv1lnQGtoJaSa',1,art + 'Music.png')
		
def travel():
        addDir('[COLOR aqua]ערוץ הטיולים - לטייל[/COLOR]','PLeh1TPHGKHcC0frpxT30gpX32Mc1DMStx',1,art + 'travel.png')
        addDir('[COLOR aqua]המדריך לתייר בגלקסיה[/COLOR]','PLeh1TPHGKHcAriEIJEPLnZ7Qsm3Fh6ELx',1,art + 'travel.png')
        addDir3('[COLOR aqua]אוכל רחוב מסביב לעולם [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=אוכל רחוב מסביב לעולם&url=www",35,art + 'travel.png')
        addDir('[COLOR aqua]סקי וסנובורד[/COLOR]','PLFZHg-6S5_GcrVsP97cT7KoYQQD5vNEQr',1,art + 'travel.png')
        addDir('[COLOR aqua]טיולי משפחות[/COLOR]','PLFZHg-6S5_GfMOlbWErniSqxw9ygllSGL',1,art + 'travel.png')
        addDir('[COLOR aqua]טיולים בעולם[/COLOR]','PLFZHg-6S5_GcIWZJp6-o4lo4vSuDQrrPt',1,art + 'travel.png')
        addDir('[COLOR aqua]מדריכי טיולים - אשת טורס[/COLOR]','PL1E93715FC3C00F68',1,art + 'travel.png')
        addDir('[COLOR aqua]עצות המומחים - כל מה שצריך לדעת על ציוד טיולים[/COLOR]','PLFZHg-6S5_GcQdP7V_Q3-6HF9pTUWQ8I_',1,art + 'travel.png')
        addDir('[COLOR aqua]'+translate(70003)+'[/COLOR]','PLnzhIyrsnB5ZjRuqUWplT_8GGcVS6lKFN',1,art + 'travel.png')
        addDir('[COLOR aqua]'+translate(70004)+'[/COLOR]','PLnzhIyrsnB5ZNE1PhI4hWyyvE6gbieoFs',1,art + 'travel.png')
        addDir('[COLOR aqua]ערים בעולם - מדריך טיולים[/COLOR]','PLe9OS0jiMKcJ28LhxyvJzHrVGfI2AJe-q',1,art + 'travel.png')
        addDir('[COLOR aqua]אירופה - מדריך טיולים[/COLOR]','PLDlvzhdA4-Pdv-zwkSUGr5-Bu_nn_33bP',1,art + 'travel.png')
        addDir('[COLOR aqua]צפון אמריקה - מדריך טיולים[/COLOR]','PLdgCSoJzrmKHhvEWqmb3-1tUQmT8ZWBrv',1,art + 'travel.png')
        addDir('[COLOR aqua]אפריקה - מדריך טיולים[/COLOR]','PLDlvzhdA4-PeKVe1Tyf8EZYhxCunhYwgG',1,art + 'travel.png')
        addDir('[COLOR aqua]יפן - מדריך טיולים[/COLOR]','PL14F9F774CE8798C3',1,art + 'travel.png')
        addDir('[COLOR aqua]ארצות הברית - מדריך טיולים[/COLOR]','PLOVadUHX1B-Kv1gRgHpJoe33hGodcPi8R',1,art + 'travel.png')
        addDir('[COLOR aqua]מדריך טיולים לערים שונות בעולם[/COLOR]','PL-NQ0KYodq5MkFgQJEpWTGELcEaLIJdVx',1,art + 'travel.png')
        addDir('[COLOR aqua]רומא - מדריך טיולים[/COLOR]','PLEC3E8FCF38E57252',1,art + 'travel.png')
        addDir('[COLOR aqua]סרטונים פופולריים – Travel Channel[/COLOR]','PL_xzw4jKGLrlQKx7hvUF5B5FvVhzUtvw6',1,art + 'travel.png')
        addDir('[COLOR aqua]אוכל ביזארי עם Andrew Zimmern[/COLOR]','PL7Yaf7nQHP3CM6bLT6acdsOhQoKCmb75c',1,art + 'travel.png')
        addDir('[COLOR aqua]סרטונים פופולריים – Aerial America[/COLOR]','PLnr8iIChmNnEy89DZIe6DKSeS4qKAe1hx',1,art + 'travel.png')
        addDir('[COLOR aqua]סרטונים פופולריים – Hotel Impossible[/COLOR]','PLF_H8SZXratCdL4Mv3fHRVfnj2SYw3bxr',1,art + 'travel.png')
		
def cooking():
        addDir('[COLOR aqua]מתכונים כלליים[/COLOR]','PLF685A5B80B86FE3B',1,art + 'cooking.png')
        addDir('[COLOR aqua]מתכונים כשרים[/COLOR]','PL3zcxKFd7HIKL3oSXq6rCH-fvFGCaOaS9',1,art + 'cooking.png')
        addDir('[COLOR aqua]מתכונים. מטבח יהודי ומזרח ים תיכוני[/COLOR]','PLRUtxvlnaqwx3KugKPtd4C3Iexv0Ee5U3',1,art + 'cooking.png')
        addDir('[COLOR aqua]'+translate(70002)+'[/COLOR]','PLnzhIyrsnB5YJYfCNr4B9ewwTMhzS8pn9',1,art + 'cooking.png')
        addDir('[COLOR aqua]'+translate(70004)+'[/COLOR]','PLnzhIyrsnB5ZNE1PhI4hWyyvE6gbieoFs',1,art + 'cooking.png')       
        addDir('[COLOR aqua]סודות מתוקים עונה 1[/COLOR]','ELAMi0KPlVcsg',1,art + 'cooking.png')
        addDir('[COLOR aqua]סודות מתוקים עונה 3[/COLOR]','ELmeqByVOghVE',1,art + 'cooking.png')
        addDir('[COLOR aqua]שגב במטבח[/COLOR]','CLWEuLXV2ejHk',1,art + 'cooking.png')         
        addDir('[COLOR aqua]מיקי שמו[/COLOR]','PLqQIVRFHrR1rsA0RqsAkzMxa2Xc4tcO25',1,art + 'cooking.png')
        addDir('[COLOR aqua]בישולים[/COLOR]','PLkSacTgmGKr6a6sPE1F7q3VF7T00lffQc',1,art + 'cooking.png')
        addDir('[COLOR aqua]בישולים 2[/COLOR]','PLdDyYBhRKiyG21-epuoI57b7zBfAyQcvI',1,art + 'cooking.png') 
        addDir('[COLOR aqua]לאכול - יסודות הבישול - ויקטור גלוגר[/COLOR]','PL8jMo70ebRM5dsJOjJXzGylZny1dnFPI7',1,art + 'cooking.png')         
        addDir('[COLOR aqua]לאכול - חומרי גלם - אוראל קמחי[/COLOR]','PL8jMo70ebRM778yBMGXg5Bb0wKm60wtb3',1,art + 'cooking.png')
        addDir('[COLOR aqua]לאון אל דנטה[/COLOR]','PL8jMo70ebRM7nnRez1MyfKBFLTj9jzl1V',1,art + 'cooking.png')
        addDir('[COLOR aqua]במטבח עם אמא[/COLOR]','PL8jMo70ebRM6gYuy9d7yoPLTGg1asK78w',1,art + 'cooking.png')
        addDir('[COLOR aqua]מיקי שמו עושה בית ספר - עונה ראשונה[/COLOR]','PL8jMo70ebRM7tvFCZsiXhakIsbDwHOe9c',1,art + 'cooking.png')         
        addDir('[COLOR aqua]מועדון ארוחת הבוקר עם אביב משה[/COLOR]','PL8jMo70ebRM6CAq8sKdjfI4_N3qUO5U1j',1,art + 'cooking.png')
        addDir('[COLOR aqua]פשוט לאפות[/COLOR]','PL8jMo70ebRM6aT0ZciSlv_YhP2Kjp1tuk',1,art + 'cooking.png')
        addDir('[COLOR aqua]המטבחון של ירון[/COLOR]','PL156601B302C8F462',1,art + 'cooking.png')
		
def liveshows():
        addDir('[COLOR aqua]זמרים ישראליים[/COLOR]','PLnzhIyrsnB5Ydr8diBFqJ368vCrqAlfbS',1,art + 'liveshows.png')
        addDir3('[COLOR aqua]הופעות חיות לועזית[/COLOR]','plugin://plugin.video.MyYoutube/kodion/search/query/?q=live%20music%20concerts',35,art + 'liveshows.png')
        addDir('[COLOR aqua]זמרים לועזית[/COLOR]','PLnzhIyrsnB5ZPMlMCdRHmuOtbze7KnaSO',1,art + 'liveshows.png')
        addDir3('[COLOR aqua]מוזיקה אלקטרונית[/COLOR]','plugin://plugin.video.MyYoutube/kodion/search/query/?q=live%20music%20concerts%20electro',35,art + 'liveshows.png')
        addDir3('[COLOR aqua]להקות רוק[/COLOR]','plugin://plugin.video.MyYoutube/kodion/search/query/?q=live%20rock%20music%20concerts',35,art + 'liveshows.png')
        addDir3('[COLOR aqua]פופ[/COLOR]','plugin://plugin.video.MyYoutube/kodion/search/query/?q=live%20pop%20music%20concerts',35,art + 'liveshows.png')
        addDir('[COLOR aqua]שנות השמונים[/COLOR]','PLnzhIyrsnB5b8Lcws_X9k5O9jbdRgLXf1',1,art + '80.jpg')
        addDir3('[COLOR aqua]שנות התשעים [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=שנות התשעים&url=www",35,art + 'liveshows.png')
        addDir3('[COLOR aqua]טראנס [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=טראנס&url=www",35,art + 'liveshows.png')
        addDir3('[COLOR aqua]אופרה וקונצרטים [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=אופרה וקונצרטים&url=www",35,art + 'liveshows.png')
        #addDir('[COLOR aqua]קאנטרי[/COLOR]','PLnzhIyrsnB5bt4BgqZt_p5qs3sewWKYMs',1,art + 'liveshows.png')
        addDir3('[COLOR aqua]סול [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=סול&url=www",35,art + 'liveshows.png.jpg')
        addDir3('[COLOR aqua]בלוז [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=בלוז&url=www",35,art + 'liveshows.png.jpg')
        addDir3('[COLOR aqua]ראפ & היפ הופ [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=ראפ & היפ הופ&url=www",35,art + 'liveshows.png.jpg')
        addDir3('[COLOR aqua]גאז [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=גאז&url=www",35,art + 'liveshows.png.jpg')
		
def Sports():        
        addDir('[COLOR aqua]כדורסל[/COLOR]','PLnzhIyrsnB5aAsPRtalXMLlCW8GflCkUY',32,art + 'bas.jpg')	
        addDir('[COLOR aqua]כדורגל[/COLOR]','PLnzhIyrsnB5aAsPRtalXMLlCW8GflCkUY',33,art + 'Soccer.jpg')
        addDir3('[COLOR aqua]קרבות מלאים WWE [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=קרבות מלאים WWE&url=www",35,art + 'Sports.png')
        addDir3('[COLOR aqua]קרבות UFC [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=קרבות UFC&url=www",35,art + 'Sports.png')
        addDir3('[COLOR aqua]אגרוף [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=אגרוף&url=www",35,art + 'Sports.png')
        addDir('[COLOR aqua]פיתוח גוף[/COLOR]','PLYMK_Nbs-rsvOuko4Hqv4Uw6NF2Q3-eCP',1,'http://i141.photobucket.com/albums/r48/kobiko3030/vodil/body_zpso63i0zn8.jpg')
        #addDir('[COLOR aqua]טניס[/COLOR]','PL1bLcCen2CCdPEMJ8B5S6Z9RzLjMnFNvT',1,art + 'Sports.png')	
        #addDir('[COLOR aqua]אתלטיקה קלה[/COLOR]','PLnzhIyrsnB5aAsPRtalXMLlCW8GflCkUY',32,art + 'Sports.png')
        #addDir('[COLOR aqua]כדורעף[/COLOR]','PLnzhIyrsnB5aAsPRtalXMLlCW8GflCkUY',32,art + 'Sports.png')	
        #addDir('[COLOR aqua]כדוריד[/COLOR]','PLnzhIyrsnB5aAsPRtalXMLlCW8GflCkUY',32,art + 'Sports.png')
        #addDir('[COLOR aqua]שחיה[/COLOR]','PLnzhIyrsnB5aAsPRtalXMLlCW8GflCkUY',32,art + 'Sports.png')
        #addDir('[COLOR aqua]כושר ואירובי[/COLOR]','PLnzhIyrsnB5aAsPRtalXMLlCW8GflCkUY',32,art + 'Sports.png')
        #addDir('[COLOR aqua]מרוצי מכוניות[/COLOR]','PLnzhIyrsnB5aAsPRtalXMLlCW8GflCkUY',32,art + 'Sports.png')
        #addDir('[COLOR aqua]ספורט אתגרי[/COLOR]','PLnzhIyrsnB5aAsPRtalXMLlCW8GflCkUY',32,art + 'Sports.png')		
        addDir3('[COLOR aqua]ביתר ירושלים [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=ביתר ירושלים&url=www",35,art + 'Sports.png')
        addDir3('[COLOR aqua]בני יהודה [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=בני יהודה&url=www",35,art + '30034.jpg')		
        addDir3('[COLOR aqua]מכבי חיפה [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=מכבי חיפה&url=www",35,art + 'Sports.png')        		
		
def poker():        
        addDir('[COLOR aqua]Poker After Dark season 6[/COLOR]','PLezGPuTnW9q2r-IBGL5-xpRqp0WRs_K_u',1,art + 'poker.png')	
        addDir('[COLOR aqua]Poker After Dark Season 7[/COLOR]','PLezGPuTnW9q0G223DE4NV3ELuwbckDiDz',1,art + 'poker.png')
        addDir('[COLOR aqua]Party Poker Premier League Poker III Season 3[/COLOR]','PL44f2aflEx4dyH2yIGBUsn2tSH0x0yHZv',1,art + 'poker.png')
        addDir('[COLOR aqua]Party Poker Premier League Poker VII Season 7[/COLOR]','PL44f2aflEx4e_vTo0bXobw1iJxFKLnkzT',1,art + 'poker.png')
        addDir('[COLOR aqua]Poker After Dark season 3[/COLOR]','PLR8ogeEohYWbiuu38N2Q4B8Ly2hiOV13T',1,art + 'poker.png')        
        addDir('[COLOR aqua]Poker After Dark season 4[/COLOR]','PLZ-UUL-0OSx0XgG5rERT4nmqQnF7piFZN',1,art + 'poker.png')		
        addDir('[COLOR aqua]Poker After Dark Season 5[/COLOR]','PLR8ogeEohYWbLlfxcdKGHKeGGOrVAv01f',1,art + 'poker.png')
        addDir('[COLOR aqua]Poker After Dark Season 6[/COLOR]','PLezGPuTnW9q2r-IBGL5-xpRqp0WRs_K_u',1,art + 'poker.png')
        addDir('[COLOR aqua]Poker After Dark Season 7[/COLOR]','PLeF1oYIU0__guuPOWKmolIw_Py7r_eZZg',1,art + 'poker.png')
        addDir('[COLOR aqua]Poker Superstars Invitational Tournament Season 1[/COLOR]','PL16320CC304567A7F',1,art + 'poker.png')
        addDir('[COLOR aqua]Celebrity Poker Showdown[/COLOR]','PL315A2328E9D4D34C',1,art + 'poker.png')
        addDir('[COLOR aqua]Daniel Negreanu Training: Texas Holdem Poker Strategy[/COLOR]','PLIXFmV-rUIufNlxYGYR2p_Tvatiz74ozE',1,art + 'poker.png')	
        addDir('[COLOR aqua]World Series Of Poker 2013 Main Event [/COLOR]','PLoGocvPOKK0FAJpTCkW3jWod49WbrCSz6',1,art + 'poker.png')
        addDir('[COLOR aqua]World Series Of Poker 2014 Main Event [/COLOR]','PLViasp1oG1PtTlIurJrYKscOujEmBxtnh',1,art + 'poker.png')
        addDir('[COLOR aqua]World Series Of Poker 2015 Main Event [/COLOR]','PL2IcC-ktSdHTA3nvSUTP1ASMsipvg70qj',1,art + 'poker.png')
        addDir('[COLOR aqua]How to Play Poker[/COLOR]','P7F1IkAJYc8&list=PLLALQuK1NDrh8fn1zxL3e8i_fjYi0e_0_',1,art + 'poker.png')
        addDir('[COLOR aqua]Poker WSOP Academy[/COLOR]','PLZMvXisiMfNBnI4-RstAtlC-ZbEaOgL17',1,art + 'poker.png')
        addDir('[COLOR aqua]Annie Duke Advanced Texas Holdem Poker Strategy [/COLOR]','PLIXFmV-rUIucxpFzip8VOMgX2zMYvARde',1,art + 'poker.png')        
		
def basket():        
        addDir('[COLOR aqua]NBA[/COLOR]','PLnzhIyrsnB5aAsPRtalXMLlCW8GflCkUY',31,art + 'Sports.png')	
        addDir('[COLOR aqua]משחקים מלאים NCAA[/COLOR]','PL6Bd4hQKgOo81RSUYKV9ko4KzNFPoKgVB',1,art + 'Sports.png')
        addDir3('[COLOR aqua]משחקי כדורסל מלאים ישראל [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=משחקי כדורסל מלאים ישראל&url=www",35,art + '30034.jpg')
        addDir3('[COLOR aqua]כדורסל מכבי תל אביב משחקים מלאים [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=כדורסל מכבי תל אביב משחקים מלאים&url=www",35,art + '30034.jpg')
        addDir('[COLOR aqua]כדורסל מכבי תל אביב משחקים מלאים[/COLOR]','PLGU699iLiZVtqvNmge4rcS10ZBvsZ4CIU',1,art + 'Sports.png')
        addDir3('[COLOR aqua]כדורסל מכבי תל אביב רגעים גדולים 2014-2020 [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=כדורסל מכבי תל אביב רגעים גדולים 2014-2020 &url=www",35,art + '30034.jpg')
        addDir('[COLOR aqua]הפועל ירושלים משחקים מלאים[/COLOR]','PLGU699iLiZVumCl6JWOlZM6-e8YrujVBy',1,art + 'Sports.png')
        addDir('[COLOR aqua]סרטונים פופולריים – כדורסל[/COLOR]','PLS3UB7jaIERxGmq_9fD24tSLwyuZd7vDm',1,art + 'Sports.png')

def soccer():        
        addDir3('[COLOR aqua]ליגת העל 2019/20 תקצירים [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=ליגת העל 2019/20 תקצירים&url=www",35,art + '30034.jpg')	       	
        addDir('[COLOR aqua]כדורגל ישראלי  תקצירים מורחבים[/COLOR]','PLGU699iLiZVsKwGIk7wqlBaDDc_PueD3i',1,art + 'Soccer.jpg')
        addDir3('[COLOR aqua]ליגת העל 2019/20  משחקים מלאים [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=ליגת העל 2019/20  משחקים מלאים&url=www",35,art + '30034.jpg')
        addDir3('[COLOR aqua]ליגת העל 2019-20 - משחקים מלאים ספורט 1 [/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=ליגת העל 2019-20 - משחקים מלאים ספורט 1 &url=www",35,art + '30034.jpg')
        addDir('[COLOR aqua]גביע המדינה 2015-16 - משחקים מלאים ספורט 1[/COLOR]','PLTu-AmawV8D1AFZcpPwWw6FbvFVAXTSLD',1,art + 'Soccer.jpg')
        addDir('[COLOR aqua]הישראליות באירופה  משחקים מלאים[/COLOR]','PLGU699iLiZVtyufLTgFM06rTPORQqMasi',1,art + 'Soccer.jpg')
        addDir('[COLOR aqua]ספורט ONE מכבי חיפה[/COLOR]','PLTu-AmawV8D2yNMxtKOmc1leheIrXgbfp',1,art + 'Soccer.jpg')
        addDir('[COLOR aqua]ספורט ONE מכבי תל אביב[/COLOR]','PLTu-AmawV8D1I2RLIuqCgn4ivpV5wqPjO',1,art + 'Soccer.jpg')
        addDir('[COLOR aqua]ספורט ONE הפועל תל אביב[/COLOR]','PLTu-AmawV8D0C5KPwVlurnJP4KkjIkgMo',1,art + 'Soccer.jpg')
        addDir('[COLOR aqua]ספורט ONE ביתר ירושלים[/COLOR]','PLTu-AmawV8D3b16u3378Sx6xOlGzc5ZDj',1,art + 'Soccer.jpg')
        addDir('[COLOR aqua]ספורט ONE מכבי נתניה[/COLOR]','PLTu-AmawV8D1mWDpHPOD8qts2GoSin1xU',1,art + 'Soccer.jpg')
        addDir('[COLOR aqua]ספורט ONE מכבי פתח תקווה[/COLOR]','PLTu-AmawV8D1usI_4UHXslajV6oBm3ibo',1,art + 'Soccer.jpg')
		
def NBA():
        addDir3('[COLOR aqua]2019-20 Top 10s of the Week[/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=2019-20 Top 10s of the Week &url=www",35,art + '30034.jpg')
        addDir3('[COLOR aqua]2020 All-Star Top 10[/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=2020 All-Star Top 10 &url=www",35,art + '30034.jpg')
        addDir('[COLOR aqua]Nba Hardwood Classic Games[/COLOR]','PLgaLmcSQmPmypokd-3BPPJqtKjzgRdRZu',1,art + 'Sports.png')
        addDir('[COLOR aqua]Inside the NBA Funniest Moments[/COLOR]','PLFHl_hR47OGIqrn4A1tlQmteFKBKTskGx',1,art + 'Sports.png')
        addDir('[COLOR aqua]סרטונים פופולריים – ליגת ה-NBA & הדיילי שואו[/COLOR]','PLcU0PpBCNEcaXFJXvI6uKBZ_XqOWvTkvy',1,art + 'Sports.png')
        addDir3('[COLOR aqua]inside the nba - 2019-2020 NBA Season[/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=inside the nba - 2019-2020 NBA Season &url=www",35,art + '30034.jpg')
        addDir('[COLOR aqua]inside the nba - 2015-2016 NBA Season[/COLOR]','PL7XTBoSLULm16wQ6MiXEoRc9oGuj0geNZ',1,art + 'Sports.png')
        addDir('[COLOR aqua]NBA full games[/COLOR]','PLZyXUPrBBStUgi8dE4_zo_mNFaQ_JvbeL',1,art + 'Sports.png')
        addDir('[COLOR aqua]NBA Greatest Games[/COLOR]','PLMATWUx3t7L_pHQ56TR3wu_G0YzlQl7RP',1,art + 'Sports.png')
        addDir3('[COLOR aqua]סרטונים פופולריים – דראפט ה-NBA & 2020 NBA draft[/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=סרטונים פופולריים – דראפט ה-NBA & 2020 NBA draft &url=www",35,art + '30034.jpg')

def box():
        addDir('[COLOR aqua]סרטונים פופולריים אגרוף - מתעדכן[/COLOR]','PLwLgSWHbGc0ryMh4ACsYm45s41d0V2DJ3',1,art + 'box.png')
        addDir('[COLOR aqua]אגרוף - TOP 10[/COLOR]','PL3mFKGDe2IPs5Zx51hw0jEmmL_CFsu2az',1,art + 'box.png')
        addDir('[COLOR aqua]המתאגרפים הגדולים ביותר[/COLOR]','PLnzhIyrsnB5bP0vSK0OyRcZqZRYyKOQdE',1,art + 'box.png')
        addDir('[COLOR aqua]הנוקאאוטים הגדולים ביותר[/COLOR]','PLnzhIyrsnB5aCGl_OsHn2OkEuX70C-rIK',1,art + 'box.png')
        addDir('[COLOR aqua]רגעי השיא של המתאגרפים הגדולים[/COLOR]','PL3mFKGDe2IPtoQ2mkA0V8dOrsMHEOhtnA',1,art + 'box.png')
        addDir('[COLOR aqua]קרבות אגרוף קלאסיים[/COLOR]','PL0i1N-wlFfiDEdYCjp6nvHR-sEpJGBGXZ',1,art + 'box.png')
        addDir('[COLOR aqua]קרבות גדולים[/COLOR]','PLQcJnkxSzA8ypDBwz9wbP87MN4dNwklBO',1,art + 'box.png')
        addDir('[COLOR aqua]קרבות מלאים 1[/COLOR]','PL-KAIrL6czM_bnmP8z41QdEVCXcj0UjEA',1,art + 'box.png')
        addDir('[COLOR aqua]קרבות מלאים 2[/COLOR]','PLF3785E12178259EE',1,art + 'box.png')
        addDir3('[COLOR aqua]המלחמות הגדולות ביותר באגרוף[/COLOR]',"plugin://plugin.video.MyYoutube/?description=חיפוש&fanart&iconimage&mode=4&name=המלחמות הגדולות ביותר באגרוף &url=www",35,art + '30034.jpg')

def vodil(url):

    ok=True        
    xbmc.executebuiltin('XBMC.Container.Update(%s)' % url )
    return ok
        
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param


params=get_params()
url=None
name=None
mode=None
iconimage=None
page = None
token = None

try: url=urllib.unquote_plus(params["url"])
except: pass
try: name=urllib.unquote_plus(params["name"])
except: pass
try: mode=int(params["mode"])
except:
	try: 
		mode=params["mode"]
	except: pass
try: iconimage=urllib.unquote_plus(params["iconimage"])
except: pass
try: token=urllib.unquote_plus(params["token"])
except: pass
try: page=int(params["page"])
except: page = 1

print ("Mode: "+str(mode))
print ("URL: "+str(url))
print ("Name: "+str(name))
print ("iconimage: "+str(iconimage))
print ("Page: "+str(page))
print ("Token: "+str(token))

		
def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setProperty('fanart_image', fanart)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
		
def addDir3(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setProperty('fanart_image', fanart)
        if mode==35 :
               ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz)
               return ok
				
def create_directory(dir_path, dir_name=None):
    if dir_name:
        dir_path = os.path.join(dir_path, dir_name)
    dir_path = dir_path.strip()
    if not os.path.exists(dir_path):
        os.makedirs(dir_path)
    return dir_path

if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES()
       
elif mode==1:
        return_youtubevideos(name,url,token,page)

elif mode==5: 
        play_youtube_video(url)

elif mode==6:
        mark_as_watched(url)

elif mode==7:
        removed_watched(url)

elif mode==8:
        add_to_bookmarks(url)

elif mode==9:
        remove_from_bookmarks(url)
		
elif mode==10:
        print ""+url
        lifestyle()
		
elif mode==11:
        print ""+url
        documentary()

elif mode==12:
        print ""+url
        kids()

elif mode==13:
        print ""+url
        Music()
        
elif mode==14:
        print ""+url
        travel()

elif mode==15:
        print ""+url
        Sports()

elif mode==16:
        print ""+url
        liveshows()

elif mode==17:
        print ""+url
        cooking()
			
elif mode==18:
        print ""+url
        junior()
		
elif mode==19:
        print ""+url
        nickjunior()

elif mode==20:
        print ""+url
        nicklodeon()

elif mode==21:
        print ""+url
        logy()

elif mode==22:
        print ""+url
        hop()

elif mode==23:
        print ""+url
        hopy()	

elif mode==24:
        print ""+url
        luly()

elif mode==25:
        print ""+url
        baby()

elif mode==26:
        print ""+url
        hot()

elif mode==27:
        print ""+url
        kidstv()

elif mode==28:
        print ""+url
        ch23()

elif mode==29:
        print ""+url
        zoom()		

elif mode==30:
        print ""+url
        dsjunior()

elif mode==31:
        print ""+url
        NBA()

elif mode==32:
        print ""+url
        basket()

elif mode==33:
        print ""+url
        soccer()		

elif mode==34:
        print ""+url
        box()		

elif mode==37:
        print ""+url
        nostal()				
		
elif mode==35:
	    vodil(url)
	
elif mode==38:
        print ""+url
        movies()

elif mode==39:
        print ""+url
        poker()

elif mode==99:
        print ""+url
        Mu()

elif mode==98:
        print ""+url
        Su()

elif mode==97:
        print ""+url
        Sl()

elif mode==96:
        print ""+url
        Sx()

elif mode==95:
        print ""+url
        Dg()

elif mode==94:
        print ""+url
        vevo()

elif mode==193:
        print ""+url
        vev()

elif mode==92:
        print ""+url
        Muyu()

elif mode==199:
        print ""+url
        Mul()

elif mode==197:
        print ""+url
        Sll()

elif mode==196:
        print ""+url
        Sxl()

elif mode==195:
        print ""+url
        Dgl()

		
xbmcplugin.endOfDirectory(int(sys.argv[1]))
