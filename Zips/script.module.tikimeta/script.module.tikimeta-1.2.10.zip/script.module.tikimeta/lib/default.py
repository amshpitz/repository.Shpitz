# -*- coding: utf-8 -*-

from sys import argv
from tikimeta.router import routing
routing(argv[2])