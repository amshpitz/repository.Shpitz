# -*- coding: utf-8 -*-
import xbmcaddon,os,xbmc,xbmcgui,urllib,urllib2,re,xbmcplugin,sys,logging,json,time,threading
from resources.modules import cache
__USERAGENT__ = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.97 Safari/537.11'
__addon__ = xbmcaddon.Addon()
__cwd__ = xbmc.translatePath(__addon__.getAddonInfo('path')).decode("utf-8")
Addon = xbmcaddon.Addon()
#reload (sys )#line:61
#sys .setdefaultencoding ('utf8')#line:62
user_dataDir = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
if not os.path.exists(user_dataDir):
     os.makedirs(user_dataDir)
user_dataDir_img=os.path.join(user_dataDir,'images')
if not os.path.exists(user_dataDir_img):
    os.makedirs(user_dataDir_img)
from resources.modules.addall import addLink,addDir3,addNolink
class Thread(threading.Thread):
    def __init__(self, target, *args):
       
        self._target = target
        self._args = args
        
        
        threading.Thread.__init__(self)
        
    def run(self):
        
        self._target(*self._args)
        
def replaceHTMLCodes(txt):
    import HTMLParser
    txt = re.sub("(&#[0-9]+)([^;^0-9]+)", "\\1;\\2", txt)
    txt = HTMLParser.HTMLParser().unescape(txt)
    txt = txt.replace("&quot;", "\"")
    txt = txt.replace("&amp;", "&")
    txt = txt.replace("&#8211", "-")
    txt = txt.replace("&#8217", "'")
    txt = txt.strip()
    return txt
def get_params():
        param=[]
        if len(sys.argv)>=2:
          paramstring=sys.argv[2]
          if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param     


def read_site_html(url_link):
    import requests
    '''
    req = urllib2.Request(url_link)
    req.add_header('User-agent',__USERAGENT__)# 'Mozilla/5.0 (Linux; U; Android 4.0.3; ko-kr; LG-L160L Build/IML74K) AppleWebkit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30')
    html = urllib2.urlopen(req).read()
    '''
    html=requests.get(url_link)
    return html

def main_menu():
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    addonPath = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
    tmdb_data_dir = addonPath#os.path.join(addonPath, 'resources', 'tmdb_data')
    tmdb_cacheFile = os.path.join(tmdb_data_dir, 'youtube.db')
    dbcon = database.connect(tmdb_cacheFile)
    dbcur = dbcon.cursor()
    match=[('0')]
    match_tv=[('0')]
    try:
        dbcur.execute("SELECT * FROM updated where type='movies'")
        match = dbcur.fetchall()
        logging.warning(match)
        dbcur.execute("SELECT * FROM updated where type='tv'")
        match_tv = dbcur.fetchall()
        logging.warning(match)
    except:
        pass
    if len(match)==0:
        match=[('0')]
    if len(match_tv)==0:
        match_tv=[('0')]
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""link TEXT,""con1 TEXT,""origin TEXT,""icon TEXT, ""image TEXT,""plot TEXT,""data TEXT);"% 'kids_movie')
    
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""link TEXT,""con1 TEXT,""origin TEXT,""icon TEXT, ""image TEXT,""plot TEXT,""data TEXT);"% 'newones')
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""link TEXT,""icon TEXT, ""image TEXT,""plot TEXT,""origin TEXT);"% 'kids_show')
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""link TEXT,""icon TEXT, ""image TEXT,""plot TEXT,""data TEXT,""tmdbid TEXT,""date_added TEXT);"% 'kids_movie_ordered')
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""link TEXT,""icon TEXT,""fanart TEXT,""plot TEXT,""video_data TEXT);"% 'kids_show_orginized')
    dbcon.commit()
    dbcur.execute("SELECT * FROM kids_movie_ordered")

    match2 = dbcur.fetchall()
    all_names=[]
    count_m=0
    for name1,link,con1,origin,icon,image,plot,data in match2:
        if name1 not in all_names:
            all_names.append(name1)
            count_m+=1
    dbcur.execute("SELECT * FROM kids_show_orginized ")

    match2 = dbcur.fetchall()
    all_names=[]
    count_tv=0
    for name1,link,icon,image,plot,origin in match2:
        if name1 not in all_names:
            all_names.append(name1)
            count_tv+=1
    all_d=[]
    addNolink( '[COLOR yellow][I]עדכן הכל[/I][/COLOR]', 'www',6,False, iconimage="https://www.csri.org.il/wp-content/uploads/2016/10/update-tae40116.jpeg",fan='https://www.csri.org.il/wp-content/uploads/2016/10/update-tae40116.jpeg')

    #all_d.append(addDir3('(%s) סרטים מדובבים'%str(count_m),'0',1,'https://www.flatpanelshd.com/pictures/despicableme2-1l.jpg','http://4k.com/wp-content/uploads/2014/11/toystory3_img10_720-790x442.jpg','סרטים מדובבים',generes=match[0][0]))
    all_d.append(addDir3('(%s) סרטים מדובבים עמודים'%str(count_m),'0',10,'https://www.flatpanelshd.com/pictures/despicableme2-1l.jpg','https://www.flatpanelshd.com/pictures/despicableme2-1l.jpg','סרטים מדובבים',generes=match[0][0]))
    all_d.append(addDir3('(%s) סרטים מדובבים שנים'%str(count_m),'0',10,'https://www.flatpanelshd.com/pictures/despicableme2-1l.jpg','https://www.flatpanelshd.com/pictures/despicableme2-1l.jpg','לפי שנים',generes=match[0][0]))
    
    all_d.append(addDir3('(%s) סרטים מדובבים לפי א-ב'%str(count_m),'0',11,'https://www.flatpanelshd.com/pictures/despicableme2-1l.jpg','https://www.flatpanelshd.com/pictures/despicableme2-1l.jpg','סרטים מדובבים',generes=match[0][0]))
    
    #all_d.append(addDir3('(%s) סדרות'%str(count_tv),'www',2,'https://travelmamas.com/wp-content/uploads/2017/10/best_travel_movies_for_kids_frozen-837x1200.jpg','https://www.slashfilm.com/wp/wp-content/images/Astro-Boy.jpg','ילדים',generes=match_tv[0][0]))
    
    all_d.append(addDir3('(%s)  סדרות לפי עמודים'%str(count_tv),'0',13,'https://travelmamas.com/wp-content/uploads/2017/10/best_travel_movies_for_kids_frozen-837x1200.jpg','https://www.slashfilm.com/wp/wp-content/images/Astro-Boy.jpg','ילדים',generes=match_tv[0][0]))
    all_d.append(addDir3('(%s)  סדרות לפי לפי א-ב'%str(count_tv),'0',14,'https://travelmamas.com/wp-content/uploads/2017/10/best_travel_movies_for_kids_frozen-837x1200.jpg','https://www.slashfilm.com/wp/wp-content/images/Astro-Boy.jpg','ילדים',generes=match_tv[0][0]))
    
    # all_d.append(addDir3('חיפוש','search',11,'https://lh5.googleusercontent.com/proxy/-RGejAHqTw0SEl8o3_eK3abBTFCoR49bh780mJ-HX2kK_Qf0aeTzeKuN_WHmW5wOZzKEmlsHE684lxp8BNbejnLx-S4S7dJDeCea3ESPCPMrkUucyFXNH5F_4iktdqh7vKfE5QNGtMZF6QAwAGknYp6v8oeRQg','https://searchengineland.com/figz/wp-content/seloads/2017/12/compare-seo-ss-1920-800x450.jpg','search'))

    
    all_d.append(addLink( '[COLOR yellow][I]הגרל לי סדרה[/I][/COLOR]',  'www',16,False,'https://www.amr-insights.eu/wp-content/uploads/2019/10/dice-3095227_960_720.jpg','https://www.amr-insights.eu/wp-content/uploads/2019/10/dice-3095227_960_720.jpg','הגרל לי סדרה'))
    
    all_d.append(addDir3('קדימונים לילדים','www',4,'https://imagesvc.timeincapp.com/v3/mm/image?url=https%3A%2F%2Fewedit.files.wordpress.com%2F2017%2F11%2Fanimationsplit.jpg%3Fw%3D2000&w=700&q=85','https://cdn1.thr.com/sites/default/files/imagecache/list_landscape_960x541/2017/08/coco_ferdinand_the_star_lego_ninjago_my_little_pony_-_split_-_publicity_-_h_2017_1.jpg','טרליירים'))
    
    all_d.append(addDir3('סדרות מועדפות','www',8,'https://www.netclipart.com/pp/m/186-1868147_kids-logo-tv-show-logos-childrens-logo-church.png','https://www.denofgeek.com/wp-content/uploads/2020/03/UK-Kids-streaming.jpg?fit=1200%2C675','סדרות מועדפות'))
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""url TEXT,""video_info TEXT,""id TEXT,""icon TEXT,""fan TEXT,""free TEXT);"%'last_played_movie' )
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""url TEXT,""video_info TEXT,""id TEXT,""icon TEXT,""fan TEXT,""free TEXT);"%'last_played_tv' )
   
    dbcur.execute("SELECT * FROM last_played_movie")
    match = dbcur.fetchall()
    for name ,url ,video_info ,id ,icon ,fan ,free in match:
        all_d.append(addLink(name.replace('%27',"'"),url,5,False,icon,fan,free.replace('%27',"'"),video_info=urllib.unquote_plus(video_info),id=id))
    dbcur.execute("SELECT * FROM last_played_tv")
    match = dbcur.fetchall()
    for name ,url ,video_info ,id ,icon ,fan ,free in match:
        x=json.loads(urllib.unquote_plus(video_info))
        logging.warning(x)
        
        all_d.append(addLink(name.replace('%27',"'")+'[COLOR yellow][B][I]'+x['original_title']+'- [/I][/B][/COLOR]',url,5,False,icon,fan,free.replace('%27',"'"),video_info=urllib.unquote_plus(video_info),id=id))
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
    # addNolink( '[COLOR yellow][I]עדכן הכל[/I][/COLOR]', 'www',6,False, iconimage="https://i.ytimg.com/vi/6sRi1FvWe1Q/maxresdefault.jpg",fan='https://i.ytimg.com/vi/DZj9lWmqbus/hqdefault.jpg')
    addNolink( '[COLOR yellow][I]עדכן סרטים[/I][/COLOR]', 'movie',6,False, iconimage="https://www.csri.org.il/wp-content/uploads/2016/10/update-tae40116.jpeg",fan='https://www.csri.org.il/wp-content/uploads/2016/10/update-tae40116.jpeg')
    addNolink( '[COLOR yellow][I]עדכן סדרות[/I][/COLOR]', 'tv',6,False, iconimage="https://www.csri.org.il/wp-content/uploads/2016/10/update-tae40116.jpeg",fan='https://www.csri.org.il/wp-content/uploads/2016/10/update-tae40116.jpeg')
    addNolink( '[COLOR orange][B]תודה שבחרתם קודי קמיליון[/B][/COLOR]', 'tv',236,False, iconimage="https://cdn.redmondpie.com/wp-content/uploads/2017/05/Chameleon-Run.jpg",fan='https://cdn.redmondpie.com/wp-content/uploads/2017/05/Chameleon-Run.jpg')
   
    
    dbcur.close()
    dbcon.close()
    
def ClearCache():
  
    logging.warning('Clear')
    cache.clear(['cookies', 'pages','posters'])
    xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kids', 'Cleared')))
def get_sdarot(url):
       from sdarot import MyResolver
       url_data=json.loads(url)
       logging.warning('Doner Test Resolve:')
       url, cookie=get_final_video_and_cookie(url_data[0], url_data[1], url_data[2], False, False)
       '''
       regex='https://(.+?)/'
       match=re.compile(regex).findall(url)
       h=(MyResolver(match[0]))
       url=url.replace(match[0],h)
       '''
       return url
def get_final_video_and_cookie(sid, season, episode, choose_quality=False, download=False):
    from resources.modules.sdarot import get_sdarot_ck,get_sdarot_ck,get_video_url
    local=False
    #get_sdarot_ck(sid,season,episode)
    token,cookie=cache.get(get_sdarot_ck,3,sid,season,episode, table='cookies')
    logging.warning('sd cookie')
    logging.warning(cookie)
   
    logging.warning('sd cookie2')
    logging.warning('Doner Test:'+token)
    logging.warning(cookie)
    #cookie={'Sdarot':'FOcYpGHLb'}
    if cookie=={} or token == 'donor':
        logging.warning('Get donor')
        token,cookie=cache.get(get_sdarot_ck,0,sid,season,episode,cookie, table='cookies')
        logging.warning('Doner Test22:'+token)
        logging.warning(cookie)
    else:
        vid = get_video_url(sid, season, episode, token, cookie, choose_quality)
        logging.warning('sd vid')
        logging.warning(vid)
        if 'errors' not in vid:
             return vid, cookie
        else:
            xbmc.executebuiltin((u'Notification(%s,%s)' % ('הכל לילדים', vid['errors'][0])).encode('utf-8'))
            
        if 'uid=|Co' in vid:
           
            token,cookie=cache.get(get_sdarot_ck,0,sid,season,episode, table='cookies')
          
        else:
           
 
           
           if 'errors' not in vid:
             return vid, cookie
    logging.warning(token)
    if token == 'donor':
        vid = get_video_url(sid, season, episode, token, cookie, choose_quality)

    else:
        if download:
            #plugin.notify('התחבר כמנוי כדי להוריד פרק זה', image=ICON)
            return None, None
        else:
            vid = get_video_url(sid, season, episode, token, cookie, choose_quality)
            if 'errors' in vid:
                msg="אנא המתן 30 שניות"#vid['errors'][0]
            else:
                msg="אנא המתן 30 שניות"
            if not local:
                
                dp = xbmcgui.DialogProgress()
                dp.create("לצפייה באיכות HD וללא המתנה ניתן לרכוש מנוי", msg, vid['errors'][0],
                          "[COLOR orange][B]לרכישת מנוי להיכנס בדפדפן - www.sdarot.tv/donate[/B][/COLOR]")
                dp.update(0)
            tm=31
   
            if not 'errors' in vid:
             tm=0
         
             return vid, cookie
            else:
                
                tm=re.findall(r' \d+ ', vid['errors'][0])
                if len(tm)==0:
                    
                        xbmcgui.Dialog().ok('Sdaror TV',vid['errors'][0])
                        sys.exit()
                tm=int (tm[0].strip())
                if tm>28:
                    token,cookie=cache.get(get_sdarot_ck,0,sid,season,episode, table='cookies')
                    tm=30
            
            
            
            

            for s in range(tm, -1, -1):
                time.sleep(1)
                if  local:
                    sys.stdout.write("\r עוד {0} שניות".format(s))
                    sys.stdout.flush()
                else:
                    dp.update(int((tm - s) / (tm+1) * 100.0), msg, 'עוד {0} שניות'.format(s), '')
                    if dp.iscanceled():
                        dp.close()
                        return None, None
        

        
        vid = get_video_url(sid, season, episode, token, cookie, choose_quality)
        logging.warning('VID LINK')
        
        if 'errors' in vid:
                    xbmcgui.Dialog().ok('Sdaror TV',vid['errors'][0])
                    sys.exit()
    if vid:
           
            return vid, cookie
            
def resolve_link(url,id,plot,name1):
    import requests
    if 'tv4kids' in url:
        url=urllib.unquote_plus(url).replace('[[OS]]','')
        logging.warning('f_url:'+url.replace('[[OS]]','').decode('utf8'))
        headers = {
            'authority': 'tv4kids.tk',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36',
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'sec-fetch-site': 'none',
            'sec-fetch-mode': 'navigate',
            'accept-encoding': 'gzip, deflate, br',
            'accept-language': 'en-US,en;q=0.9',
            
        }

        response = requests.get(url, headers=headers,stream=True).url
        


        headers = {
            'authority': 'tv4kids.tk',
            'accept-encoding': 'identity;q=1, *;q=0',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36',
            'accept': '*/*',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-mode': 'no-cors',
            'referer':url.replace('[[OS]]',''),
            'accept-language': 'en-US,en;q=0.9',
           
        }
        
        head=urllib.urlencode(headers)
        url=url+"|"+head
        url=response
        
    
    if '%%%' in url:
        regex='\[\[(.+?)\]\]'
        match2=re.compile(regex).findall(url)
        if len(match2)>0:
           
            url=url.replace(match2[0],'').replace('[','').replace(']','').strip()
        url=url.split('%%%')[0]
        url_id=url
        url='plugin://plugin.video.telemedia/?url=%s&no_subs=%s&season=%s&episode=%s&mode=40&original_title=%s&id=%s&data=&fanart=&url=%s&iconimage=&file_name=%s&description=%s&resume=%s&name=%s&heb_name=%s'%(url_id,'1','%20','%20',name1.decode('utf-8','ignore').encode("utf-8"),id,url_id,name1.decode('utf-8','ignore').encode("utf-8"),plot,'',name1,name1)
        logging.warning(url)
    if '[' in url and 'http' not in url:
       from resources.modules.sdarot import MyResolver
       url_data=json.loads(url)
       logging.warning('Doner Test Resolve:')
       url, cookie=get_final_video_and_cookie(url_data[0], url_data[1], url_data[2], False, False)
    if 'f2h' in url:
        url=url.replace('nana10.co.il','io')
        headers = {
        'Pragma': 'no-cache',
        
        'Accept-Encoding': 'utf8',

        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36',


        
        }
        html=requests.get(url,headers=headers).content
        
        regex='<script.+?"(.+?)/ip.php'
        match=re.compile(regex).findall(html)

        for links in match:
         
         if 'f2h.co.il' in links:
           id=links

        regex2="<form name='myform' id='myform' method='post' action='.+?/thanks/(.+?)'"
        match2=re.compile(regex2).findall(html)

        url=id+'/files/'+match2[0].replace("|","%7C")
    if 'www.youtube.com' in url :
        vid=re.compile('\?(?:v|id)=(.+?)(?:$|&)').findall(url)[0]
        url='plugin://plugin.video.youtube/play/?video_id='+vid
    return url
def play_link(name,url,video_info,id,icon,fan,plot):
    logging.warning(url)
    
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    addonPath = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
    tmdb_data_dir = addonPath#os.path.join(addonPath, 'resources', 'tmdb_data')
    tmdb_cacheFile = os.path.join(tmdb_data_dir, 'youtube.db')
    dbcon = database.connect(tmdb_cacheFile)
    dbcur = dbcon.cursor()
    
    if 'tv_title' in video_info:
        table_name='last_played_tv'
    else:
        table_name='last_played_movie'
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""url TEXT,""video_info TEXT,""id TEXT,""icon TEXT,""fan TEXT,""free TEXT);"%table_name )
    dbcur.execute("DELETE FROM "+table_name)
    dbcur.execute("INSERT INTO %s Values ('%s','%s','%s','%s','%s','%s','%s')"%(table_name,name.replace("'","%27"),url,urllib.quote_plus(video_info),id,icon,fan,plot.replace("'","%27")))
    
    dbcon.commit()
    dbcur.close()
    dbcon.close()

    all_data=json.loads(video_info)
    all_f_name=[]
    if '$$$' in url:
       links=url.split('$$$')
       sour_pre=''
       sour=''
       all_s=[]
       for lk in links:
           f_name=''
           regex='\[\[(.+?)\]\]'
           match=re.compile(regex).findall(str(lk))
           if len(match)==0:
               if 'TEME' in lk:
                 ff_link=lk
                 f_name=lk.split('%%%')[1].split('_')[1]
                 
                 ff_link=fn.replace(match2[0],'').replace('[','').replace(']','')
                 match=[('TE',f_name)]
               else:
                    regex='//(.+?)/'
                     
                    match_ser=re.compile(regex).findall(str(lk))
            
                    if len(match_ser)>0:
                         match=[]
                         match.append((sour,match_ser[0]))
                    else:
                        match=[]
                        match.append((sour,'Direct'))
           else:
                if 'TEME' in lk:
                 logging.warning(lk)
                 ff_link=lk
                 f_name=lk.split('%%%')[1].split('_')[1]
                 
                 match=[('TE',f_name)]
                 
                else:
                    regex='\[\[(.+?)\]\].+?//(.+?)/'
                    match=re.compile(regex).findall(str(lk))
                if len(match)==0:
                    if 'TEME' in lk:
                     ff_link=lk
                     f_name=lk.split('%%%')[1].split('_')[1]
                     
                     match=[('TE',f_name)]
                     
                    else:
                        regex='\[\[(.+?)\]\]'
                        sour=re.compile(regex).findall(str(lk))[0]
                        match=[]
                        match.append((sour,'Direct'))
           
           for sour,ty in match:
                all_f_name.append(f_name)
                sour=sour.replace('openload','vummo')
                ty=ty.replace('tv4kids','streamango').replace('.tk','.com')
                if 'sratim' in ty:
                    ty='str'
                all_s.append('[COLOR lightblue][B]'+sour+'[/B][/COLOR] - [COLOR yellow][I]'+ty.replace('letsupload','avlts')+'[/I][/COLOR]')
                
       #logging.warning(all_s)
       
       ret = xbmcgui.Dialog().select("בחר", all_s)
       if ret!=-1:
         #logging.warning(links)
         #logging.warning(ret)
         ff_link=links[ret]
         
         regex='\[\[(.+?)\]\]'
         match2=re.compile(regex).findall(links[ret])
         if len(match2)>0:
           if 'TE' in all_s[ret]:
            
            
            ff_link=ff_link
            logging.warning('ff_link2:'+ff_link)
           if 'http' in ff_link or 'TE' in all_s[ret]:
            ff_link=ff_link.replace(match2[0],'').replace('[','').replace(']','')
           else:
            ff_link=ff_link.replace(match2[0],'')
         else:
            try:
                if 'http' in ff_link:
                    ff_link=ff_link.replace(match2[0],'').replace('[','').replace(']','')
                else:
                    ff_link=ff_link.replace(match2[0],'')
            except:
                pass
         logging.warning('ff_link:'+ff_link)
        
         if 'TE' in all_s[ret]:
            
            
            heb_name=all_f_name[ret]
            saved_name=all_f_name[ret]
            original_title=all_f_name[ret]
            season='%20'
            
         url=ff_link.strip()
       else:
         sys.exit()
    else:
        regex='\[\[(.+?)\]\]'
        match2=re.compile(regex).findall(url)
        if len(match2)>0:
           
            url=url.replace(match2[0],'').replace('[','').replace(']','').strip()
    o_url=url
    if '[' not in o_url:
        try:
            
            
            path=xbmc.translatePath('special://home/addons/script.module.resolveurl/lib')
            sys.path.append( path)
            path=xbmc.translatePath('special://home/addons/script.module.six/lib')
            sys.path.append( path)
            import resolveurl
            url =resolveurl .HostedMediaFile (url =url ).resolve ()#line:2687
            
            logging.warning('resolve:'+url)
        except Exception as e:
            logging.warning('Error resolve:'+str(e))
            url=resolve_link(o_url,id,all_data['plot'],name)
    else:
        url=resolve_link(o_url,id,all_data['plot'],name)
    if 'drive.google.com' in url:
        from resources.modules.google_solve import googledrive_resolve
        
        if len(match2)>0:
           
            url=url.replace(match2[0],'').replace('[','').replace(']','').strip()
        
        url,q=googledrive_resolve(url)
    listItem = xbmcgui.ListItem(all_data['title'], path=url) 
    listItem.setInfo(type='Video', infoLabels=all_data)


    listItem.setProperty('IsPlayable', 'true')
    ok=xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)
def save_fav(name,url,iconimage,fanart,description,video_info):
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    addonPath = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
    tmdb_data_dir = addonPath#os.path.join(addonPath, 'resources', 'tmdb_data')
    tmdb_cacheFile = os.path.join(tmdb_data_dir, 'youtube.db')
    dbcon = database.connect(tmdb_cacheFile)
    dbcur = dbcon.cursor()
    
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""url TEXT,""iconimage TEXT,""fanart TEXT,""description TEXT,""free TEXT,""free2 TEXT);"%'Fav' )
    
    dbcur.execute("INSERT INTO Fav Values ('%s','%s','%s','%s','%s','%s','')"%(name.replace("'","%27"),url,iconimage,fanart,description.replace("'","%27"),video_info.replace("'","%27")))
    
    dbcon.commit()
    dbcur.close()
    dbcon.close()
    xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kids', 'נשמר')))
def show_fav():
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    addonPath = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
    tmdb_data_dir = addonPath#os.path.join(addonPath, 'resources', 'tmdb_data')
    tmdb_cacheFile = os.path.join(tmdb_data_dir, 'youtube.db')
    dbcon = database.connect(tmdb_cacheFile)
    dbcur = dbcon.cursor()
    
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""url TEXT,""iconimage TEXT,""fanart TEXT,""description TEXT,""free TEXT,""free2 TEXT);"%'Fav' )

    dbcon.commit()
    
    dbcur.execute("SELECT * FROM Fav")
    match = dbcur.fetchall()
    all_d=[]
    thread=[]
    all_img=[]
    for name ,url ,icon ,fan ,plot,free,free2 in match:
        if 'sdarot' in icon:
            f_image=get_img_loc(icon)
            
            if not os.path.exists(os.path.join(f_image)):
                all_img.append(icon)
            icon=f_image
            image=f_image
        else:
            logging.warning(icon)
        try:
            video_data=json.loads(free.replace("%27","'"))
        except: 
            video_data={}
            video_data['title']=name.replace("%27","'")
            video_data['icon']=icon
            video_data['fanart']=fan
            video_data['plot']=plot.replace("%27","'")
        video_data['fast']=1
        
        all_d.append(addDir3(name.replace('%27',"'"),url,46,icon,fan,plot.replace('%27',"'"),video_info=video_data))
    thread.append(Thread(download_img,all_img))
  
    for td in thread:
          td.start()
          
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
    dbcur.close()
    dbcon.close()
def remove_fav(name,url,iconimage,fanart,description):
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    addonPath = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
    tmdb_data_dir = addonPath#os.path.join(addonPath, 'resources', 'tmdb_data')
    tmdb_cacheFile = os.path.join(tmdb_data_dir, 'youtube.db')
    dbcon = database.connect(tmdb_cacheFile)
    dbcur = dbcon.cursor()
    
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""url TEXT,""iconimage TEXT,""fanart TEXT,""description TEXT,""free TEXT,""free2 TEXT);"%'Fav' )
    
    dbcur.execute("DELETE FROM Fav Where name='%s'"%(name.replace("'","%27")))
    
    dbcon.commit()
    dbcur.close()
    dbcon.close()
    xbmc.executebuiltin('Container.Refresh')
    xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kids', 'הוסר')))
def get_img_loc(image):
    img_n=image.split('/')
    f_img=img_n[len(img_n)-1].replace('/','')
   
    f_save=os.path.join(user_dataDir_img,f_img)
    return f_save
def download_img(urls):
    
    from resources.modules.sdarot import resolve_dns
    for items in urls:
        try:
            x=resolve_dns(items).download_image()
        except:
            pass
    return 0
def heb_tv_dub(url):
    page=int(url)
    
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    
    addonPath = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
    tmdb_data_dir = addonPath#os.path.join(addonPath, 'resources', 'tmdb_data')
    tmdb_cacheFile = os.path.join(tmdb_data_dir, 'youtube.db')
    dbcon = database.connect(tmdb_cacheFile)
    logging.warning(tmdb_cacheFile)
    dbcur = dbcon.cursor()
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""link TEXT,""icon TEXT,""fanart TEXT,""plot TEXT,""video_data TEXT);"% 'kids_show_orginized')
    dbcur.execute("SELECT * FROM kids_show_orginized ORDER BY name ASC")
    all_l=[]
    match = dbcur.fetchall()
    x=page
    thread=[]
    all_img=[]
    logging.warning('f_image')
    for name ,link,icon, image,plot,data in match:
        
        if (x>=(page*100) and x<=((page+1)*100)):
            if 'sdarot' in image:
                f_image=get_img_loc(image)
                
                if not os.path.exists(os.path.join(f_image)):
                    all_img.append(image)
                icon=f_image
                image=f_image
            else:
                logging.warning(icon)
                
            all_l.append(addDir3(name.replace('..','a'),link,46,icon, image,plot,video_info=json.loads(data)))
        
        x+=1
    thread.append(Thread(download_img,all_img))
  
    for td in thread:
          td.start()
    all_l.append(addDir3('[COLOR yellow]עמוד הבא[/COLOR]',str(int(page)+1),13,'https://www.flatpanelshd.com/pictures/despicableme2-1l.jpg','http://4k.com/wp-content/uploads/2014/11/toystory3_img10_720-790x442.jpg','סרטים מדובבים'))
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_l,len(all_l))
    dbcur.close()
    dbcon.close()
def heb_tv_letter(iconimage,fanart):
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    
    addonPath = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
    tmdb_data_dir = addonPath#os.path.join(addonPath, 'resources', 'tmdb_data')
    tmdb_cacheFile = os.path.join(tmdb_data_dir, 'youtube.db')
    dbcon = database.connect(tmdb_cacheFile)
    logging.warning(tmdb_cacheFile)
    dbcur = dbcon.cursor()
    
    
        
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""link TEXT,""icon TEXT,""fanart TEXT,""plot TEXT,""video_data TEXT);"% 'kids_show_orginized')
    dbcur.execute("SELECT * FROM kids_show_orginized WHERE substr(name,1,1) NOT LIKE 'א%' and  substr(name,1,1) NOT LIKE 'ב%' and  substr(name,1,1) NOT LIKE 'ג%' and  substr(name,1,1) NOT LIKE 'ד%' and  substr(name,1,1) NOT LIKE 'ה%' and  substr(name,1,1) NOT LIKE 'ו%' and  substr(name,1,1) NOT LIKE 'ז%' and  substr(name,1,1) NOT LIKE 'ח%' and  substr(name,1,1) NOT LIKE 'ט%' and  substr(name,1,1) NOT LIKE 'י%' and  substr(name,1,1) NOT LIKE 'כ%' and  substr(name,1,1) NOT LIKE 'ל%' and  substr(name,1,1) NOT LIKE 'מ%' and  substr(name,1,1) NOT LIKE 'נ%' and  substr(name,1,1) NOT LIKE 'ס%' and  substr(name,1,1) NOT LIKE 'ע%' and  substr(name,1,1) NOT LIKE 'פ%' and  substr(name,1,1) NOT LIKE 'צ%' and  substr(name,1,1) NOT LIKE 'ק%' and  substr(name,1,1) NOT LIKE 'ר%' and  substr(name,1,1) NOT LIKE 'ש%' and  substr(name,1,1) NOT LIKE 'ת%'")
    match_num = dbcur.fetchall()
    
    
    all_l=[]
    exclude=[1503,1498,1509,1501,1507]
    all_l.append(addDir3('1-2'+ ' [COLOR lightblue](%s)[/COLOR] '%str(len(match_num)),'0',15,iconimage,fanart,'סרטים מדובבים'))
    for ch in range(1488,1515): 
        if ch in exclude:
            continue
        dbcur.execute('SELECT * FROM kids_show_orginized where name like "{0}%"'.format(unichr(ch)))
    
        match = dbcur.fetchall()
        
        all_l.append(addDir3(unichr(ch)+ ' [COLOR lightblue](%s)[/COLOR] '%str(len(match)),'0',15,iconimage,fanart,'סרטים מדובבים'))
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_l,len(all_l))
    dbcur.close()
    dbcon.close()
def heb_tv_dub_letter(name,url):
    o_name=name
    page=int(url)
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    
    addonPath = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
    tmdb_data_dir = addonPath#os.path.join(addonPath, 'resources', 'tmdb_data')
    tmdb_cacheFile = os.path.join(tmdb_data_dir, 'youtube.db')
    dbcon = database.connect(tmdb_cacheFile)
    logging.warning(tmdb_cacheFile)
    dbcur = dbcon.cursor()
    name=name.split(' [')[0]
    if name=='1-2':
        exclude=[1503,1498,1509,1501,1507]
        all_s=[]
        for ch in range(1488,1515): 
            if ch in exclude:
                continue
            all_s.append("substr(name,1,1) NOT LIKE '{0}%' and ".format(unichr(ch)))
        
        dbcur.execute("SELECT * FROM kids_show_orginized WHERE substr(name,1,1) NOT LIKE 'א%' and  substr(name,1,1) NOT LIKE 'ב%' and  substr(name,1,1) NOT LIKE 'ג%' and  substr(name,1,1) NOT LIKE 'ד%' and  substr(name,1,1) NOT LIKE 'ה%' and  substr(name,1,1) NOT LIKE 'ו%' and  substr(name,1,1) NOT LIKE 'ז%' and  substr(name,1,1) NOT LIKE 'ח%' and  substr(name,1,1) NOT LIKE 'ט%' and  substr(name,1,1) NOT LIKE 'י%' and  substr(name,1,1) NOT LIKE 'כ%' and  substr(name,1,1) NOT LIKE 'ל%' and  substr(name,1,1) NOT LIKE 'מ%' and  substr(name,1,1) NOT LIKE 'נ%' and  substr(name,1,1) NOT LIKE 'ס%' and  substr(name,1,1) NOT LIKE 'ע%' and  substr(name,1,1) NOT LIKE 'פ%' and  substr(name,1,1) NOT LIKE 'צ%' and  substr(name,1,1) NOT LIKE 'ק%' and  substr(name,1,1) NOT LIKE 'ר%' and  substr(name,1,1) NOT LIKE 'ש%' and  substr(name,1,1) NOT LIKE 'ת%' ORDER BY name ASC")
    else:
        dbcur.execute('SELECT * FROM kids_show_orginized where name like "{0}%" ORDER BY name ASC'.format(name))
    all_l=[]
    match = dbcur.fetchall()
    x=page
    thread=[]
    all_img=[]
    for name ,link,icon, image,plot,data in match:
        if (x>=(page*100) and x<=((page+1)*100)):
            
            if 'sdarot' in image:
                f_image=get_img_loc(image)
                
                if not os.path.exists(os.path.join(f_image)):
                    all_img.append(image)
                icon=f_image
                image=f_image
                
            all_l.append(addDir3(name,link,46,icon,image,plot,video_info=json.loads(data)))
            
        x+=1




    
    thread.append(Thread(download_img,all_img))
  
    for td in thread:
          td.start()
    if (len(match)-((page+1)*100))>0:
        all_l.append(addDir3(o_name+' [COLOR yellow]עמוד הבא[/COLOR]',str(int(page)+1),15,'https://www.flatpanelshd.com/pictures/despicableme2-1l.jpg','http://4k.com/wp-content/uploads/2014/11/toystory3_img10_720-790x442.jpg','סרטים מדובבים'))
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_l,len(all_l))
    dbcur.close()
    dbcon.close()
def heb_mov_dub(url,description):
    page=int(url)
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    
    addonPath = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
    tmdb_data_dir = addonPath#os.path.join(addonPath, 'resources', 'tmdb_data')
    tmdb_cacheFile = os.path.join(tmdb_data_dir, 'youtube.db')
    dbcon = database.connect(tmdb_cacheFile)
    logging.warning(tmdb_cacheFile)
    dbcur = dbcon.cursor()

    if 'שנים' in description:
        
        dbcur.execute("SELECT * FROM kids_movie_year ORDER BY year DESC")
        all_l=[]
        match = dbcur.fetchall()
        x=page
        for name ,link,icon, image,plot,data,tmdbid ,date_added,year in match:
            if (x>=(page*100) and x<=((page+1)*100)):
                all_l.append(addLink(replaceHTMLCodes(name),link,5,False,icon,image,plot,video_info=data,id=tmdbid))
            x+=1
        all_l.append(addDir3('[COLOR yellow]עמוד הבא[/COLOR]',str(int(page)+1),10,'https://www.flatpanelshd.com/pictures/despicableme2-1l.jpg','http://4k.com/wp-content/uploads/2014/11/toystory3_img10_720-790x442.jpg',description))
    else:
        
        dbcur.execute("SELECT * FROM kids_movie_ordered ORDER BY date_added DESC")
        all_l=[]
        match = dbcur.fetchall()
        x=page
        for name ,link,icon, image,plot,data,tmdbid ,date_added in match:
            if (x>=(page*100) and x<=((page+1)*100)):
                all_l.append(addLink(replaceHTMLCodes(name),link,5,False,icon,image,plot,video_info=data,id=tmdbid))
            x+=1
        all_l.append(addDir3('[COLOR yellow]עמוד הבא[/COLOR]',str(int(page)+1),10,'https://www.flatpanelshd.com/pictures/despicableme2-1l.jpg','http://4k.com/wp-content/uploads/2014/11/toystory3_img10_720-790x442.jpg',description))
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_l,len(all_l))
    dbcur.close()
    dbcon.close()
def heb_mov_letter(iconimage,fanart):
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    
    addonPath = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
    tmdb_data_dir = addonPath#os.path.join(addonPath, 'resources', 'tmdb_data')
    tmdb_cacheFile = os.path.join(tmdb_data_dir, 'youtube.db')
    dbcon = database.connect(tmdb_cacheFile)
    logging.warning(tmdb_cacheFile)
    dbcur = dbcon.cursor()
    
    
        
        
    dbcur.execute("SELECT * FROM kids_movie_ordered WHERE substr(name,1,1) NOT LIKE 'א%' and  substr(name,1,1) NOT LIKE 'ב%' and  substr(name,1,1) NOT LIKE 'ג%' and  substr(name,1,1) NOT LIKE 'ד%' and  substr(name,1,1) NOT LIKE 'ה%' and  substr(name,1,1) NOT LIKE 'ו%' and  substr(name,1,1) NOT LIKE 'ז%' and  substr(name,1,1) NOT LIKE 'ח%' and  substr(name,1,1) NOT LIKE 'ט%' and  substr(name,1,1) NOT LIKE 'י%' and  substr(name,1,1) NOT LIKE 'כ%' and  substr(name,1,1) NOT LIKE 'ל%' and  substr(name,1,1) NOT LIKE 'מ%' and  substr(name,1,1) NOT LIKE 'נ%' and  substr(name,1,1) NOT LIKE 'ס%' and  substr(name,1,1) NOT LIKE 'ע%' and  substr(name,1,1) NOT LIKE 'פ%' and  substr(name,1,1) NOT LIKE 'צ%' and  substr(name,1,1) NOT LIKE 'ק%' and  substr(name,1,1) NOT LIKE 'ר%' and  substr(name,1,1) NOT LIKE 'ש%' and  substr(name,1,1) NOT LIKE 'ת%'")
    match_num = dbcur.fetchall()
    
    
    all_l=[]
    exclude=[1503,1498,1509,1501,1507]
    all_l.append(addDir3('1-2'+ ' [COLOR lightblue](%s)[/COLOR] '%str(len(match_num)),'0',12,iconimage,fanart,'סרטים מדובבים'))
    for ch in range(1488,1515): 
        if ch in exclude:
            continue
        dbcur.execute('SELECT * FROM kids_movie_ordered where name like "{0}%"'.format(unichr(ch)))
    
        match = dbcur.fetchall()
    
        all_l.append(addDir3(unichr(ch)+ ' [COLOR lightblue](%s)[/COLOR] '%str(len(match)),'0',12,iconimage,fanart,'סרטים מדובבים'))
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_l,len(all_l))
    dbcur.close()
    dbcon.close()
def heb_mov_dub_letter(name,url):
    o_name=name
    page=int(url)
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    
    addonPath = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
    tmdb_data_dir = addonPath#os.path.join(addonPath, 'resources', 'tmdb_data')
    tmdb_cacheFile = os.path.join(tmdb_data_dir, 'youtube.db')
    dbcon = database.connect(tmdb_cacheFile)
    logging.warning(tmdb_cacheFile)
    dbcur = dbcon.cursor()
    name=name.split(' [')[0]
    if name=='1-2':
        exclude=[1503,1498,1509,1501,1507]
        all_s=[]
        for ch in range(1488,1515): 
            if ch in exclude:
                continue
            all_s.append("substr(name,1,1) NOT LIKE '{0}%' and ".format(unichr(ch)))
        
        dbcur.execute("SELECT * FROM kids_movie_ordered WHERE substr(name,1,1) NOT LIKE 'א%' and  substr(name,1,1) NOT LIKE 'ב%' and  substr(name,1,1) NOT LIKE 'ג%' and  substr(name,1,1) NOT LIKE 'ד%' and  substr(name,1,1) NOT LIKE 'ה%' and  substr(name,1,1) NOT LIKE 'ו%' and  substr(name,1,1) NOT LIKE 'ז%' and  substr(name,1,1) NOT LIKE 'ח%' and  substr(name,1,1) NOT LIKE 'ט%' and  substr(name,1,1) NOT LIKE 'י%' and  substr(name,1,1) NOT LIKE 'כ%' and  substr(name,1,1) NOT LIKE 'ל%' and  substr(name,1,1) NOT LIKE 'מ%' and  substr(name,1,1) NOT LIKE 'נ%' and  substr(name,1,1) NOT LIKE 'ס%' and  substr(name,1,1) NOT LIKE 'ע%' and  substr(name,1,1) NOT LIKE 'פ%' and  substr(name,1,1) NOT LIKE 'צ%' and  substr(name,1,1) NOT LIKE 'ק%' and  substr(name,1,1) NOT LIKE 'ר%' and  substr(name,1,1) NOT LIKE 'ש%' and  substr(name,1,1) NOT LIKE 'ת%' ORDER BY name ASC")
    else:
        dbcur.execute('SELECT * FROM kids_movie_ordered where name like "{0}%" ORDER BY name ASC'.format(name))
    all_l=[]
    match = dbcur.fetchall()
    x=page
    for name ,link,icon, image,plot,data,tmdbid ,date_added in match:
        if (x>=(page*100) and x<=((page+1)*100)):
            all_l.append(addLink(replaceHTMLCodes(name),link,5,False,icon,image,plot,video_info=data,id=tmdbid))
        x+=1

    if (len(match)-((page+1)*100))>0:
        all_l.append(addDir3(o_name+' [COLOR yellow]עמוד הבא[/COLOR]',str(int(page)+1),12,'https://www.flatpanelshd.com/pictures/despicableme2-1l.jpg','http://4k.com/wp-content/uploads/2014/11/toystory3_img10_720-790x442.jpg','סרטים מדובבים'))
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_l,len(all_l))
    dbcur.close()
    dbcon.close()
def random_tv():
    import random
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    
    addonPath = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
    tmdb_data_dir = addonPath#os.path.join(addonPath, 'resources', 'tmdb_data')
    tmdb_cacheFile = os.path.join(tmdb_data_dir, 'youtube.db')
    dbcon = database.connect(tmdb_cacheFile)
    logging.warning(tmdb_cacheFile)
    dbcur = dbcon.cursor()
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""link TEXT,""icon TEXT,""fanart TEXT,""plot TEXT,""video_data TEXT);"% 'kids_show_orginized')
    dbcur.execute("SELECT * FROM kids_show_orginized ORDER BY name ASC")
    all_l=[]
    match = dbcur.fetchall()
    dbcur.close()
    dbcon.close()
    x=0
    found=True
    count=0
    while found:
        rand=random.randint(0,len(match)-1)
        
        for name ,link,icon, image,plot,data in match:
            if x==rand and 'Sdarot' in link:
                found=False
                break

            x+=1
        count+=1
        if count>10:
            break
    s_name=name
    from resources.modules.kidstv_season import get_seasons
    all_img=[]
    if 'sdarot' in image:
        f_image=get_img_loc(image)
        
        if not os.path.exists(os.path.join(f_image)):
            all_img.append(image)
        icon=f_image
        image=f_image
        thread=[]
        thread.append(Thread(download_img,all_img))
      
        for td in thread:
              td.start()
    name,link,icon,image,plot,video_data=get_seasons(name,link,icon,image,plot,rand=True)
    xbmc.executebuiltin((u'Notification(%s,%s)' % ('נבחרה', s_name)))
    play_link(name,link,json.dumps(video_data),'0',icon,image,plot)
    
params=get_params()

url=None
name=None
mode=None
iconimage=None
fanart=None
description=None
id='0'

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
try:
    video_info=urllib.unquote_plus(params["video_info"])
except:
        pass
try:
    id=(params["id"])
except:
        pass
logging.warning('Mode:'+str(mode))
logging.warning('url:'+str(url))
#logging.warning('video_info:'+str(video_info))
if mode==None or url==None or len(url)<1:
        main_menu()
elif mode==1:
    from resources.modules.hebdub_movies import get_dub
    get_dub(url)
    
elif mode==2:
    from resources.modules.kidstv import get_links
    get_links()
    
elif mode==4:
    import datetime
    from resources.modules.kidstv import Trailer_Youtube
    now = datetime.datetime.now()
    link_url='https://www.youtube.com/results?sp=CAI%253D&q=%22%D7%98%D7%A8%D7%99%D7%99%D7%9C%D7%A8+%D7%9E%D7%93%D7%95%D7%91%D7%91%22+' + str(now.year)
    Trailer_Youtube(link_url,now)
    
elif mode==5:
    play_link(name,url,video_info,id,iconimage,fanart,description)
elif mode==6:
    from resources.modules.hebdub_movies import update_now
    from resources.modules.kidstv import update_now_tv
    if url=='movie':
        update_now(progress=True)
    elif url=='tv':
        update_now_tv(progress=True)
    else:
        update_now(progress=True)
        update_now_tv(progress=True)
elif mode==7:
    save_fav(name,url,iconimage,fanart,description,video_info)
elif mode==8:
    show_fav()
elif mode==9:
    remove_fav(name,url,iconimage,fanart,description)
elif mode==10:
    heb_mov_dub(url,description)
elif mode==11:
    heb_mov_letter(iconimage,fanart)
elif mode==12:
    heb_mov_dub_letter(name,url)
elif mode==13:
    heb_tv_dub(url)
    
elif mode==14:
    heb_tv_letter(iconimage,fanart)
elif mode==15:
    heb_tv_dub_letter(name,url)
elif mode==16:
    random_tv()
elif mode==35:
    ClearCache()
elif mode==46:
    from resources.modules.kidstv_season import get_seasons
    get_seasons(name,url,iconimage,fanart,description)
xbmcplugin.setContent(int(sys.argv[1]), 'movies')


xbmcplugin.endOfDirectory(int(sys.argv[1]))

