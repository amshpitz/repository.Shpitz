# -*- coding: utf-8 -*-
import xbmc,time,logging,datetime,xbmcaddon

from resources.modules.hebdub_movies import update_now
from resources.modules.kidstv import update_now_tv
Addon = xbmcaddon.Addon()
logging.warning('Nextup Service Started')

START=True

    


monitor = xbmc.Monitor()


logging.warning('!!!!!!!!!!!!!!!!!!Start Kids_new service!!!!!!!!!!!!!!!!!!')

strings = time.strftime("%Y,%m,%d,%H,%M,%S")
t = strings.split(',')
numbers = [ int(x) for x in t ]
pre_date=numbers[2]
while not monitor.abortRequested():
 
    if monitor.waitForAbort(1):
            # Abort was requested while waiting. We should exit
            break
    
   
    
 
    START=False
    strings = time.strftime("%Y,%m,%d,%H,%M,%S")
    t = strings.split(',')
    numbers = [ int(x) for x in t ]
    
    if numbers[3]==int(Addon.getSetting("update_kids")) and numbers[2]!=pre_date:
        logging.warning('Updating now Hebdub')
        xbmc.executebuiltin((u'Notification(%s,%s)' % ('הכל לילדים', 'מעדכן מדובבים')))
        pre_date=numbers[2]
        update_now()
        update_now_tv()
        xbmc.executebuiltin((u'Notification(%s,%s)' % ('הכל לילדים', 'הכל מעודכן')))

       
    xbmc.sleep(1000)
del monitor
               
                             