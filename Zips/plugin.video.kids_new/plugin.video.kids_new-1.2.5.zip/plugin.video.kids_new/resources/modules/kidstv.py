# -*- coding: utf-8 -*-
import logging,urllib2,re,os,sys,urllib,json,xbmcplugin,requests,xbmc
import  threading,xbmcaddon
Addon = xbmcaddon.Addon()
try:
    from sqlite3 import dbapi2 as database
except:
    from pysqlite2 import dbapi2 as database
__BASENICKJADD__= 'https://nickjr.walla.co.il/'
__BASE_URL_NICK__ = 'https://nick.walla.co.il/'
__USERAGENT__ = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.97 Safari/537.11'
import xbmc
user_dataDir_pre = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
global all_data_you
all_data_you=[]
KODI_VERSION = int(xbmc.getInfoLabel("System.BuildVersion").split('.', 1)[0])
if KODI_VERSION>=17:
 
  domain_s='https://'
elif KODI_VERSION<17:
  domain_s='http://'
dir_path = os.path.dirname(os.path.realpath(__file__))
mypath=os.path.join(dir_path,'..\solvers')
sys.path.append(mypath)
mypath=os.path.join(dir_path,'..\done')
sys.path.append(mypath)
from addall import addDir3,addLink
user_dataDir=os.path.join(user_dataDir_pre,'cache_f','ghost')
user_dataDir2=os.path.join(user_dataDir_pre,'cache_f','avegner')
user_dataDir3=os.path.join(user_dataDir_pre,'cache_f','ghk')
if not os.path.exists(user_dataDir):
    os.makedirs(user_dataDir)
if not os.path.exists(user_dataDir2):
    os.makedirs(user_dataDir2)
def download_file(url,path):
    local_filename =os.path.join(path, "fixed_list.txt")
    # NOTE the stream=True parameter
    r = requests.get(url, stream=True)
    with open(local_filename, 'wb') as f:
        for chunk in r.iter_content(chunk_size=1024): 
            if chunk: # filter out keep-alive new chunks
                f.write(chunk)
                #f.flush() commented by recommendation from J.F.Sebastian
    return local_filename

def unzip(file,dest):
    
    from zipfile import ZipFile
    
    
    zip_file = file
    ptp = 'Masterpenpass'
    zf=ZipFile(zip_file)
    #zf.setpassword(bytes(ptp))
    #with ZipFile(zip_file) as zf:
    zf.extractall(dest)

def renew_data(path,l_list):


    download_file(l_list,path)

    unzip(os.path.join(path, "fixed_list.txt"),path)

    return 'ok'
def gdecom(url):

    import StringIO ,gzip
    compressedFile = StringIO.StringIO()
    compressedFile.write(url.decode('base64'))
    # # Set the file's current position to the beginning
    # of the file so that gzip.GzipFile can read
    # its contents from the top.
    # 
    compressedFile.seek(0)
    return  gzip.GzipFile(fileobj=compressedFile, mode='rb').read()
class Thread(threading.Thread):
    def __init__(self, target, *args):
       
        self._target = target
        self._args = args
        
        
        threading.Thread.__init__(self)
        
    def run(self):
        
        self._target(*self._args)

global all_dub,all_dub2,all_dub3,all_dub4,all_dub5,all_dub6,all_dub7
all_dub=[]
all_dub2=[]
all_dub3=[]
all_dub4=[]
all_dub5=[]
all_dub6=[]
all_dub7=[]
try:
    import xbmc
    addonInfo = xbmcaddon.Addon().getAddonInfo
    dataPath = xbmc.translatePath(addonInfo('profile')).decode('utf-8')
except:
  
    dataPath = os.path.dirname(os.path.realpath(__file__))
images_file = os.path.join(dataPath, 'images_file_nick.txt')
def getData(url):

 try:
        #print url
            logging.warning(url)
            req = urllib2.Request(url)
            req.add_header('User-Agent', __USERAGENT__)
            response = urllib2.urlopen(req)
            contentType = response.headers['content-type']

            data = response.read().replace("\n", "").replace("\t", "").replace("\r", "")
           
            response.close()            
            

            return contentType, data
 except Exception as e:
    xbmc.sleep(100)
    
    response = urllib2.urlopen(req)
    contentType = response.headers['content-type']

    data = response.read().replace("\n", "").replace("\t", "").replace("\r", "")
   
    response.close()            
    

    return contentType, data
    logging.warning(str(e))
    
def clean(contentType, name):
    return name
    try:
         
        if isinstance(name, str):
         
            if contentType.lower().find('utf-8') == -1: 
            
                name = name.decode('windows-1255', 'replace')
                name = name.encode('utf-8')
        elif isinstance(name, unicode):
            name = name.encode('utf-8')    
 
    except Exception as e:
         print 'Error in clean: '
         print e
         raise e
#     if (name):
#         cleanName = name.replace("&quot;", "\"").replace("&#39;", "'").replace("&nbsp;", " ")
#         return  cleanName
    return name
def ghk_new():
    global all_dub
    logging.warning('get GhostK')
    import cache
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    
    
    l_list='https://raw.githubusercontent.com/moshep15/back/master/onlykids.txt'
    #l_list=Addon.getSetting("ghaddr").decode('base64')
    cacheFile=os.path.join(user_dataDir3,'localfile.txt')
    if not os.path.exists(cacheFile):
       
        download_file(l_list,user_dataDir3)

        unzip(os.path.join(user_dataDir3, "fixed_list.txt"),user_dataDir3)

    else:

        all_img=cache.get(renew_data,1,user_dataDir3,l_list, table='posters')
    
    


    dbcon = database.connect(cacheFile)
    dbcur = dbcon.cursor()
    dbcur.execute("SELECT * FROM MyTable where REPLACE(father,' ','')=REPLACE('[B][COLOR orange]ילדים[/B][/COLOR][B]סדרות לילדים מדובבים[/B]',' ','') or  REPLACE(father,' ','')=REPLACE('[B][COLOR orange]ילדים[/B][/COLOR][B]סדרות נוסטלגיה לילדים[/B]',' ','')")
    match = dbcur.fetchall()
    
    logging.warning('GhostK')
    logging.warning(len(match))
    for index,name,f_link,icon,fanart,plot,data,date,year,genre,father,type in match:
        name=name.replace('%27',"'")
        plot=plot.replace('%27',"'")
        data=data.replace('%27',"'")
        try:
            f_link=gdecom(f_link)
        except:
           pass
    
            
        all_dub.append((name,f_link,icon,fanart,plot,'[[GhostK]]'))
    return all_dub
def NickJr():
 
    global all_dub
    #tv_mode=__settings__.getSetting(id = 'deviceId')
    all_dub=[]
    list=[]
    url='http://nickjr.walla.co.il/'
    #r = requests.get(url)
    contentType, page = getData(url+'tvshows')
    matches1 = re.compile('desktop&quot;:5(.*?)</section>',re.DOTALL).findall(page)

    match=re.compile('<a href="/(.*?)".*?<img src="(.*?)".*?cd-title>(.*?)<').findall(matches1[0])

            
    for link,image,name in match:

      if __BASENICKJADD__ not in link:
       link=__BASENICKJADD__+link
      #contentType, page = getData(link)
      #matche = re.compile('<div class="top_stripe_div".+?<img src="(.+?)">').findall(page)
      #if (len(matche)>0):
      # image=matche[0]
      #else:

      if '///' in image:
       image_fixed='http:' +image
      else:
       image_fixed='http:/' +image

      list.append((link,name))
      
      all_dub.append((clean(contentType,name),link,image_fixed,image_fixed,clean(contentType,name),'[[nickjr]]'))
    return all_dub
def getMatches(url, pattern):

 try:
        contentType, page = getData(url)
        matches = re.compile(pattern).findall(page)
        return contentType, matches 
 except Exception as e:
   
   logging.warning(str(e))
 
   pass
def GetlistMatch():
    
    list=[]

    contentType,block = getMatches(__BASE_URL_NICK__+'tvshows','desktop&quot;:5(.*?)</section>')
    page = re.compile('<a href="/(.*?)".*?<img src="(.*?)".*?cd-title>(.*?)<').findall(block[0])

    for path in page:
                
                summary = ''
                url=__BASE_URL_NICK__ + path[0]
            
                iconImage='http:' + path[1]
                title=path[2]
               
                list.append((clean(contentType,title),__BASE_URL_NICK__ + path[0],iconImage))
                
    return list
def nicolodiaon():
            global all_dub2
            list2=[]
            names=[]
            all_dub2=[]
  
           
            matches_list=GetlistMatch()
     
    
            for items in matches_list:
               list2.append(items[1])
               names.append(items[0])
              
               all_dub2.append((items[0], items[1], items[2], items[2], '','[[Nicolodian]]'))
            
            return all_dub2
def html_decode(s):
   
    """
    Returns the ASCII decoded version of the given HTML string. This does
    NOT remove normal HTML tags like <p>.
    """
    htmlCodes = (
            ("'", '&#39;'),
            ('"', '&quot;'),
            ('>', '&gt;'),
            ('<', '&lt;'),
            ('-','&#8211;'),
            ('&', '&amp;')
        )
    for code in htmlCodes:
        s = s.replace(code[1], code[0])
    return s
def get_youtube_data(link_url,xxx):
   global all_data_you
   contentType, page = getData(link_url)

   matche = re.compile('yt-lockup yt-lockup-tile yt-lockup-video vve-check clearfix(.+?)</div></div></div>',re.DOTALL).findall(page)
   for links in matche:
    link=re.compile('<a href="(.+?)"').findall(links)
    name=re.compile('title="(.+?)"').findall(links)
    
    

    link[0]=link[0][9:]

    name_final=name[0]
    if "Watch Later" in name[0]:
       name_final=name[1]
    if "Queue" in name[1]:
       name_final=name[2]


    image=re.compile('<img.+?"https:(.+?)"',re.DOTALL).findall(links)
    all_data_you.append((name_final,link[0],image[0],xxx))
    
def results_Youtube(link_url,pages=False):
   import time,xbmcgui
   global all_data_you
   start_time=time.time()
   if Addon.getSetting("dp")=='true':
                dp = xbmcgui.DialogProgress()
                dp.create("טוען סרטים", "אנא המתן", '')
                dp.update(0)
   all_data_you=[]
   #tv_mode=__settings__.getSetting(id = 'deviceId')
  

   thread=[]
   x=0
   regex='page=(.+?)$'
   page_no=int(re.compile(regex).findall(link_url)[0])
   xxx=0
   for page in range(page_no,page_no+2):
        link=(link_url.split('page=')[0])+'page='+str(page)
        get_youtube_data(link,xxx)
        #thread.append(Thread(get_youtube_data,link_url,xxx))
        #thread[len(thread)-1].setName('עמוד ' + str(page))
        xxx+=1
   '''
   for td in thread:
        td.start()

        if Addon.getSetting("dp")=='true':
                elapsed_time = time.time() - start_time
                dp.update(0, ' מפעיל '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),td.name)
        #if len(thread)>38:
        xbmc.sleep(25)
   while 1:
          
          still_alive=0
          all_alive=[]
          for yy in range(0,len(thread)):
            
            if  thread[yy].is_alive():
              all_alive.append(thread[yy].name)
              still_alive=1
          if Addon.getSetting("dp")=='true':
                elapsed_time = time.time() - start_time
                dp.update(0, ' אנא המתן '+ time.strftime("%H:%M:%S", time.gmtime(elapsed_time)),','.join(all_alive))
          if still_alive==0:
            break
          xbmc.sleep(100)

   '''
   all_data_you=sorted(all_data_you, key=lambda x: x[3], reverse=False)
   for name_final,link,image,xxx in all_data_you:
       video_data={}
       video_data['title']=html_decode(name_final)
       video_data['icon']='https:'+image
       video_data['fanart']='https:'+image
       video_data['plot']=html_decode(name_final)+'-HebDub-'
       nm=html_decode(name_final)
       addLink(nm,'https://www.youtube.com/watch?v='+link,5,False,'https:'+image,'https:'+image,html_decode(name_final),video_info=json.dumps(video_data),original_title=nm)
   if pages:
        regex='page=(.+?)$'
        match=re.compile(regex).findall(link_url)
        link=link_url.split('page=')[0]
        
        addDir3('[COLOR aqua][I]עוד תוצאות[/I][/COLOR]'.decode('utf8'),link+'page='+str(int(match[0])+2),117,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTTNmz-ZpsUi0yrgtmpDEj4_UpJ1XKGEt3f_xYXC-kgFMM-zZujsg','https://cdn4.iconfinder.com/data/icons/arrows-1-6/48/1-512.png','עוד תוצאות'.decode('utf8'))
def Trailer_Youtube(link_url,now):
  try:
   import datetime
   
   #tv_mode=__settings__.getSetting(id = 'deviceId')
   list=[]
   names=[]
   
   x=0
   all_d=[]
   
   contentType, page = getData(link_url)

   matche = re.compile('yt-lockup yt-lockup-tile yt-lockup-video vve-check clearfix(.+?)</div></div></div>',re.DOTALL).findall(page)
  
   
   for links in matche:
    link=re.compile('<a href="(.+?)"').findall(links)
    name=re.compile('title="(.+?)"').findall(links)
    
    
    x=x+1
    link[0]=link[0][9:]
    name_final=name[0]
    for items in name:
        
        if "watch later" not in items.lower() and "queue" not in items.lower():
            name_final=items
            break
    
    list.append(link[0])
    names.append(html_decode(name_final))
    image=re.compile('<img.+?"https:(.+?)"',re.DOTALL).findall(links)
    video_data={}
    video_data['title']=html_decode(name_final)
    video_data['icon']='https:'+image[0]
    video_data['fanart']='https:'+image[0]
    video_data['plot']=html_decode(name_final)+'-HebDub-'
  
    all_d.append(addLink(html_decode(name_final),'https://www.youtube.com/watch?v='+link[0],5,False,'https:'+image[0],'https:'+image[0],html_decode(name_final),video_info=json.dumps(video_data)))
   
   link_url='https://www.youtube.com/results?q='+ str(now.year) + '+%22%D7%98%D7%A8%D7%99%D7%99%D7%9C%D7%A8+%D7%9E%D7%93%D7%95%D7%91%D7%91%22&sp=SBTqAwA%253D'
   contentType, page = getData(link_url)

   matche2 = re.compile('yt-lockup yt-lockup-tile yt-lockup-video vve-check clearfix(.+?)</div></div></div>',re.DOTALL).findall(page)
   for links in matche2:
    
    link=re.compile('<a href="(.+?)"').findall(links)
    name=re.compile('title="(.+?)"').findall(links)

    link[0]=link[0][9:]

    name_final=name[0]
    for items in name:
        
        if "watch later" not in items.lower() and "queue" not in items.lower():
            name_final=items
            break
    list.append(link[0])
    names.append(html_decode(name_final))
    image=re.compile('<img.+?"https:(.+?)"',re.DOTALL).findall(links)
    
    video_data={}
    video_data['title']=html_decode(name_final)
    video_data['icon']='https:'+image[0]
    video_data['fanart']='https:'+image[0]
    video_data['plot']=html_decode(name_final)+'-HebDub-'
    
     
    all_d.append(addLink(html_decode(name_final),'https://www.youtube.com/watch?v='+link[0],5,False,'https:'+image[0],'https:'+image[0],html_decode(name_final),video_info=json.dumps(video_data)))
    #addDir3(html_decode(name_final),link[0],8,'https:'+image[0],'https:'+image[0],'https:'+image[0],"0") 
   xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
  except Exception as e:    #xbmc.Player().play(playback_url)
  
    logging.warning("FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF3"+ str(e))
    logging.warning(len(matche))
    pass
def get_youtube_lists_little():
  global all_dub3
  list=[]
  list2=[]
  names=[]
  names2=[]
  all_dub3=[]
  Addon = xbmcaddon.Addon()

  addonPath = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
  tmdb_data_dir = addonPath#os.path.join(addonPath, 'resources', 'tmdb_data')
  tmdb_cacheFile = os.path.join(tmdb_data_dir, 'youtube.db')
  dbcon = database.connect(tmdb_cacheFile)
  dbcur = dbcon.cursor()
  dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""link TEXT,""icon TEXT,""fanart TEXT,""plot TEXT);"% 'youtbe_little')

  try:
        dbcur.execute("VACUUM 'AllData';")
        dbcur.execute("PRAGMA auto_vacuum;")
        dbcur.execute("PRAGMA JOURNAL_MODE=MEMORY ;")
        dbcur.execute("PRAGMA temp_store=MEMORY ;")
  except:
   pass
  dbcon.commit()
    
  #tv_mode=__settings__.getSetting(id = 'deviceId')

  
  f_path=os.path.join(dir_path,'youtube_playlist_little.html')
  playlists= open(f_path,'r').read()
 
  
  youtube_playlists = re.compile('List"(.+?)"EndList').findall(playlists)
  
 
  x=0
  for link in  youtube_playlists:

    dbcur.execute("SELECT * FROM youtbe_little WHERE link = '%s'"%(link))

    match = dbcur.fetchone()
    if match==None:
      
      
        try:
          
          contentType, page = getData(link)
        
          matche = re.compile('<div class="playlist-info">.+?<ul class="playlist-details">',re.DOTALL).findall(page)
         
          matches = re.compile('data-sessionlink="ei=(.+?)" >(.+?)</a>').findall(matche[0])
          
          matches3 = re.compile('data-thumbnail-url="(.+?).:?(jpg|png)').findall(page)
          names.append(html_decode(matches[0][1]))
        
          list.append(link)
          dbcur.execute("INSERT INTO youtbe_little Values ('%s', '%s', '%s', '%s','%s');" %  (html_decode(matches[0][1]).replace("'"," "),link,matches3[0][0]+"."+matches3[0][1],matches3[0][0]+"."+matches3[0][1],html_decode(matches[0][1]).replace("'"," ")))
          dbcon.commit()
          video_data={}
          video_data['title']=html_decode(matches[0][1])
          video_data['icon']=matches3[0][0]+"."+matches3[0][1]
          video_data['fanart']=matches3[0][0]+"."+matches3[0][1]
          video_data['plot']=html_decode(matches[0][1])
         
          addDir3(html_decode(matches[0][1]),'[[youtube]]'+link,46,matches3[0][0]+"."+matches3[0][1],matches3[0][0]+"."+matches3[0][1],html_decode(matches[0][1]),video_info=video_data)
          
          
          
        except Exception as e:
            import linecache
            exc_type, exc_obj, tb = sys.exc_info()
            f = tb.tb_frame
            lineno = tb.tb_lineno
            filename = f.f_code.co_filename
            linecache.checkcache(filename)
            line = linecache.getline(filename, lineno, f.f_globals)
            
            logging.warning('ERROR IN KIDSTV play:'+str(lineno))
            logging.warning('inline:'+line)
            logging.warning(e)
            logging.warning(link)
           
    else:
      name,link,icon,image,plot=match
     
      video_data={}
      video_data['title']=name
      video_data['icon']=icon
      video_data['fanart']=image
      video_data['plot']=plot
     
      addDir3(name,'[[youtube]]'+link,46,icon,image,plot,video_info=video_data)
  dbcur.close()
  dbcon.close()
  return all_dub3
def get_youtube_lists():
  global all_dub3
  list=[]
  list2=[]
  names=[]
  names2=[]
  all_dub3=[]
  Addon = xbmcaddon.Addon()
  try:
    from sqlite3 import dbapi2 as database
  except:
    from pysqlite2 import dbapi2 as database
  addonPath = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
  tmdb_data_dir = addonPath#os.path.join(addonPath, 'resources', 'tmdb_data')
  tmdb_cacheFile = os.path.join(tmdb_data_dir, 'youtube.db')
  dbcon = database.connect(tmdb_cacheFile)
  dbcur = dbcon.cursor()
  dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""link TEXT,""icon TEXT,""fanart TEXT,""plot TEXT);"% 'youtbe')

  try:
        dbcur.execute("VACUUM 'AllData';")
        dbcur.execute("PRAGMA auto_vacuum;")
        dbcur.execute("PRAGMA JOURNAL_MODE=MEMORY ;")
        dbcur.execute("PRAGMA temp_store=MEMORY ;")
  except:
   pass
  dbcon.commit()
    
  #tv_mode=__settings__.getSetting(id = 'deviceId')

  
  f_path=os.path.join(dir_path,'youtube_playlist.html')
  playlists= open(f_path,'r').read()
 
  
  youtube_playlists = re.compile('List"(.+?)"EndList').findall(playlists)
  
 
  x=0
  for link in  youtube_playlists:

    dbcur.execute("SELECT * FROM youtbe WHERE link = '%s'"%(link))

    match = dbcur.fetchone()
    if match==None:
      
      
        try:
          
          contentType, page = getData(link)
        
          matche = re.compile('<div class="playlist-info">.+?<ul class="playlist-details">',re.DOTALL).findall(page)
         
          matches = re.compile('data-sessionlink="ei=(.+?)" >(.+?)</a>').findall(matche[0])
          
          matches3 = re.compile('data-thumbnail-url="(.+?).:?(jpg|png)').findall(page)
          names.append(html_decode(matches[0][1]))
        
          list.append(link)
          dbcur.execute("INSERT INTO youtbe Values ('%s', '%s', '%s', '%s','%s');" %  (html_decode(matches[0][1]).replace("'"," "),link,matches3[0][0]+"."+matches3[0][1],matches3[0][0]+"."+matches3[0][1],html_decode(matches[0][1]).replace("'"," ")))
          dbcon.commit()
          all_dub3.append((html_decode(matches[0][1]),link,matches3[0][0]+"."+matches3[0][1],matches3[0][0]+"."+matches3[0][1],html_decode(matches[0][1]),'[[youtube]]'))
          
        except Exception as e:
          logging.warning( 'ERROR ' + link)
          logging.warning( e)
    else:
      name,link,icon,image,plot=match
      all_dub3.append((name,link,icon,image,plot,'[[youtube]]'))
  dbcur.close()
  dbcon.close()
  return all_dub3

def Sdarot_Tv():
    from sdarot import resolve_dns
    global all_dub4
    all_dub4=[]
    all_names=[]
    import requests
    API='https://api.sdarot.tv'
    POSTER_PREFIX='https://static.sdarot.website/series/'
    
    all_generes=['38','7','44','55']
    all_ge_name=['ילדים','אנימציה','נוער','דיסני']
    for items in all_generes:
        req,cookie_new = resolve_dns(API + '/series/list/{0}/page/0/perPage/100'.format(items)).get()
        
        req=json.loads(req)
        logging.warning(API + '/series/list/{0}/page/0/perPage/100'.format(items))
        
        for s in req['series']:
                label = (s['heb'].encode('utf-8'))

                if  'מדובב' in label:
                    add_dis='[COLOR yellow] מדובב[/COLOR]\n'
                else:
                    add_dis=''
                
                all_dub4.append((label,s['id'],POSTER_PREFIX + s['poster'],POSTER_PREFIX + s['poster'],add_dis+s['description'],'[[Sdarot]]'))
                all_names.append(s['id'])
        for pages in range(1,int(req['pages']['totalPages'])):
        
            req,cookie_new = resolve_dns(API + '/series/list/{0}/page/{1}/perPage/100'.format(items, str(pages))).get()
            req=json.loads(req)
            if 'series' not in req:
                continue
            if req['series']==None:
                continue
            for s in req['series']:
                label = (s['heb'].encode('utf-8'))
               
            
            
            
                if  'מדובב' in label:
                    add_dis='[COLOR yellow] מדובב[/COLOR]\n'
                else:
                    add_dis=''
                
                all_dub4.append((label,s['id'],POSTER_PREFIX + s['poster'],POSTER_PREFIX + s['poster'],add_dis+s['description'],'[[Sdarot]]'))
                all_names.append(s['id'])
              
    
    return all_dub4
def get_aven():
    global all_dub7
    logging.warning('get Aven')
    import cache
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    
    

   
    l_list='https://raw.githubusercontent.com/kodimen/Steve-Rogers/master/%D7%94%D7%A0%D7%95%D7%A7%D7%9D%20%D7%94%D7%A8%D7%90%D7%A9%D7%95%D7%9F.txt'
    cacheFile=os.path.join(user_dataDir2,'localfile.txt')
    if not os.path.exists(cacheFile):
       
        download_file(l_list,user_dataDir2)

        unzip(os.path.join(user_dataDir2, "fixed_list.txt"),user_dataDir2)

    else:

        all_img=cache.get(renew_data,1,user_dataDir2,l_list, table='posters')
    
    


    dbcon = database.connect(cacheFile)
    dbcur = dbcon.cursor()
    dbcur.execute("SELECT * FROM MyTable where REPLACE(father,' ','')=REPLACE('[B][COLOR deepskyblue] הנוקם הראשון סדרות בתרגום מובנה [/COLOR][/B]סדרות מדובבות לילדים',' ','')")
    match = dbcur.fetchall()
    logging.warning('all_dub7:'+str(len(match)))
    logging.warning(len(match))
    for index,name,f_link,icon,fanart,plot,data,date,year,genre,father,type in match:
        name=name.replace('%27',"'")
        plot=plot.replace('%27',"'")
        data=data.replace('%27',"'")
        try:
            f_link=gdecom(f_link)
        except:
           pass
    
            
        all_dub7.append((name,f_link,icon,fanart,plot,'[[Aven]]'))
    return all_dub7
def get_ghost():
    global all_dub6
    logging.warning('get Ghost')
    import cache
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    
    
    #l_list='https://files.fm/pa/moshep1977/upload/1.txt'
    l_list=Addon.getSetting("ghaddr").decode('base64')
    cacheFile=os.path.join(user_dataDir,'localfile.txt')
    if not os.path.exists(cacheFile):
       
        download_file(l_list,user_dataDir)

        unzip(os.path.join(user_dataDir, "fixed_list.txt"),user_dataDir)

    else:

        all_img=cache.get(renew_data,1,user_dataDir,l_list, table='posters')
    
    


    dbcon = database.connect(cacheFile)
    dbcur = dbcon.cursor()
    dbcur.execute("SELECT * FROM MyTable where REPLACE(father,' ','')=REPLACE('[B][COLOR orange]ילדים[/B][/COLOR][B]סדרות לילדים מדובבים[/B]',' ','')")
    match = dbcur.fetchall()
    logging.warning('Ghost')
    logging.warning(len(match))
    for index,name,f_link,icon,fanart,plot,data,date,year,genre,father,type in match:
        name=name.replace('%27',"'")
        plot=plot.replace('%27',"'")
        data=data.replace('%27',"'")
        try:
            f_link=gdecom(f_link)
        except:
           pass
    
            
        all_dub6.append((name,f_link,icon,fanart,plot,'[[Ghost]]'))
    return all_dub6
def get_small():
    global all_dub5
    import requests
    all_dub5=[]
    headers= {
                                
                                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
                                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                                'Accept-Language': 'en-US,en;q=0.5',
                                'Connection': 'keep-alive',
                                'Upgrade-Insecure-Requests': '1',
                            }
    html=requests.get('https://hatzerim.wordpress.com/',headers=headers).content
    regex='<li id="menu-item-.+?" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-.+?"><a href="(.+?)">(.+?)<|<li id="menu-item-.+?" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-.+?"><a href="(.+?)">(.+?)<'
    match=re.compile(regex).findall(html)
    image_all={}
    from resources.modules.image_small import images_all
    for topic_link,topic_name,link,name in match:
      if len (topic_link)>0:
        topic_name=topic_name
      else:
        
          if 0:
            x=0
            html2=requests.get(link).content
            regex2='<meta property="og:image" content="(.+?)"'
            match2=re.compile(regex2).findall(html2)
            image=match2[0]
            
            image_all[name.encode('utf8')]=image
          if name in images_all:
            image=images_all[name]
          name=html_decode(name.decode('utf-8')).encode('utf-8')
          all_dub5.append((name,link,image,image,name,'[[Small]]'))
    return all_dub5
def get_anime(link_o,search_entered=''):
    try:
      link_o=int(link_o)
    except:
       link_o=0

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0',
        'Accept': 'application/json, text/javascript, */*; q=0.01',
        'Accept-Language': 'en-US,en;q=0.5',
        'Referer': 'https://www.anime-spin.net/%D7%A6%D7%A4%D7%99%D7%99%D7%94/',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'X-Requested-With': 'XMLHttpRequest',
        'Connection': 'keep-alive',
        'Pragma': 'no-cache',
        'Accept-Encoding':'utf-8',

        'Cache-Control': 'no-cache',
    }
    
    x=requests.get('https://www.anime-spin.net/%D7%A6%D7%A4%D7%99%D7%99%D7%94/',headers=headers)
    regex='name="csrf-token" content="(.+?)"'
    match=re.compile(regex).findall(x.content)
    cook=(x.cookies)
    if search_entered!='':
        data = [
          ('token', match[0]),
          ('text', search_entered),
          
        ]

        response = requests.post('https://www.anime-spin.net/ajax/search', headers=headers, data=data,cookies=cook).text
        r=response.decode('unicode_escape').replace('\/','/')
        
        regex='a href="(.+?)".+?img src="(.+?)".+?<span class="data">(.+?)<'
        match=re.compile(regex,re.DOTALL).findall(r)

     
        for link,image,name in match:
            video_data={}
            video_data['title']=name
            video_data['icon']=image
            video_data['fanart']=image
            video_data['plot']=name
            
            addDir3(name,'[[anime]]'+link.encode('utf8'),46,image,image,name,video_info=video_data)
    else:
        data = [
          ('token', match[0]),
          ('type', 'popular'),
          ('from', link_o),
          ('limit', '18'),
        ]

        response = requests.post('https://www.anime-spin.net/ajax/watchFilters', headers=headers, data=data,cookies=cook).text
        r=response.decode('unicode_escape').replace('\/','/')#.replace('\u003C','<').replace('\u003E','>').replace('/\\','/').replace('\/','/').replace('\\"','"')
        regex_pre='<div class="item"(.+?)</div>'
        match_pre=re.compile(regex_pre,re.DOTALL).findall(r)
   
        for items in match_pre:
            
            regex='img src="(.+?)".+?a href="(.+?)".+?<h3>(.+?)</h3>.+?<h4>(.+?)</h4>'
            match=re.compile(regex,re.DOTALL).findall(items)

          
            for image,link,name,plot in match:
                video_data={}
                video_data['title']=name
                video_data['icon']=image
                video_data['fanart']=image
                video_data['plot']=plot
                
                addDir3(name,'[[anime]]'+link.encode('utf8'),46,image,image,plot,video_info=video_data)
        addDir3('[COLOR aqua][I]עמוד הבא[/I][/COLOR]',str(int(link_o)+18),52,' ',' ',' ')
def update_now_tv(progress=False):
    logging.warning('background')
    import time
    from time import gmtime, strftime
    import datetime
    import _strptime
    from datetime import datetime

    
    
    
    
    if (progress):
        import xbmcgui
        dp = xbmcgui . DialogProgress ( )
        dp.create('אנא המתן','מעדכן סדרות', '','')
        dp.update(0, 'אנא המתן','מעדכן סדרות', '' )
    global all_dub,all_dub2,all_dub3,all_dub4,all_dub5,all_dub6,all_dub7
    addonPath = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
    tmdb_data_dir = addonPath#os.path.join(addonPath, 'resources', 'tmdb_data')
    tmdb_cacheFile = os.path.join(tmdb_data_dir, 'youtube.db')
    start_time=time.time()
    logging.warning('Waiting for play')
    
    
    logging.warning('Done Waiting')
    thread=[]
    search_entered=''
    if search_entered=='youtube only':
        thread.append(Thread(get_youtube_lists))
    else:
        #thread.append(Thread(NickJr))
        #thread.append(Thread(nicolodiaon))
        #thread.append(Thread(get_youtube_lists))
        #thread[len(thread)-1].setName('youtube')
        thread.append(Thread(Sdarot_Tv))
        thread[len(thread)-1].setName('Sdarot')
        thread.append(Thread(get_small))
        thread[len(thread)-1].setName('small')
        #thread.append(Thread(get_ghost))
        #thread.append(Thread(get_aven))

   
    for td in thread:
          td.start()
    if (progress):
        elapsed_time = time.time() - start_time
        dp.update(0, 'אנא המתן','מעדכן סדרות',time.strftime("%H:%M:%S", time.gmtime(elapsed_time))+ '\nמתחיל סריקה' )
    while 1:

        
        for threads in thread:
       
            still_alive=0
            all_alive=[]
            all_d=0
            for yy in range(0,len(thread)):
                    if thread[yy].is_alive():
                      all_alive.append(thread[yy].getName())
                      still_alive=1
                    else:
                        all_d+=1
        if still_alive==0:
          break
        if (progress):
            elapsed_time = time.time() - start_time
            dp.update(int(((all_d* 100.0)/(len(thread))) ), 'אנא המתן',time.strftime("%H:%M:%S", time.gmtime(elapsed_time)), ','.join(all_alive))
        
        xbmc.sleep(1000)
    if (progress):
            dp.close()
    logging.warning('all_dub:'+str(len(all_dub)))
    logging.warning('all_dub2:'+str(len(all_dub2)))
    logging.warning('all_dub3:'+str(len(all_dub3)))
    logging.warning('all_dub4:'+str(len(all_dub4)))
    logging.warning('all_dub5:'+str(len(all_dub5)))
    logging.warning('all_dub6:'+str(len(all_dub6)))
    logging.warning('all_dub7:'+str(len(all_dub7)))
    all_data_tog=all_dub+all_dub2+all_dub3+all_dub4+all_dub5+all_dub6+all_dub7
    
    dbcon = database.connect(tmdb_cacheFile)
    dbcur = dbcon.cursor()
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""link TEXT,""icon TEXT, ""image TEXT,""plot TEXT,""origin TEXT);"% 'kids_show')
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""date TEXT,""type TEXT);" % 'updated')
    dbcur.execute("DELETE FROM kids_show")
    dbcon.commit()
    for name1,link,icon,image,plot,origin in all_data_tog:
       dbcur.execute("INSERT INTO %s Values (?,?,?,?,?,?)" % 'kids_show', (name1.decode('utf8'),link.decode('utf8'),icon.decode('utf8'),image.decode('utf8'),plot.decode('utf8'),origin.decode('utf8')))
    dbcur.execute("DELETE FROM updated  where type='tv'")
    
    
    # datetime object containing current date and time
    now = datetime.now()
    a = now.strftime('%H:%M:%S %d/%m/%Y')
    dbcur.execute("INSERT INTO updated Values ('%s','%s')"%(str(a),'tv'))
    
    dbcon.commit()
    
    
    
    
    all_links={}
    all_names=[]
    count=0
    addonPath = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
    tmdb_data_dir = addonPath#os.path.join(addonPath, 'resources', 'tmdb_data')
    tmdb_cacheFile = os.path.join(tmdb_data_dir, 'youtube.db')
    dbcon = database.connect(tmdb_cacheFile)
    dbcur = dbcon.cursor()
    
    
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""link TEXT,""icon TEXT,""fanart TEXT,""plot TEXT,""video_data TEXT);"% 'kids_show_orginized')
    
    
    dbcur.execute("DELETE FROM kids_show_orginized")
    dbcon.commit()
    dbcur.execute("SELECT * FROM kids_show ")

    match = dbcur.fetchall()
    xx=0
    for name1,link,icon,image,plot,origin in match:
          if (progress):
              dp.update(int(((xx* 100.0)/(len(match))) ), 'אנא המתן','אוסף', name1 )
              xx+=1
          check=True
          if search_entered=='youtube only':
             check=False
             if origin=='[[youtube]]':
               check=True
          add_l=''
          if 'מדובב'.decode('utf-8') in name1 and 'Sdarot' in origin:
            add_l='מדובב'
            
          name1=html_decode(name1.replace('מדובב','').replace('*','').replace(':','').replace('-','').strip()).decode('utf-8')#.replace('מדובב','').replace('*','').replace(':','').replace('-','')
          origin_n=origin.replace('[','').replace(']','')
          if name1 not in all_links:
   
             all_names.append(name1)
             all_links[name1]={}
             all_links[name1]['icon']=icon
             all_links[name1]['image']=image
             all_links[name1]['plot']=plot
  
             all_links[name1]['link']=origin+link+add_l
             all_links[name1]['origin']=origin_n
          else:
               if link not in all_links[name1]['link']:
                 if '$$$' in link:
                      links=link.split('$$$')
                      for link in links:
                        all_links[name1]['link']=all_links[name1]['link']+'$$$'+origin+link+add_l
                 else:
                   all_links[name1]['link']=all_links[name1]['link']+'$$$'+origin+link+add_l
                 all_links[name1]['origin']=all_links[name1]['origin']+','+origin_n
    xx=0
    all_l=[]
    for items in all_links:
        if (progress):
              dp.update(int(((xx* 100.0)/(len(match))) ), 'אנא המתן','אוסף2', items )
              xx+=1
        link=all_links[items]['link']
        icon=all_links[items]['icon']
        image=all_links[items]['image']
        plot=all_links[items]['plot']
        origin=all_links[items]['origin']
        video_data={}
        video_data['title']=items
        video_data['icon']=icon
        video_data['fanart']=image
        video_data['plot']='--[COLOR lightblue]'+origin+'[/COLOR]-- \n '+plot
        video_data['fast']=1
        dbcur.execute("INSERT INTO %s Values (?,?,?,?,?,?)" % 'kids_show_orginized', (items,link,icon,image,'--[COLOR lightblue]'+origin+'[/COLOR]--\n '+plot,json.dumps(video_data)))
        #all_l.append(addDir3(items,link,46,icon,image,'--[COLOR lightblue]'+origin+'[/COLOR]--\n '+plot,video_info=video_data))
        
    dbcon.commit()
    dbcur.close()
    dbcon.close()
    logging.warning('Done Updating')
    if progress:
        xbmc.executebuiltin('Container.Refresh')
        xbmc.executebuiltin((u'Notification(%s,%s)' % ('הכל לילדים', 'הכל עודכן')))
def get_background_data():
    logging.warning('background')
    global all_dub,all_dub2,all_dub3,all_dub4,all_dub5,all_dub6,all_dub7
    addonPath = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
    tmdb_data_dir = addonPath#os.path.join(addonPath, 'resources', 'tmdb_data')
    tmdb_cacheFile = os.path.join(tmdb_data_dir, 'youtube.db')
    
    logging.warning('Waiting for play')
    
    while 1:
        if  xbmc.Player().isPlaying() :
            if  xbmc.Player().getTime()>10:
                break
        xbmc.sleep(100)
    logging.warning('Done Waiting')
    thread=[]
    search_entered=''
    if search_entered=='youtube only':
        thread.append(Thread(get_youtube_lists))
    else:
        #thread.append(Thread(NickJr))
        #thread.append(Thread(nicolodiaon))
        thread.append(Thread(get_youtube_lists))
        thread.append(Thread(Sdarot_Tv))
        thread.append(Thread(get_small))
        #thread.append(Thread(get_ghost))
        #thread.append(Thread(get_aven))

   
    for td in thread:
          td.start()
    
    while 1:

    
        for threads in thread:
       
            still_alive=0
            for yy in range(0,len(thread)):
                    if thread[yy].is_alive():
                      
                      still_alive=1
        if still_alive==0:
          break
        xbmc.sleep(1000)
    logging.warning('all_dub:'+str(len(all_dub)))
    logging.warning('all_dub2:'+str(len(all_dub2)))
    logging.warning('all_dub3:'+str(len(all_dub3)))
    logging.warning('all_dub4:'+str(len(all_dub4)))
    logging.warning('all_dub5:'+str(len(all_dub5)))
    logging.warning('all_dub6:'+str(len(all_dub6)))
    logging.warning('all_dub7:'+str(len(all_dub7)))
    all_data_tog=all_dub+all_dub2+all_dub3+all_dub4+all_dub5+all_dub6+all_dub7
    
    dbcon = database.connect(tmdb_cacheFile)
    dbcur = dbcon.cursor()
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""link TEXT,""icon TEXT, ""image TEXT,""plot TEXT,""origin TEXT);"% 'kids_show')
    dbcur.execute("DELETE FROM kids_show")
    for name1,link,icon,image,plot,origin in all_data_tog:
       dbcur.execute("INSERT INTO %s Values (?,?,?,?,?,?)" % 'kids_show', (name1.decode('utf8'),link.decode('utf8'),icon.decode('utf8'),image.decode('utf8'),plot.decode('utf8'),origin.decode('utf8')))
    dbcur.execute("DELETE FROM updated  where type='tv'")
    from time import gmtime, strftime
    a=strftime("%Y-%m-%d %H:%M:%S", gmtime())
    
    dbcur.execute("INSERT INTO updated Values ('%s','%s')"%(str(a),'tv'))
    dbcon.commit()
    dbcur.close()
    dbcon.close()
    logging.warning('Done Updating')
def get_background_data_tr_tv():
        logging.warning('Starting Thread Update TV')
        thread=[]
        thread.append(Thread(get_background_data))
        thread[0].start()
        return 'OK'
def get_links(search_entered=''):
    import xbmcgui,cache
    logging.warning('start')
    if Addon.getSetting("kids_dp")=='true':
            dp = xbmcgui . DialogProgress ( )
            dp.create('אנא המתן','טוען', '','')
            dp.update(0, 'אנא המתן','טוען', '' )
    thread=[]
    #thread.append(Thread(get_background_data))
    #thread[0].start()
    
   
    #get_background_data()
    all_links={}
    all_names=[]
    count=0
    addonPath = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
    tmdb_data_dir = addonPath#os.path.join(addonPath, 'resources', 'tmdb_data')
    tmdb_cacheFile = os.path.join(tmdb_data_dir, 'youtube.db')
    dbcon = database.connect(tmdb_cacheFile)
    dbcur = dbcon.cursor()
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""link TEXT,""icon TEXT,""fanart TEXT,""plot TEXT,""origin TEXT);"% 'kids_show')
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""date TEXT,""type TEXT);" % 'updated')
    try:
            dbcur.execute("VACUUM 'kids_show';")
            dbcur.execute("PRAGMA auto_vacuum;")
            dbcur.execute("PRAGMA JOURNAL_MODE=MEMORY ;")
            dbcur.execute("PRAGMA temp_store=MEMORY ;")
    except:
       pass
    dbcon.commit()
    dbcur.execute("SELECT * FROM kids_show ")

    match = dbcur.fetchall()
    xx=0
    for name1,link,icon,image,plot,origin in match:
          if Addon.getSetting("kids_dp")=='true':
              dp.update(int(((xx* 100.0)/(len(match))) ), 'אנא המתן','אוסף', name1 )
              xx+=1
          check=True
          if search_entered=='youtube only':
             check=False
             if origin=='[[youtube]]':
               check=True
          add_l=''
          if 'מדובב' in name1 and 'Sdarot' in origin:
            add_l='מדובב'
            
          name1=html_decode(name1.replace('מדובב','').replace('*','').replace(':','').replace('-','').strip()).decode('utf-8')#.replace('מדובב','').replace('*','').replace(':','').replace('-','')
          origin_n=origin.replace('[','').replace(']','')
          if name1 not in all_links:
   
             all_names.append(name1)
             all_links[name1]={}
             all_links[name1]['icon']=icon
             all_links[name1]['image']=image
             all_links[name1]['plot']=plot
  
             all_links[name1]['link']=origin+link+add_l
             all_links[name1]['origin']=origin_n
          else:
               if link not in all_links[name1]['link']:
                 if '$$$' in link:
                      links=link.split('$$$')
                      for link in links:
                        all_links[name1]['link']=all_links[name1]['link']+'$$$'+origin+link+add_l
                 else:
                   all_links[name1]['link']=all_links[name1]['link']+'$$$'+origin+link+add_l
                 all_links[name1]['origin']=all_links[name1]['origin']+','+origin_n
    xx=0
    all_l=[]
    for items in all_links:
        if Addon.getSetting("kids_dp")=='true':
              dp.update(int(((xx* 100.0)/(len(match))) ), 'אנא המתן','אוסף2', items )
              xx+=1
        link=all_links[items]['link']
        icon=all_links[items]['icon']
        image=all_links[items]['image']
        plot=all_links[items]['plot']
        origin=all_links[items]['origin']
        video_data={}
        video_data['title']=items
        video_data['icon']=icon
        video_data['fanart']=image
        video_data['plot']='--[COLOR lightblue]'+origin+'[/COLOR]-- \n '+plot
        video_data['fast']=1
        if search_entered=='' or search_entered=='youtube only':
          all_l.append(addDir3(items,link,46,icon,image,'--[COLOR lightblue]'+origin+'[/COLOR]--\n '+plot,video_info=video_data))
        else:
          if search_entered in items:
            all_l.append(addDir3(items,link,46,icon,image,'--[COLOR lightblue]'+origin+'[/COLOR]--\n '+plot,video_info=video_data))
    if Addon.getSetting("kids_dp")=='true':
        dp.close()





    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_l,len(all_l))
    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_SORT_TITLE)
    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_YEAR)
    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_DATEADDED)
    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_RATING)
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
    dbcur.close()
    dbcon.close()
    all_img=cache.get(get_background_data_tr_tv,24, table='posters')

    
  
    