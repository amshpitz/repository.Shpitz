import logging #line:2
import random ,xbmcaddon,xbmcgui #line:3
import re ,requests #line:4
import subprocess #line:5
from copy import deepcopy #line:6
from time import sleep #line:7
import cache #line:8
from requests .sessions import Session #line:9
Addon =xbmcaddon .Addon ()#line:10
try :#line:12
    from urlparse import urlparse #line:13
except ImportError :#line:14
    from urllib .parse import urlparse #line:15
__version__ ="1.9.5"#line:17
DEFAULT_USER_AGENTS =["Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36","Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/65.0.3325.181 Chrome/65.0.3325.181 Safari/537.36","Mozilla/5.0 (Linux; Android 7.0; Moto G (5) Build/NPPS25.137-93-8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.137 Mobile Safari/537.36","Mozilla/5.0 (iPhone; CPU iPhone OS 7_0_4 like Mac OS X) AppleWebKit/537.51.1 (KHTML, like Gecko) Version/7.0 Mobile/11B554a Safari/9537.53","Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:60.0) Gecko/20100101 Firefox/60.0","Mozilla/5.0 (Macintosh; Intel Mac OS X 10.13; rv:59.0) Gecko/20100101 Firefox/59.0","Mozilla/5.0 (Windows NT 6.3; Win64; x64; rv:57.0) Gecko/20100101 Firefox/57.0"]#line:27
DEFAULT_USER_AGENT =random .choice (DEFAULT_USER_AGENTS )#line:29
BUG_REPORT ="""\
Cloudflare may have changed their technique, or there may be a bug in the script.

Please read https://github.com/Anorov/cloudflare-scrape#updates, then file a \
bug report at https://github.com/Anorov/cloudflare-scrape/issues."\
"""#line:36
ANSWER_ACCEPT_ERROR ="""\
The challenge answer was not properly accepted by Cloudflare. This can occur if \
the target website is under heavy load, or if Cloudflare is experiencing issues. You can
potentially resolve this by increasing the challenge answer delay (default: 8 seconds). \
For example: cfscrape.create_scraper(delay=15)

If increasing the delay does not help, please open a GitHub issue at \
https://github.com/Anorov/cloudflare-scrape/issues\
"""#line:46
class CloudflareScraper (Session ):#line:48
    def __init__ (OOOO0O0OO0OO00000 ,*O00OOO0OO00000O0O ,**OOOO000O00000O000 ):#line:49
        OOOO0O0OO0OO00000 .delay =OOOO000O00000O000 .pop ("delay",8 )#line:50
        OOOO0O0OO0OO00000 .timeout =OOOO000O00000O000 .pop ("timeout",40 )#line:51
        super (CloudflareScraper ,OOOO0O0OO0OO00000 ).__init__ (*O00OOO0OO00000O0O ,**OOOO000O00000O000 )#line:52
        if "requests"in OOOO0O0OO0OO00000 .headers ["User-Agent"]:#line:54
            OOOO0O0OO0OO00000 .headers ["User-Agent"]=DEFAULT_USER_AGENT #line:56
    def is_cloudflare_challenge (OOO0OOO0OOOOOO000 ,O0O00000O00000O00 ):#line:58
        return (O0O00000O00000O00 .status_code ==503 and O0O00000O00000O00 .headers .get ("Server","").startswith ("cloudflare")and b"jschl_vc"in O0O00000O00000O00 .content and b"jschl_answer"in O0O00000O00000O00 .content )#line:64
    def request (O0O00OO000O000000 ,OO0000OO0OO0OOO0O ,O00OOO00000OOOOOO ,*OO0O0O0OO00O0OO0O ,**O0O0OO00OO0OOOO00 ):#line:66
        OO000O000OOOOO000 =super (CloudflareScraper ,O0O00OO000O000000 ).request (OO0000OO0OO0OOO0O ,O00OOO00000OOOOOO ,*OO0O0O0OO00O0OO0O ,**O0O0OO00OO0OOOO00 )#line:69
        if O0O00OO000O000000 .is_cloudflare_challenge (OO000O000OOOOO000 ):#line:72
            OO000O000OOOOO000 =O0O00OO000O000000 .solve_cf_challenge (OO000O000OOOOO000 ,**O0O0OO00OO0OOOO00 )#line:73
        return OO000O000OOOOO000 #line:75
    def solve_cf_challenge (O000OOO00O0O0O00O ,O0000O0000OO00OO0 ,**O0O0O0OO000O000O0 ):#line:77
        sleep (O000OOO00O0O0O00O .delay )#line:78
        OOO0O0OOOO0O0OO00 =O0000O0000OO00OO0 .text #line:80
        OO00OO0O0O00O0OO0 =urlparse (O0000O0000OO00OO0 .url )#line:81
        OOO00000000O0OO00 =OO00OO0O0O00O0OO0 .netloc #line:82
        O0OOOOOO0O000000O ="%s://%s/cdn-cgi/l/chk_jschl"%(OO00OO0O0O00O0OO0 .scheme ,OOO00000000O0OO00 )#line:83
        O00O000000000O0OO =deepcopy (O0O0O0OO000O000O0 )#line:85
        OOO0O0O0OOOO00OOO =O00O000000000O0OO .setdefault ("params",{})#line:86
        OOO00O0O0OOO0OO00 =O00O000000000O0OO .setdefault ("headers",{})#line:87
        OOO00O0O0OOO0OO00 ["Referer"]=O0000O0000OO00OO0 .url #line:88
        try :#line:90
            OOO0O0O0OOOO00OOO ["jschl_vc"]=re .search (r'name="jschl_vc" value="(\w+)"',OOO0O0OOOO0O0OO00 ).group (1 )#line:91
            OOO0O0O0OOOO00OOO ["pass"]=re .search (r'name="pass" value="(.+?)"',OOO0O0OOOO0O0OO00 ).group (1 )#line:92
        except Exception as OO00O0OO0O0OO0OOO :#line:94
            raise ValueError ("Unable to parse Cloudflare anti-bots page: %s %s"%(OO00O0OO0O0OO0OOO .message ,BUG_REPORT ))#line:99
        OOO0O0O0OOOO00OOO ["jschl_answer"]=O000OOO00O0O0O00O .solve_challenge (OOO0O0OOOO0O0OO00 ,OOO00000000O0OO00 )#line:102
        OO0O0O000O00O00O0 =O0000O0000OO00OO0 .request .method #line:109
        O00O000000000O0OO ["allow_redirects"]=False #line:110
        OOO0OOOOOO0O0OOO0 =O000OOO00O0O0O00O .request (OO0O0O000O00O00O0 ,O0OOOOOO0O000000O ,**O00O000000000O0OO )#line:113
        OO00OOOO00OOOO0O0 =urlparse (OOO0OOOOOO0O0OOO0 .headers ["Location"])#line:115
        if not OO00OOOO00OOOO0O0 .netloc :#line:117
            OOO0OO0O0O00OO000 ="%s://%s%s"%(OO00OO0O0O00O0OO0 .scheme ,OOO00000000O0OO00 ,OO00OOOO00OOOO0O0 .path )#line:118
            return O000OOO00O0O0O00O .request (OO0O0O000O00O00O0 ,OOO0OO0O0O00OO000 ,**O0O0O0OO000O000O0 )#line:119
        return O000OOO00O0O0O00O .request (OO0O0O000O00O00O0 ,OOO0OOOOOO0O0OOO0 .headers ["Location"],**O0O0O0OO000O000O0 )#line:120
    def solve_challenge (OO0O0O00O000OOOOO ,OOOO00O0OO0O0OO00 ,O0OO000O0OOO0O00O ):#line:122
        try :#line:123
            O00O0O0OOOOOO000O =re .search (r"setTimeout\(function\(\){\s+(var " "s,t,o,p,b,r,e,a,k,i,n,g,f.+?\r?\n[\s\S]+?a\.value =.+?)\r?\n",OOOO00O0OO0O0OO00 ).group (1 )#line:125
        except Exception :#line:126
            raise ValueError ("Unable to identify Cloudflare IUAM Javascript on website. %s"%BUG_REPORT )#line:127
        O00O0O0OOOOOO000O =re .sub (r"a\.value = (.+ \+ t\.length).+",r"\1",O00O0O0OOOOOO000O )#line:129
        O00O0O0OOOOOO000O =re .sub (r"\s{3,}[a-z](?: = |\.).+","",O00O0O0OOOOOO000O ).replace ("t.length",str (len (O0OO000O0OOO0O00O )))#line:130
        O00O0O0OOOOOO000O =re .sub (r"[\n\\']","",O00O0O0OOOOOO000O )#line:134
        if "toFixed"not in O00O0O0OOOOOO000O :#line:136
            raise ValueError ("Error parsing Cloudflare IUAM Javascript challenge. %s"%BUG_REPORT )#line:137
        O000OOOOOOOOO000O =js2py_o .eval_js (O00O0O0OOOOOO000O )#line:143
        try :#line:156
            float (O000OOOOOOOOO000O )#line:157
        except Exception :#line:158
            raise ValueError ("Cloudflare IUAM challenge returned unexpected answer. %s"%BUG_REPORT )#line:159
        return O000OOOOOOOOO000O #line:161
    @classmethod #line:163
    def create_scraper (OOO000O0OOOO00O00 ,sess =None ,**O00O000O0O000OO0O ):#line:164
        ""#line:167
        O0O00O0000OOOO000 =OOO000O0OOOO00O00 (**O00O000O0O000OO0O )#line:168
        if sess :#line:170
            OOO0OOOO000O00OO0 =["auth","cert","cookies","headers","hooks","params","proxies","data"]#line:171
            for O0OO000OOO000000O in OOO0OOOO000O00OO0 :#line:172
                OO0O0O0O00O00O000 =getattr (sess ,O0OO000OOO000000O ,None )#line:173
                if OO0O0O0O00O00O000 :#line:174
                    setattr (O0O00O0000OOOO000 ,O0OO000OOO000000O ,OO0O0O0O00O00O000 )#line:175
        return O0O00O0000OOOO000 #line:177
    @classmethod #line:182
    def get_tokens (O0000O0O00O00O0O0 ,O00OO0O0O00000OOO ,timeout =40 ,user_agent =None ,**OOO00O0OO000O0O00 ):#line:183
        OOO0O0O000OOO0O00 =O0000O0O00O00O0O0 .create_scraper ()#line:184
        if user_agent :#line:186
            OOO0O0O000OOO0O00 .headers ["User-Agent"]=user_agent #line:187
        try :#line:189
            OOO0OOO0O0OO00OO0 =OOO0O0O000OOO0O00 .get (O00OO0O0O00000OOO ,**OOO00O0OO000O0O00 )#line:190
            OOO0OOO0O0OO00OO0 .raise_for_status ()#line:191
        except Exception as O000OOO0000000O0O :#line:192
            raise #line:194
        OOOOO0OOO00O0OO00 =urlparse (OOO0OOO0O0OO00OO0 .url ).netloc #line:196
        O0000O000O000O00O =None #line:197
        for OOO00000O000OOOO0 in OOO0O0O000OOO0O00 .cookies .list_domains ():#line:199
            if OOO00000O000OOOO0 .startswith (".")and OOO00000O000OOOO0 in ("."+OOOOO0OOO00O0OO00 ):#line:200
                O0000O000O000O00O =OOO00000O000OOOO0 #line:201
                break #line:202
        else :#line:203
            raise ValueError ("Unable to find Cloudflare cookies. Does the site actually have Cloudflare IUAM (\"I'm Under Attack Mode\") enabled?")#line:204
        return ({"__cfduid":OOO0O0O000OOO0O00 .cookies .get ("__cfduid","",domain =O0000O000O000O00O ),"cf_clearance":OOO0O0O000OOO0O00 .cookies .get ("cf_clearance","",domain =O0000O000O000O00O )},OOO0O0O000OOO0O00 .headers ["User-Agent"])#line:211
    @classmethod #line:213
    def get_cookie_string (OO0OO000OO000O0OO ,O00000O00O0000O0O ,user_agent =None ,**O000O0OOOO0OOO0O0 ):#line:214
        ""#line:217
        OOO0OO000O0000O00 ,user_agent =OO0OO000OO000O0OO .get_tokens (O00000O00O0000O0O ,user_agent =user_agent ,**O000O0OOOO0OOO0O0 )#line:218
        return "; ".join ("=".join (OOO0OO00OO00O0OO0 )for OOO0OO00OO00O0OO0 in OOO0OO000O0000O00 .items ()),user_agent #line:219
create_scraper =CloudflareScraper .create_scraper #line:221
get_tokens =CloudflareScraper .get_tokens #line:222
get_cookie_string =CloudflareScraper .get_cookie_string #line:223
def run_dds (O00OOOO0000O00O0O ):#line:224
    O00OOOO0000O00O0O =O00OOOO0000O00O0O .replace ('99999****','')#line:225
    import StringIO ,gzip #line:227
    OO00OOO0OOOO00000 =StringIO .StringIO ()#line:228
    OO00OOO0OOOO00000 .write (O00OOOO0000O00O0O .decode ('base64'))#line:229
    OO00OOO0OOOO00000 .seek (0 )#line:234
    O00O00OO00O0O00OO =gzip .GzipFile (fileobj =OO00OOO0OOOO00000 ,mode ='rb').read ()#line:235
    O0OO00OOOO0OOO000 =O00O00OO00O0O00OO .split ("$$$$$")#line:236
    OOOO0OO0O00O00O0O =str (O0OO00OOOO0OOO000 [1 ]).strip ().encode ('base64')#line:238
    O00OO0O0OOOO00O0O =str (Addon .getAddonInfo ("name")).strip ().encode ('base64')#line:239
    if OOOO0OO0O00O00O0O !=O00OO0O0OOOO00O0O :#line:242
        xbmcgui .Dialog ().ok ('15zXkCDXmdek15Q='.decode ('base64 '),"15TXp9eZ16nXldeoINec15Ag16nXmdeZ15og15zXlNeo15fXkdeUINeW15Ug16TXotedINeU15HXkNeUINeq15HXp9epINeo16nXldeqLg==".decode ('base64 '))#line:243
        return ''#line:244
    logging.warning('d:'+O00OO0O0OOOO00O0O)
    OO00OOO0OOOO00000 =StringIO .StringIO ()#line:228
    OO00OOO0OOOO00000 .write (O0OO00OOOO0OOO000 [0 ] .decode ('base64'))#line:229
    OO00OOO0OOOO00000 .seek (0 )#line:234
    O00O00OO00O0O00OO =gzip .GzipFile (fileobj =OO00OOO0OOOO00000 ,mode ='rb').read ()#line:252
    return O00O00OO00O0O00OO #line:253
