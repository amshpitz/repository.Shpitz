﻿id_addon='chanand.kids'
parts=['aHR0cHM6Ly9naXRodWIuY29tL3lvbm5pNTU=','NTU1L2tpZHMvYmxvYi9tYXN0ZXIvJUQ3JUE=','NyVENyU5RSVENyU5OSVENyU5QyVENyU5OSU=','RDclOTUlRDclOUYudHh0P3Jhdz10cnVl']
cat_cat=False
year_cat=False
a_b_cat=False
ranking_cat=False
all_m_cat=False
cat_chan=True