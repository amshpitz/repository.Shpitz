# -*- coding: utf-8 -*-
import urllib,urllib2,re,xbmcplugin,xbmcgui,os,sys,datetime
from resources.lib.common_variables import *
from resources.lib.directory import *
from resources.lib.youtubewrapper import *
from resources.lib.watched import * 

fanart = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.lahavSelected', 'fanart.jpg'))
art = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.lahavSelected/resources/img', ''))

def CATEGORIES():
        addDir('ערוצים חיים מישראל', 'url', 47, art + 'TV1.jpg')
        addDir('VOD ישראלי', 'url', 48, art + 'vodil.jpg')
        addDir('סדרות','url',49,art + 'tvshows.jpg')
        addDir('סרטים','url',44,art + 'movies.jpg')
        addDir('ילדים','url',12,art + 'lamusic.jpg')
        addDir('ספורט', 'url', 46, art + 'Soccer.jpg')
        addDir('רדיו ישראלי', 'url', 40, art + 'Soccer.jpg')
        addDir('מוזיקה','url',41,art + 'lamusic.jpg')
        addDir('אוכל', 'url', 42, art + 'lacook.jpg')
        addDir('הסטוריה ומדע','url',45,art + 'labook.jpg')
        addDir('favorite Repo Install', 'url', 50, art + 'lacook.jpg')
        addDir('תחזוקה והתקנות', 'url', 60, art + 'vodil.jpg')

def laLiveTV():
        addDir3('RoiD TV Live', 'plugin://plugin.video.RoiD', 35, art + 'movies.png')
        addDir3('The Pyramid TV', 'plugin://plugin.video.thepyramid', 35, art + 'movies.png')
        addDir3('Sanctuary Live TV', 'plugin://plugin.video.sanctuary/?url=http%3A%2F%2Fgenietvcunts.co.uk%2Fbamffff%2Fbamftv.m3u&amp;mode=1101&amp;name=%5BCOLORgreen%5D%5BB%5DLIVE+UK+%26+USA+%5B%2FB%5D%5B%2FCOLOR%5D&amp;fanart=C%3A%5CUsers%5CAmos%5CAppData%5CRoaming%5CKodi%5Caddons%5Cplugin.video.sanctuary%5Cfanart.jpg', 35, art + 'movies.png')
        addDir3('Phoenix TV', 'plugin://plugin.video.phstreams', 35, art + 'movies.png')
        addDir3('UK Turk Live TV', 'plugin://plugin.video.ukturk/?url=http%3A%2F%2Fukturk.offshorepastebin.com%2FUKTurk%2FLive%2520TV.txt&amp;mode=1&amp;name=Live+TV&amp;description=&amp;fanart=C%3A%5CUsers%5CAmos%5CAppData%5CRoaming%5CKodi%5Caddons%5Cplugin.video.ukturk%5Cfanart.jpg&amp;iconimage=http%3A%2F%2Fukturk.offshorepastebin.com%2FUKTurk%2Fthumbs%2Fnew%2FUk%2520turk%2520thumbnails%2520live%2520tv.jpg', 35, art + 'movies.png')
        addDir3('שידורים מארצות שונות', 'plugin://plugin.video.RoiD/?mode=1&amp;item=title%3D%255BCOLOR%2Bwhite%255D%255BB%255DStream2Watch.cc%255B%252FB%255D%255B%252FCOLOR%255D%2B-%2BTV%2BChannels%2BFrom%2BAll%2BOver%2BThe%2BWorld%26url%3DChannels%252FStream2Watch.cfg%26definedIn%3DChannels%252F_Channels_Menu.cfg%26director%3DRoiD%26type%3Drss%26icon%3DC%253A%255CUsers%255CAmos%255CAppData%255CRoaming%255CKodi%255Caddons%255Cplugin.video.RoiD%255Cresources%255Cimages%255CStream2Watch_v02.jpg', 35, art + 'movies.png')

def laVOD():
        addDir3('RoiD VOD', 'plugin://plugin.video.RoiD/?mode=1&amp;item=title%3DVOD%26url%3DVOD%252F_VOD_Menu.cfg%26definedIn%3DmainMenu_Adult_Yes.cfg%26director%3DRoiD%26type%3Drss%26icon%3DC%253A%255CUsers%255CAmos%255CAppData%255CRoaming%255CKodi%255Caddons%255Cplugin.video.RoiD%255Cresources%255Cimages%255CVOD_v02.jpg', 35, art + 'lacook.jpg')
        addDir3('VodIL', 'plugin://plugin.video.Vodil', 35, art + 'lacook.jpg')
        addDir3('Vod Lahav', 'plugin://plugin.video.Vodlahav', 35, art + 'lacook.jpg')

def laTVshow():
        addDir3('סדרות My Zen', 'plugin://plugin.video.zen/?action=tvshows&amp;url=mycustomlist1', 35, art + 'tvshows.png')
        addDir3('סדרות Zen', 'plugin://plugin.video.zen/?action=tvNavigator', 35, art + 'tvshows.png')
        addDir3('My Specto TvShow Ishow-Favoties', 'plugin://plugin.video.specto/?action=tvshows&amp;url=http%3A%2F%2Fapi-v2launch.trakt.tv%2Fusers%2Fme%2Flists%2Fishows-favorites%2Fitems', 35, art + 'tvshows.png')
        addDir3('סדרות Exodus', 'plugin://plugin.video.exodus/?action=tvNavigator', 35, art + 'tvshows.png')
        addDir3('סדרות specto', 'plugin://plugin.video.specto/?action=tvNavigator', 35, art + 'tvshows.png')
        addDir3('סדרות 123movies', 'plugin://plugin.video.md123movies', 35, art + 'tvshows.png')
        addDir3('סדרות עם תרגום מובנה','plugin://plugin.video.RoiD/?mode=1&amp;item=title%3D%255BCOLOR%2Bwhite%255D%255BB%255DTvil.me%255B%252FB%255D%255B%252FCOLOR%255D%2B-%2BVOD%2BFrom%2BAll%2BOver%2BThe%2BWorld%2B%2528%25D7%25AA%25D7%25A8%25D7%2592%25D7%2595%25D7%259D%2B%25D7%259E%25D7%2595%25D7%2591%25D7%25A0%25D7%2594%2529%26url%3DVOD%252FTvil.cfg%26definedIn%3DVOD%252F_VOD_Menu.cfg%26director%3DRoiD%26type%3Drss%26icon%3DC%253A%255CUsers%255CAmos%255CAppData%255CRoaming%255CKodi%255Caddons%255Cplugin.video.RoiD%255Cresources%255Cimages%255CTvil_v02.jpg', 35, art + 'tvshows.png')

def lamovies():
        addDir3('My Zen סרטים', 'plugin://plugin.video.zen/?action=movies&amp;url=mycustomlist1', 35, art + 'movies.png')
        addDir3('Zen סרטים', 'plugin://plugin.video.zen/?action=movieNavigator', 35, art + 'movies.png')
        addDir3('My Specto Movies Ishow-Favoties', 'plugin://plugin.video.specto/?action=movies&amp;url=http%3A%2F%2Fapi-v2launch.trakt.tv%2Fusers%2Fme%2Flists%2Fishows-favorites%2Fitems', 35, art + 'movies.png')
        addDir3('סרטים Exodus', 'plugin://plugin.video.exodus/?action=movieNavigator', 35, art + 'movies.png')
        addDir3('סרטים specto', 'plugin://plugin.video.specto/?action=movieNavigator', 35, art + 'movies.png')
        addDir3('סרטים 123movies', 'plugin://plugin.video.md123movies', 35, art + 'movies.png')
        addDir3('מארזי סרטים', 'plugin://plugin.video.bob/?action=directory&amp;url=http%3A%2F%2F217.182.69.114%2F%7Ebob%2Fnorestrictions.club%2Ftnpb%2FDirectories%2FMain%2520Directory%2FAll%2520Boxsets%2520Directory.xml&amp;content=0', 35, art + 'movies.png')

def lakids():
        addDir3('My Zen סרטים', 'plugin://plugin.video.zen/?action=movies&amp;url=mycustomlist1', 35, art + 'movies.png')
        addDir3('Zen סרטים', 'plugin://plugin.video.zen/?action=movieNavigator', 35, art + 'movies.png')
        addDir3('My Specto Movies Ishow-Favoties', 'plugin://plugin.video.specto/?action=movies&amp;url=http%3A%2F%2Fapi-v2launch.trakt.tv%2Fusers%2Fme%2Flists%2Fishows-favorites%2Fitems', 35, art + 'movies.png')
        addDir3('סרטים Exodus', 'plugin://plugin.video.exodus/?action=movieNavigator', 35, art + 'movies.png')
        addDir3('סרטים specto', 'plugin://plugin.video.specto/?action=movieNavigator', 35, art + 'movies.png')
        addDir3('סרטים 123movies', 'plugin://plugin.video.md123movies', 35, art + 'movies.png')
        addDir3('מארזי סרטים', 'plugin://plugin.video.bob/?action=directory&amp;url=http%3A%2F%2F217.182.69.114%2F%7Ebob%2Fnorestrictions.club%2Ftnpb%2FDirectories%2FMain%2520Directory%2FAll%2520Boxsets%2520Directory.xml&amp;content=0', 35, art + 'movies.png')


def laradio():
        addDir3('ספורט 1','plugin://plugin.video.RoiD/?mode=1&amp;item=title%3D%25D7%25A1%25D7%25A4%25D7%2595%25D7%25A8%25D7%2598%2B1%26url%3DIsrael%252FSport1.cfg%26definedIn%3DmainMenu_Adult_Yes.cfg%26director%3DRoiD%26type%3Drss%26icon%3DC%253A%255CUsers%255CAmos%255CAppData%255CRoaming%255CKodi%255Caddons%255Cplugin.video.RoiD%255Cresources%255Cimages%255CSport1_v02.jpg")', 35, art + 'Soccer.png')
        addDir3('ספורט 2', 'plugin://plugin.video.RoiD/?mode=1&amp;item=title%3D%25D7%25A1%25D7%25A4%25D7%2595%25D7%25A8%25D7%2598%2B2%26url%3DIsrael%252FSport2.cfg%26definedIn%3DmainMenu_Adult_Yes.cfg%26director%3DRoiD%26type%3Drss%26icon%3DC%253A%255CUsers%255CAmos%255CAppData%255CRoaming%255CKodi%255Caddons%255Cplugin.video.RoiD%255Cresources%255Cimages%255CSport2_v02.jpg")', 35, art + 'Soccer.png')
        addDir3('One ספורט', 'plugin://plugin.video.RoiD/?mode=1&amp;item=title%3D%25D7%25A1%25D7%25A4%25D7%2595%25D7%25A8%25D7%2598%2BOne%26url%3DIsrael%252FSportOne.cfg%26definedIn%3DmainMenu_Adult_Yes.cfg%26director%3DRoiD%26type%3Drss%26icon%3DC%253A%255CUsers%255CAmos%255CAppData%255CRoaming%255CKodi%255Caddons%255Cplugin.video.RoiD%255Cresources%255Cimages%255CSportOne_v02.jpg")', 35, art + 'Soccer.jpg')
        addDir3('ספורט 5','plugin://plugin.video.RoiD/?mode=1&amp;item=title%3D%25D7%25A1%25D7%25A4%25D7%2595%25D7%25A8%25D7%2598%2B5%26url%3DIsrael%252FSport5.cfg%26definedIn%3DmainMenu_Adult_Yes.cfg%26director%3DRoiD%26type%3Drss%26icon%3DC%253A%255CUsers%255CAmos%255CAppData%255CRoaming%255CKodi%255Caddons%255Cplugin.video.RoiD%255Cresources%255Cimages%255CSport5_v02.jpg")',35, art + 'Soccer.jpg')
        addDir3('ספורט 5 פלוס','plugin://plugin.video.RoiD/?mode=1&amp;item=title%3D%25D7%25A1%25D7%25A4%25D7%2595%25D7%25A8%25D7%2598%2B5%2B%25D7%25A4%25D7%259C%25D7%2595%25D7%25A1%26url%3DIsrael%252FSport5plus.cfg%26definedIn%3DmainMenu_Adult_Yes.cfg%26director%3DRoiD%26type%3Drss%26icon%3DC%253A%255CUsers%255CAmos%255CAppData%255CRoaming%255CKodi%255Caddons%255Cplugin.video.RoiD%255Cresources%255Cimages%255CSport5plus_v02.jpg")',35, art + 'Soccer.jpg')
        addDir3('ספורט 5 לייב','plugin://plugin.video.RoiD/?mode=1&amp;item=title%3D%25D7%25A1%25D7%25A4%25D7%2595%25D7%25A8%25D7%2598%2B5%2B%25D7%259C%25D7%2599%25D7%2599%25D7%2591%26url%3DIsrael%252FSport5live.cfg%26definedIn%3DmainMenu_Adult_Yes.cfg%26director%3DRoiD%26type%3Drss%26icon%3DC%253A%255CUsers%255CAmos%255CAppData%255CRoaming%255CKodi%255Caddons%255Cplugin.video.RoiD%255Cresources%255Cimages%255CSport5live_v02.jpg")',35, art + 'Soccer.jpg')
        addDir3('UK Turk Sport','plugin://plugin.video.ukturk/?url=http%3A%2F%2Fukturk.offshorepastebin.com%2FUKTurk%2FSportsList.txt&amp;mode=1&amp;name=Sports&amp;description=&amp;fanart=C%3A%5CUsers%5CAmos%5CAppData%5CRoaming%5CKodi%5Caddons%5Cplugin.video.ukturk%5Cfanart.jpg&amp;iconimage=http%3A%2F%2Fukturk.offshorepastebin.com%2FUKTurk%2Fthumbs%2Fnew%2FUk%2520turk%2520thumbnails%2520sports.jpg")',35, art + 'Soccer.jpg')
        addDir3('Zem Sport', 'plugin://plugin.video.ZemTV-shani/?url=Live&amp;mode=13&amp;name=Sports', 35, art + 'Soccer.png')
        addDir3('The Pyramid Sport','plugin://plugin.video.thepyramid/?url=http%3A%2F%2Ftombraiderbuilds.co.uk%2Faddon%2Fsportschannels%2Fsportschannels.txt&amp;mode=1&amp;name=%5BB%5D%5BI%5D%5BCOLORtomato%5DSPORTS+ZONE%5B%2FB%5D%5B%2FI%5D%5B%2FCOLOR%5D&amp;fanart=http%3A%2F%2Ftombraiderbuilds.co.uk%2FBackgrounds%2FTombRaiderMoviesBackground.jpg', 35, art + 'Soccer.png')

def lasport():
        addDir3('ספורט 1','plugin://plugin.video.RoiD/?mode=1&amp;item=title%3D%25D7%25A1%25D7%25A4%25D7%2595%25D7%25A8%25D7%2598%2B1%26url%3DIsrael%252FSport1.cfg%26definedIn%3DmainMenu_Adult_Yes.cfg%26director%3DRoiD%26type%3Drss%26icon%3DC%253A%255CUsers%255CAmos%255CAppData%255CRoaming%255CKodi%255Caddons%255Cplugin.video.RoiD%255Cresources%255Cimages%255CSport1_v02.jpg")', 35, art + 'Soccer.png')
        addDir3('ספורט 2', 'plugin://plugin.video.RoiD/?mode=1&amp;item=title%3D%25D7%25A1%25D7%25A4%25D7%2595%25D7%25A8%25D7%2598%2B2%26url%3DIsrael%252FSport2.cfg%26definedIn%3DmainMenu_Adult_Yes.cfg%26director%3DRoiD%26type%3Drss%26icon%3DC%253A%255CUsers%255CAmos%255CAppData%255CRoaming%255CKodi%255Caddons%255Cplugin.video.RoiD%255Cresources%255Cimages%255CSport2_v02.jpg")', 35, art + 'Soccer.png')
        addDir3('One ספורט', 'plugin://plugin.video.RoiD/?mode=1&amp;item=title%3D%25D7%25A1%25D7%25A4%25D7%2595%25D7%25A8%25D7%2598%2BOne%26url%3DIsrael%252FSportOne.cfg%26definedIn%3DmainMenu_Adult_Yes.cfg%26director%3DRoiD%26type%3Drss%26icon%3DC%253A%255CUsers%255CAmos%255CAppData%255CRoaming%255CKodi%255Caddons%255Cplugin.video.RoiD%255Cresources%255Cimages%255CSportOne_v02.jpg")', 35, art + 'Soccer.jpg')
        addDir3('ספורט 5','plugin://plugin.video.RoiD/?mode=1&amp;item=title%3D%25D7%25A1%25D7%25A4%25D7%2595%25D7%25A8%25D7%2598%2B5%26url%3DIsrael%252FSport5.cfg%26definedIn%3DmainMenu_Adult_Yes.cfg%26director%3DRoiD%26type%3Drss%26icon%3DC%253A%255CUsers%255CAmos%255CAppData%255CRoaming%255CKodi%255Caddons%255Cplugin.video.RoiD%255Cresources%255Cimages%255CSport5_v02.jpg")',35, art + 'Soccer.jpg')
        addDir3('ספורט 5 פלוס','plugin://plugin.video.RoiD/?mode=1&amp;item=title%3D%25D7%25A1%25D7%25A4%25D7%2595%25D7%25A8%25D7%2598%2B5%2B%25D7%25A4%25D7%259C%25D7%2595%25D7%25A1%26url%3DIsrael%252FSport5plus.cfg%26definedIn%3DmainMenu_Adult_Yes.cfg%26director%3DRoiD%26type%3Drss%26icon%3DC%253A%255CUsers%255CAmos%255CAppData%255CRoaming%255CKodi%255Caddons%255Cplugin.video.RoiD%255Cresources%255Cimages%255CSport5plus_v02.jpg")',35, art + 'Soccer.jpg')
        addDir3('ספורט 5 לייב','plugin://plugin.video.RoiD/?mode=1&amp;item=title%3D%25D7%25A1%25D7%25A4%25D7%2595%25D7%25A8%25D7%2598%2B5%2B%25D7%259C%25D7%2599%25D7%2599%25D7%2591%26url%3DIsrael%252FSport5live.cfg%26definedIn%3DmainMenu_Adult_Yes.cfg%26director%3DRoiD%26type%3Drss%26icon%3DC%253A%255CUsers%255CAmos%255CAppData%255CRoaming%255CKodi%255Caddons%255Cplugin.video.RoiD%255Cresources%255Cimages%255CSport5live_v02.jpg")',35, art + 'Soccer.jpg')
        addDir3('UK Turk Sport','plugin://plugin.video.ukturk/?url=http%3A%2F%2Fukturk.offshorepastebin.com%2FUKTurk%2FSportsList.txt&amp;mode=1&amp;name=Sports&amp;description=&amp;fanart=C%3A%5CUsers%5CAmos%5CAppData%5CRoaming%5CKodi%5Caddons%5Cplugin.video.ukturk%5Cfanart.jpg&amp;iconimage=http%3A%2F%2Fukturk.offshorepastebin.com%2FUKTurk%2Fthumbs%2Fnew%2FUk%2520turk%2520thumbnails%2520sports.jpg")',35, art + 'Soccer.jpg')
        addDir3('Zem Sport', 'plugin://plugin.video.ZemTV-shani/?url=Live&amp;mode=13&amp;name=Sports', 35, art + 'Soccer.png')
        addDir3('The Pyramid Sport','plugin://plugin.video.thepyramid/?url=http%3A%2F%2Ftombraiderbuilds.co.uk%2Faddon%2Fsportschannels%2Fsportschannels.txt&amp;mode=1&amp;name=%5BB%5D%5BI%5D%5BCOLORtomato%5DSPORTS+ZONE%5B%2FB%5D%5B%2FI%5D%5B%2FCOLOR%5D&amp;fanart=http%3A%2F%2Ftombraiderbuilds.co.uk%2FBackgrounds%2FTombRaiderMoviesBackground.jpg', 35, art + 'Soccer.png')


def lahist():
        addDir('שעה היסטורית עם פרופ הרסגור', 'PLi3ABZgzV07L9O3Mh3ELo0Fg2jZo-Dxi4', 1, art + 'hrsagor.jpg')
        addDir('ד"ר יובל הררי - היסטוריה עולמית', 'PLfHmQCZe1ktg9G7Too6IjmJfVPEeHfXCq', 1, art + 'lahav.jpg')
        addDir('בית שני', 'PLC4C505694FD95258', 1, art + 'lahav.jpg')
        addDir('ישראל הקדום, ארכיאולוגיה ומקרא', 'PLPpE92HjGRlkYELCoBb0BhQsSWDLqyaQr', 1, art + 'lahav.jpg')
        addDir('אלוהים ויהדות בלי סיפורי אגדות','PLPpE92HjGRlnuEuWDq_HWe8RzuGKLvSoV',1,art + 'lahav.png')
        addDir3('History Tube','plugin://plugin.video.historytube',35,art + 'ysearch.png')
        addDir('קורס תכנות בפייתון','PLPpE92HjGRlmznhxNpEEDC6fgTQDO32EN',1,art + 'lahav.jpg')


def lamusic():
        addDir3('Lahav PlayList','plugin://plugin.video.gdrive/?mode=index&amp;instance=gdrive1&amp;folder=0B-cTjQHcHUGAYkZTN2hQUEJBMXc&amp;epath=%2F%D7%9E%D7%95%D7%96%D7%99%D7%A7%D7%94%2F&amp;content_type=video',35, art + 'lamusic.jpg')
        addDir3('Music TV','plugin://plugin.video.bob/?action=directory&amp;url=http%3A%2F%2F217.182.69.114%2F%7Ebob%2Fnorestrictions.club%2Ftastreams%2Ffiles%2Fmusic%2FMusic%2520TV.xml&amp;content=0',35,art + 'lamusic.png')
        addDir3('99FM Playlist', 'plugin://plugin.audio.99fm-playlists', 35, art + 'movies.png')
        addDir3('100FM Digital', 'plugin://plugin.video.RoiD/?mode=1&amp;item=title%3D%25D7%2593%25D7%2599%25D7%2592%25D7%2599%25D7%2598%25D7%259C%2B100fm%26fanart%3Dhttp%253A%252F%252Fdigital.100fm.co.il%252Fimg%252Fshare.png%26cfg%3DRadio.cfg%2540Digital100fm%26definedIn%3DRadio.cfg%26director%3DRoiD%26url%3Dhttp%253A%252F%252Fdigital.100fm.co.il%26type%3Drss%26icon%3DC%253A%255CUsers%255CAmos%255CAppData%255CRoaming%255CKodi%255Caddons%255Cplugin.video.RoiD%255Cresources%255Cimages%255CDigital100fm_v02.jpg', 35, art + 'movies.png')
        addDir3('רדיו כאן- מוזיקה', 'plugin://plugin.video.RoiD/?mode=1&amp;item=title%3D%25D7%25A8%25D7%2593%25D7%2599%25D7%2595%2B%25D7%259B%25D7%2590%25D7%259F%2B%257C%2B%25D7%25AA%25D7%2590%25D7%2592%25D7%2599%25D7%2593%2B%25D7%2594%25D7%25A9%25D7%2599%25D7%2593%25D7%2595%25D7%25A8%2B%25D7%2594%25D7%2599%25D7%25A9%25D7%25A8%25D7%2590%25D7%259C%25D7%2599%26url%3Dhttp%253A%252F%252Fwww.kan.org.il%252Fradio%252Fradio-nos.aspx%26cfg%3DRadio.cfg%2540Kan%26definedIn%3DRadio.cfg%26director%3DRoiD%26type%3Drss%26icon%3DC%253A%255CUsers%255CAmos%255CAppData%255CRoaming%255CKodi%255Caddons%255Cplugin.video.RoiD%255Cresources%255Cimages%255CKan_v02.jpg', 35, art + 'movies.png')

def lacook():
        addDir('מתכונים נבחרים','PLPpE92HjGRllnKB-aztb5TPBHWg4W9Dwm',1,art + 'lacook.jpg')
        addDir('ארוחת ערב - tasty','PL8zglt-LDl-iwBHEl3Pw1IhWGp9cfgMrc',1,art + 'lacook.jpg')
        addDir('ארוחת בוקר - tasty','PL8zglt-LDl-i0xOKNOyfp3MHejOv1Kyov',1,art + 'lacook.jpg')
        addDir('מתאבנים - tasty','PL8zglt-LDl-jp8PpdleYo6o2-ogLAxjzD',1,art + 'lacook.jpg')
        addDir('תוכניות אוכל מיוחד','PLPpE92HjGRlkBeYOQuXza0z7L-XUkGCJ0',1,art + 'lacook.jpg')
        addDir3('תוכניות אוכל VodIL', 'plugin://plugin.video.Vodil/?url=url&amp;mode=17&amp;name=%D7%90%D7%95%D7%9B%D7%9C+%D7%95%D7%91%D7%99%D7%A9%D7%95%D7%9C', 35, art + 'lacook.jpg')


def laTools():
        addDir3('תחזוקה','plugin://plugin.program.senyortools/?url=http%3A%2F%2Fkodi-senyor.co.il%2F&amp;mode=30&amp;name=%5BCOLOR+orange%5D%5BB%5DMaintenance%5B%2FB%5D%5B%2FCOLOR%5D&amp;iconimage=C%3A%5CUsers%5CAmos%5CAppData%5CRoaming%5CKodi%5Caddons%5Cplugin.program.senyortools%5Cresources%5Cart%5Ctahzooka.png&amp;fanart=C%3A%5CUsers%5CAmos%5CAppData%5CRoaming%5CKodi%5Caddons%5Cplugin.program.senyortools%5Cfanart.jpg&amp;description=',35, art + 'lacook.jpg')
        addDir3('התקנה מלאה אוטומטית Lahav', 'plugin://plugin.program.lahavtools/?url=http%3A%2F%2Fkodi-senyor.co.il%2F&amp;mode=23&amp;name=%5BCOLOR+green%5D%5BB%5D%D7%90%D7%A9%D7%A3+%D7%94%D7%AA%D7%A7%D7%A0%D7%AA+%D7%A7%D7%95%D7%93%D7%99%5B%2FB%5D%5B%2FCOLOR%5D&amp;iconimage=C%3A%5CUsers%5CAmos%5CAppData%5CRoaming%5CKodi%5Caddons%5Cplugin.program.lahavtools%5Cresources%5Cart%5Cashaf4.png&amp;fanart=C%3A%5CUsers%5CAmos%5CAppData%5CRoaming%5CKodi%5Caddons%5Cplugin.program.lahavtools%5Cfanart.jpg&amp;description=', 35, art + 'lacook.jpg')
        addDir3('התקנת תוספים לפי בחירה', 'plugin://plugin.program.repotools', 35, art + 'lacook.jpg')
        addDir3('תחזוקה כללית לקודי indigo', 'plugin://plugin.program.indigo', 35, art + 'lacook.jpg')

def lashow():
        addDir('לילה גוב עונה ראשונה','PL0HqiSqEXnIBp1UWXrlRkas-hpy-w_dn0',1,art + 'lacook.jpg')
        addDir('לילה גוב עונה שנייה','PL0HqiSqEXnIDYk1o0Timz69ZKhTUBq6G3',1,art + 'lacook.jpg')
        addDir('לילה גוב עונה שלישית','PL0HqiSqEXnIBmCUhhyw6IUI3b9g9tfaly',1,art + 'lacook.jpg')
        addDir('לילה גוב עונה רביעית','PL3VbzQ6kUVhEgzu-swdD2LoWoWrBM1qC2',1,art + 'lacook.jpg')
        addDir('לילה גוב עונה חמישית','PL0HqiSqEXnIBhap-Jl7qdAQtMXIZOinPD',1,art + 'lacook.jpg')
        addDir('הופעות חיות','PLPpE92HjGRllxp4mUf6F08aSGig9kqXcZ',1,art + 'lacook.jpg')

def cooking():
        addDir('מתכונים כלליים','PLF685A5B80B86FE3B',1,art + 'cooking.png')
        addDir('מתכונים כשרים','PL3zcxKFd7HIKL3oSXq6rCH-fvFGCaOaS9',1,art + 'cooking.png')
        addDir('מתכונים. מטבח יהודי ומזרח ים תיכוני','PLRUtxvlnaqwx3KugKPtd4C3Iexv0Ee5U3',1,art + 'cooking.png')
        addDir(''+translate(70002)+'','PLnzhIyrsnB5YJYfCNr4B9ewwTMhzS8pn9',1,art + 'cooking.png')
        addDir(''+translate(70004)+'','PLnzhIyrsnB5ZNE1PhI4hWyyvE6gbieoFs',1,art + 'cooking.png')       
        addDir('סודות מתוקים עונה 1','ELAMi0KPlVcsg',1,art + 'cooking.png')
        addDir('סודות מתוקים עונה 3','ELmeqByVOghVE',1,art + 'cooking.png')
        addDir('שגב במטבח','CLWEuLXV2ejHk',1,art + 'cooking.png')         
        addDir('מיקי שמו','PLqQIVRFHrR1rsA0RqsAkzMxa2Xc4tcO25',1,art + 'cooking.png')
        addDir('בישולים','PLkSacTgmGKr6a6sPE1F7q3VF7T00lffQc',1,art + 'cooking.png')
        addDir('בישולים 2','PLdDyYBhRKiyG21-epuoI57b7zBfAyQcvI',1,art + 'cooking.png') 
        addDir('לאכול - יסודות הבישול - ויקטור גלוגר','PL8jMo70ebRM5dsJOjJXzGylZny1dnFPI7',1,art + 'cooking.png')         
        addDir('לאכול - חומרי גלם - אוראל קמחי','PL8jMo70ebRM778yBMGXg5Bb0wKm60wtb3',1,art + 'cooking.png')
        addDir('לאון אל דנטה','PL8jMo70ebRM7nnRez1MyfKBFLTj9jzl1V',1,art + 'cooking.png')
        addDir('במטבח עם אמא','PL8jMo70ebRM6gYuy9d7yoPLTGg1asK78w',1,art + 'cooking.png')
        addDir('מיקי שמו עושה בית ספר - עונה ראשונה','PL8jMo70ebRM7tvFCZsiXhakIsbDwHOe9c',1,art + 'cooking.png')         
        addDir('מועדון ארוחת הבוקר עם אביב משה','PL8jMo70ebRM6CAq8sKdjfI4_N3qUO5U1j',1,art + 'cooking.png')
        addDir('פשוט לאפות','PL8jMo70ebRM6aT0ZciSlv_YhP2Kjp1tuk',1,art + 'cooking.png')
        addDir('המטבחון של ירון','PL156601B302C8F462',1,art + 'cooking.png')


def RepoInstall():
        addDir('ToMeRepo', 'url', 51, art + 'lacook.jpg')
        addDir('TheWiz', 'url', 52, art + 'lacook.jpg')
        addDir('kodisrael', 'url', 53, art + 'Soccer.jpg')
        addDir('featherence', 'url', 54, art + 'lacook.jpg')
        addDir('abeksis', 'url', 55, art + 'lacook.jpg')
        addDir('xbmcisrael', 'url', 56, art + 'Soccer.jpg')
        addDir('senyor', 'url', 57, art + 'lacook.jpg')
        addDir('nirepo', 'url', 58, art + 'lacook.jpg')
        addDir('RoiD', 'url', 59, art + 'Soccer.jpg')



def ToMeRepo():
        if os.path.exists(
                os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'repository.ToMeRepo')):
                return

        url = "https://github.com/amshpitz/repository.lahav/blob/master/Zips/repository.ToMeRepo/repository.ToMeRepo-1.1.1.zip?raw=true"
        addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
        packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')

        urllib.urlretrieve(url, packageFile)
        ExtractAll(packageFile, addonsDir)

        try:
                os.remove(packageFile)
        except:
                pass

        xbmc.executebuiltin("UpdateLocalAddons")
        xbmc.executebuiltin("UpdateAddonRepos")


def TheWiz():
        if os.path.exists(
                os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'repository.TheWiz')):
                return

        url = "https://github.com/amshpitz/repository.lahav/blob/master/Zips/repository.TheWiz/repository.TheWiz-2.3.3.zip?raw=true"
        addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
        packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')

        urllib.urlretrieve(url, packageFile)
        ExtractAll(packageFile, addonsDir)

        try:
                os.remove(packageFile)
        except:
                pass

        xbmc.executebuiltin("UpdateLocalAddons")
        xbmc.executebuiltin("UpdateAddonRepos")


def kodisrael():
        if os.path.exists(
                os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'repository.kodil')):
                return

        url = "https://github.com/amshpitz/repository.lahav/blob/master/Zips/repository.kodil/repository.kodil-1.2.zip?raw=true"
        addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
        packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')

        urllib.urlretrieve(url, packageFile)
        ExtractAll(packageFile, addonsDir)

        try:
                os.remove(packageFile)
        except:
                pass

        xbmc.executebuiltin("UpdateLocalAddons")
        xbmc.executebuiltin("UpdateAddonRepos")


def featherence():
        if os.path.exists(
                os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'repository.featherence')):
                return

        url = "https://github.com/amshpitz/repository.lahav/blob/master/Zips/repository.featherence/repository.featherence-1.2.0.zip?raw=true"
        addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
        packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')

        urllib.urlretrieve(url, packageFile)
        ExtractAll(packageFile, addonsDir)

        try:
                os.remove(packageFile)
        except:
                pass

        xbmc.executebuiltin("UpdateLocalAddons")
        xbmc.executebuiltin("UpdateAddonRepos")


def abeksis():
        if os.path.exists(
                os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'repository.abeksis')):
                return

        url = "https://github.com/amshpitz/repository.lahav/blob/master/Zips/repository.abeksis/repository.abeksis-1.0.3.zip?raw=true"
        addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
        packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')

        urllib.urlretrieve(url, packageFile)
        ExtractAll(packageFile, addonsDir)

        try:
                os.remove(packageFile)
        except:
                pass

        xbmc.executebuiltin("UpdateLocalAddons")
        xbmc.executebuiltin("UpdateAddonRepos")


def xbmcisrael():
        if os.path.exists(
                os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'repository.xbmc-israel')):
                return

        url = "https://github.com/amshpitz/repository.lahav/blob/master/Zips/repository.xbmc-israel/repository.xbmc-israel-1.0.4.zip?raw=true"
        addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
        packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')

        urllib.urlretrieve(url, packageFile)
        ExtractAll(packageFile, addonsDir)

        try:
                os.remove(packageFile)
        except:
                pass

        xbmc.executebuiltin("UpdateLocalAddons")
        xbmc.executebuiltin("UpdateAddonRepos")


def senyor():
        if os.path.exists(
                os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'repository.kodi-senyor')):
                return

        url = "https://github.com/amshpitz/repository.lahav/blob/master/Zips/repository.kodi-senyor/repository.kodi-senyor-1.2.1.zip?raw=true"
        addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
        packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')

        urllib.urlretrieve(url, packageFile)
        ExtractAll(packageFile, addonsDir)

        try:
                os.remove(packageFile)
        except:
                pass

        xbmc.executebuiltin("UpdateLocalAddons")
        xbmc.executebuiltin("UpdateAddonRepos")


def nirepo():
        if os.path.exists(
                os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'repository.nirepo')):
                return

        url = "https://github.com/amshpitz/repository.lahav/blob/master/Zips/repository.nirepo/repository.nirepo-0.0.1.zip?raw=true"
        addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
        packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')

        urllib.urlretrieve(url, packageFile)
        ExtractAll(packageFile, addonsDir)

        try:
                os.remove(packageFile)
        except:
                pass

        xbmc.executebuiltin("UpdateLocalAddons")
        xbmc.executebuiltin("UpdateAddonRepos")

def RoiD():
        if os.path.exists(
                os.path.join(xbmc.translatePath("special://home/addons/").decode("utf-8"), 'repository.RoiD')):
                return

        url = "https://github.com/amshpitz/repository.lahav/blob/master/Zips/repository.RoiD/repository.RoiD-1.0.2.zip?raw=true"
        addonsDir = xbmc.translatePath(os.path.join('special://home', 'addons')).decode("utf-8")
        packageFile = os.path.join(addonsDir, 'packages', 'isr.zip')

        urllib.urlretrieve(url, packageFile)
        ExtractAll(packageFile, addonsDir)

        try:
                os.remove(packageFile)
        except:
                pass

        xbmc.executebuiltin("UpdateLocalAddons")
        xbmc.executebuiltin("UpdateAddonRepos")


def lahavexec(url):

    ok=True        
    xbmc.executebuiltin('XBMC.Container.Update(%s)' % url )
    return ok
        
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param


params=get_params()
url=None
name=None
mode=None
iconimage=None
page = None
token = None

try: url=urllib.unquote_plus(params["url"])
except: pass
try: name=urllib.unquote_plus(params["name"])
except: pass
try: mode=int(params["mode"])
except:
	try: 
		mode=params["mode"]
	except: pass
try: iconimage=urllib.unquote_plus(params["iconimage"])
except: pass
try: token=urllib.unquote_plus(params["token"])
except: pass
try: page=int(params["page"])
except: page = 1

print ("Mode: "+str(mode))
print ("URL: "+str(url))
print ("Name: "+str(name))
print ("iconimage: "+str(iconimage))
print ("Page: "+str(page))
print ("Token: "+str(token))

		
def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setProperty('fanart_image', fanart)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok


def addDir2(name, url, mode, iconimage, fanart, description):
        u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(
                name) + "&iconimage=" + urllib.quote_plus(iconimage) + "&fanart=" + urllib.quote_plus(
                fanart) + "&description=" + urllib.quote_plus(description)
        ok = True
        liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
        liz.setProperty("Fanart_Image", fanart)
        if mode == 4:
                ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=False)
        else:
                ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
        return ok


def addDir3(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setProperty('fanart_image', fanart)
        if mode==35 :
               ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz)
               return ok


def addDir4(name, url, mode, iconimage, fanart, description):
        u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(
                name) + "&iconimage=" + urllib.quote_plus(iconimage) + "&fanart=" + urllib.quote_plus(
                fanart) + "&description=" + urllib.quote_plus(description)
        ok = True
        liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
        liz.setProperty("Fanart_Image", fanart)
        if mode == 33:
                ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=False)
        else:
                ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
        return ok


def addDir5(name, url, mode, iconimage, description):
        u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(
                name) + "&iconimage=" + urllib.quote_plus(iconimage) + "&description=" + urllib.quote_plus(description)
        liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
        menu = []

        if mode == 34:
                ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz)
                return ok


def addDir6(name, url, mode, iconimage, fanart, description):
        u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(
                name) + "&iconimage=" + urllib.quote_plus(iconimage) + "&fanart=" + urllib.quote_plus(
                fanart) + "&description=" + urllib.quote_plus(description)
        ok = True
        liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
        liz.setProperty("Fanart_Image", fanart)
        if mode == 92 or mode == 35 or mode == 36 or mode == 37 or mode == 12 or mode == 13 or mode == 14:
                ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=False)
        else:
                ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
        return ok


def addDir7(name, url, mode, iconimage, description):
        u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(
                name) + "&iconimage=" + urllib.quote_plus(iconimage) + "&description=" + urllib.quote_plus(description)
        liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
        menu = []

        if mode == 40:
                ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz)
                return ok


def addDir8(name, url, mode, iconimage, description):
        u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(
                name) + "&iconimage=" + urllib.quote_plus(iconimage) + "&description=" + urllib.quote_plus(description)
        liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
        menu = []

        if mode == 24:
                ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz)
                return ok


def addDir9(name, url, mode, iconimage, description):
        u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(
                name) + "&iconimage=" + urllib.quote_plus(iconimage) + "&description=" + urllib.quote_plus(description)
        liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
        menu = []

        if mode == 8:
                ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz)
                return ok


def addDir11(name, url, mode, iconimage, fanart, description):
        u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(
                name) + "&iconimage=" + urllib.quote_plus(iconimage) + "&fanart=" + urllib.quote_plus(
                fanart) + "&description=" + urllib.quote_plus(description)
        ok = True
        liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
        liz.setProperty("Fanart_Image", fanart)
        if mode == 94:
                ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=False)
        else:
                ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
        return ok



def create_directory(dir_path, dir_name=None):
    if dir_name:
        dir_path = os.path.join(dir_path, dir_name)
    dir_path = dir_path.strip()
    if not os.path.exists(dir_path):
        os.makedirs(dir_path)
    return dir_path

if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES()
       
elif mode==1:
        return_youtubevideos(name,url,token,page)

elif mode==5: 
        play_youtube_video(url)

elif mode==6:
        mark_as_watched(url)

elif mode==7:
        removed_watched(url)

elif mode==8:
        add_to_bookmarks(url)

elif mode==9:
        remove_from_bookmarks(url)
		
elif mode==10:
        print ""+url
        lifestyle()
		
elif mode==11:
        print ""+url
        documentary()

elif mode==12:
        print ""+url
        kids()

elif mode==13:
        print ""+url
        Music()
        
elif mode==14:
        print ""+url
        travel()

elif mode==15:
        print ""+url
        Sports()

elif mode==16:
        print ""+url
        liveshows()

elif mode==17:
        print ""+url
        cooking()
			
elif mode==18:
        print ""+url
        junior()
		
elif mode==19:
        print ""+url
        nickjunior()

elif mode==20:
        print ""+url
        nicklodeon()

elif mode==21:
        print ""+url
        logy()

elif mode==22:
        print ""+url
        hop()

elif mode==23:
        print ""+url
        hopy()	

elif mode==24:
        print ""+url
        luly()

elif mode==25:
        print ""+url
        baby()

elif mode==26:
        print ""+url
        hot()

elif mode==27:
        print ""+url
        kidstv()

elif mode==28:
        print ""+url
        ch23()

elif mode==29:
        print ""+url
        zoom()		

elif mode==30:
        print ""+url
        dsjunior()

elif mode==31:
        print ""+url
        NBA()

elif mode==32:
        print ""+url
        basket()

elif mode==33:
        print ""+url
        soccer()		

elif mode==34:
        print ""+url
        box()		

elif mode==37:
        print ""+url
        nostal()				
		
elif mode==35:
        lahavexec(url)

elif mode==38:
        print ""+url
        movies()

elif mode==39:
        print ""+url
        poker()
elif mode==40:
        print ""+url
        lahav()

elif mode==41:
        print ""+url
        lamusic()

elif mode==42:
        print ""+url
        lacook()

elif mode==43:
        print ""+url
        lashow()

elif mode==44:
        print ""+url
        lamovies()

elif mode == 45:
        print "" + url
        lahist()
elif mode == 46:
        print "" + url
        lasport()

elif mode == 47:
        print "" + url
        laLiveTV()

elif mode == 48:
        print "" + url
        laVOD()

elif mode == 49:
        print "" + url
        laTVshow()

elif mode == 50:
        print "" + url
        RepoInstall()

elif mode == 51:
        print "" + url
        ToMeRepo()

elif mode == 52:
        print "" + url
        TheWiz()

elif mode == 53:
        print "" + url
        kodisrael()

elif mode == 54:
        print "" + url
        featherence()

elif mode == 55:
        print "" + url
        abeksis()

elif mode == 56:
        print "" + url
        xbmcisrael()

elif mode == 57:
        print "" + url
        senyor()

elif mode == 58:
        print "" + url
        nirepo()

elif mode == 59:
        print "" + url
        RoiD()

elif mode == 60:
        print "" + url
        laTools()

xbmcplugin.endOfDirectory(int(sys.argv[1]))
